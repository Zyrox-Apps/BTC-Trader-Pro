BTC Trader Pro 2.0.0-kunden-v2-r0020 (revision 26). Execution policy: runtime-gated-v1. Installation und LIVE-Betrieb erfordern die jeweiligen Freigaben.
