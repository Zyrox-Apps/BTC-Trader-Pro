/* Existing authenticated update hint; no installation-registry customer actions. */
(() => {
'use strict';
document.addEventListener('DOMContentLoaded',async()=>{
 try {
  const r=await fetch('/api/v1/btctrader/license/customer-status',{cache:'no-store'});
  if(!r.ok)return;
  const state=await r.json(),hint=document.getElementById('customerUpdateHint');
  if(state.customer && state.update?.latestRevision){hint.hidden=false;hint.textContent='Update verfügbarer Stand: Revision '+state.update.latestRevision+'. Lokale Verwaltung: btctrader-admin update. APK-Updates mit gleichem Signer erhalten Gerätekey und Pairing.';}
 }catch{}
});
})();
