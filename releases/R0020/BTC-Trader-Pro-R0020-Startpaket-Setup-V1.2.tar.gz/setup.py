"""Thin interactive dispatcher. All mutations belong to existing product CLIs."""
import ast
import contextlib
import fcntl
import hashlib
import os
from pathlib import Path
import re
import stat
import subprocess
import sys
import tempfile
import shutil
import textwrap
from urllib.parse import urlsplit

BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE / 'vendor'))
ROOT = Path('/opt/btctrader')
OPS = Path('/var/lib/btctrader-operations')
KEY = Path('/usr/share/btctrader/release-public.key')
TERMINAL = {'FINALIZED', 'ROLLED_BACK'}


class Refused(Exception):
    """Only fixed, customer-safe text is carried by this exception."""


class Cancelled(Exception):
    pass


def width():
    return max(8, min(72, shutil.get_terminal_size(fallback=(80, 24)).columns - 1))


def colored():
    term = os.environ.get('TERM', '')
    return (sys.stdout.isatty() and 'NO_COLOR' not in os.environ
            and term.startswith(('xterm', 'screen', 'tmux', 'rxvt', 'linux', 'vt100', 'ansi')))


def say(message='', level='normal'):
    colors = {'title': '1;38;5;208' if '256color' in os.environ.get('TERM', '') else '1;33',
              'heading': '1;36', 'success': '32', 'warning': '33', 'error': '31', 'muted': '2'}
    color = colors.get(level) if colored() else None
    # Escape terminal control characters in displayed paths/metadata.
    message = ''.join(c if c == '\n' or ord(c) >= 32 and ord(c) != 127 else repr(c)[1:-1] for c in str(message))
    for paragraph in message.split('\n'):
        for line in textwrap.wrap(paragraph, width=width(), break_long_words=True, break_on_hyphens=False) or ['']:
            print(('\033[' + color + 'm' + line + '\033[0m') if color else line)


def ask(prompt):
    say(prompt)
    return input('> ')


def verifier():
    try:
        from btctrader_customer import artifacts
        return artifacts
    except ImportError:
        raise Refused('Paketprüfer fehlen. Benötigt: Ubuntu-Pakete python3-cryptography '
                      'und python3-jsonschema. Das Setup installiert sie nicht automatisch.') from None


def read(path, limit=1024 * 1024, owned=False):
    from btctrader_customer.common import safe
    path = safe(path)
    info = path.stat()
    if not stat.S_ISREG(info.st_mode) or info.st_size > limit:
        raise Refused('Dateityp oder Dateigröße ist nicht zulässig.')
    if owned:
        for entry in [path, *path.parents]:
            st = entry.stat()
            if st.st_uid != 0 or st.st_mode & 0o022:
                raise Refused('Installierte Verwaltungsdateien sind nicht sicher geschützt.')
    with path.open('rb') as stream:
        data = stream.read(limit + 1)
    if len(data) > limit:
        raise Refused('Dateigröße ist nicht zulässig.')
    return data


def digest(data):
    return hashlib.sha256(data).hexdigest()


def contract():
    from btctrader_customer.common import strict_json
    return strict_json(read(BASE / 'interface-contract.json'))


def public_key():
    key = read(BASE / 'TEST-ONLY-release-public.key', 32)
    if len(key) != 32 or digest(key) != contract()['keySha256']:
        raise Refused('Öffentlicher TEST-Vertrauensschlüssel stimmt nicht überein.')
    return key


def verify_package(path):
    api = verifier()
    raw = read(path, 512 * 1024**2)
    signature = read(Path(str(path) + '.sig'), 64)
    meta, payload = api.package(raw, signature, public_key())
    check_interface(meta, payload)
    if not re.fullmatch(r'2\.0\.0-kunden-v2-r[0-9]+', meta['productVersion']):
        raise Refused('Produktversionsvertrag wird von diesem Setup nicht unterstützt.')
    return meta, payload, raw, signature


def choose_package(folder=BASE):
    candidates = []
    for path in sorted(folder.glob('*.tar.gz')):
        try:
            meta, _, raw, _ = verify_package(path)
            candidates.append((path, meta, digest(raw)))
        except Exception:
            say('Ein Archiv wurde abgewiesen: Paket, Signatur, Schlüssel oder Schnittstelle ungültig.')
    if not candidates:
        raise Refused('Kein kompatibles signiertes Kundenpaket gefunden. Die innere Produkt-TAR.GZ '
                      'und ihre gleichnamige .sig neben start.sh ablegen; kein äußeres Startpaket.')
    for i, (_, meta, sha) in enumerate(candidates, 1):
        say(f"{i}. {meta['productVersion']} | Revision {meta['fromRevision']} → {meta['toRevision']} | SHA256 {sha}")
    # Always ask, including a single package. No automatic newest selection.
    value = ask('Paketnummer wählen (leer = abbrechen): ').strip()
    if not value.isdecimal() or not 1 <= int(value) <= len(candidates):
        raise Refused('Paketauswahl abgebrochen.')
    path, meta, sha = candidates[int(value) - 1]
    checked = verify_package(path)
    if digest(checked[2]) != sha:
        raise Refused('Paket wurde während der Auswahl verändert.')
    return checked


def state(root=ROOT, ops=OPS):
    """Read receipts only; never run recovery or read private customer state."""
    api = verifier()
    from btctrader_customer.common import strict_json, safe
    receipt = None
    receipt_path = ops / 'installation.json'
    if receipt_path.exists():
        receipt = strict_json(read(receipt_path, owned=True))
        if (set(receipt) != {'schemaVersion', 'operation', 'operationId', 'artifactSha256', 'revision', 'state'}
                or receipt['schemaVersion'] != 1 or receipt['operation'] != 'INSTALL'
                or not isinstance(receipt['revision'], int) or isinstance(receipt['revision'], bool)
                or not re.fullmatch(r'[0-9a-f]{64}', receipt['artifactSha256'])
                or not re.fullmatch(r'[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}', receipt['operationId'])):
            raise Refused('Installationsbeleg ist ungültig. Keine Änderungen; Journale prüfen lassen.')
    journals = {}
    if ops.exists():
        safe(ops)
        for directory in ops.iterdir():
            safe(directory, ops)
            if directory.is_dir() and (directory / 'journal.json').exists():
                j = strict_json(read(directory / 'journal.json', owned=True))
                api.schema('operationsjournal', j)
                if j['operationId'] != directory.name:
                    raise Refused('Journalzuordnung ist ungültig.')
                journals[directory.name] = j
    if receipt:
        j = journals.get(receipt['operationId'])
        if not j or any(j[a] != receipt[b] for a, b in [('operation', 'operation'), ('state', 'state'),
                      ('artifactSha256', 'artifactSha256'), ('toRevision', 'revision')]):
            raise Refused('Installationsbeleg und Journal widersprechen sich. Keine Änderung.')
    pending = [j for j in journals.values() if j['state'] not in TERMINAL]
    if len(pending) == 1 and receipt and pending[0]['operationId'] == receipt['operationId']:
        return 'UNFINISHED', receipt
    if pending:
        raise Refused('Offene Wartung/RECOVERY_REQUIRED: keine automatische Freigabe. Journale prüfen lassen.')
    if root.exists():
        if not (root / 'product.json').is_file():
            raise Refused('Unvollständiger Produktbestand ohne passenden Resume-Nachweis.')
        return 'INSTALLED', receipt
    return 'ABSENT', receipt


# Installer interface 2 is declared in the signed package metadata. Check the
# callable boundaries, not implementation bodies or customer-facing messages.
CLI_BOUNDARIES = {
    'tools/btctrader-admin': '*',
    'tools/btctrader-update': '*',
    'tools/install-bootstrap.py': '*',
    'tools/customer/btctrader_customer/admin.py': 'main',
    'tools/customer/btctrader_customer/update.py': 'main',
    'tools/customer/btctrader_customer/common.py': 'lock',
}


def check_entrypoints(payload):
    for name, function in CLI_BOUNDARIES.items():
        tree = ast.parse(payload[name], filename=name)
        if function != '*':
            nodes = [n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == function]
            if len(nodes) != 1:
                raise Refused('Verwaltungsschnittstelle nicht eindeutig.')
            args = nodes[0].args
            expected = 1 if function == 'lock' else 0
            if (len(args.posonlyargs) + len(args.args) != expected
                    or args.defaults or args.kwonlyargs or args.vararg or args.kwarg):
                raise Refused('Verwaltungsschnittstelle nicht unterstützt.')


def check_interface(meta, payload):
    c = contract()
    if (c.get('schemaVersion') != 3 or c.get('installerInterfaceVersion') != '2'
            or meta['minInstallerVersion'] != c['installerInterfaceVersion']
            or 'android' not in meta
            or not set(c['requiredTools']) <= payload.keys()
            or {n: digest(payload[n]) for n in c['schemas']} != c['schemas']):
        raise Refused('Authentisches Paket mit unbekanntem Verwaltungsvertrag. Geprüfte Setup-Unterstützung erforderlich.')
    check_entrypoints(payload)


def package_identity(meta):
    return {'product': meta['product'], 'revision': meta['toRevision'],
            'productVersion': meta['productVersion'], 'android': meta.get('android'), 'files': meta['files']}


def current_package(current, folder=None):
    matches = {}
    for path in sorted((folder or BASE).glob('*.tar.gz')):
        try:
            checked = verify_package(path)
        except Exception:
            continue
        if checked[0]['toRevision'] == current['revision']:
            matches[digest(checked[2])] = checked
    if len(matches) != 1:
        raise Refused('Eindeutiges signiertes Paket der installierten Revision fehlt. Paket und .sig neben start.sh bereitstellen.')
    checked = next(iter(matches.values()))
    if package_identity(checked[0]) != current:
        raise Refused('Produktinventar widerspricht dem authentischen Paket.')
    return checked


def journal_chain(current, checked, root, ops):
    import datetime
    import json
    from btctrader_customer.common import strict_json
    status, receipt = state(root, ops)
    if status != 'INSTALLED' or not receipt or receipt['state'] != 'FINALIZED':
        raise Refused('Abgeschlossene Installation mit konsistentem Ursprungsbeleg erforderlich.')
    records = []
    for directory in sorted(ops.iterdir()):
        if directory.is_dir() and (directory / 'journal.json').exists():
            j = strict_json(read(directory / 'journal.json', owned=True))
            inv = strict_json(read(directory / j['inventoryFile'], 16 * 1024**2, owned=True))
            records.append((j, inv))
    installation = next(j for j, _ in records if j['operationId'] == receipt['operationId'])
    revisions = {current['revision']: current}
    def remember(product):
        if (not isinstance(product, dict) or product.get('product') != 'BTC Trader Pro'
                or type(product.get('revision')) is not int or not isinstance(product.get('files'), list)):
            raise Refused('Operationsinventar enthält keine gültige Produktidentität.')
        r = product['revision']
        if r in revisions and revisions[r] != product:
            raise Refused('Widersprüchliche Produktinventare innerhalb der Updatekette.')
        revisions[r] = product
    updates = {}
    for j, inv in records:
        operation = j['operation']
        if operation == 'INSTALL':
            if j['operationId'] != receipt['operationId'] or inv.get('installerManaged') is not True:
                raise Refused('Installationshistorie nicht eindeutig zugeordnet.')
            continue
        if operation in {'UNINSTALL', 'PURGE'}:
            # PURGE deliberately retains its receipt after deleting the old
            # installation. Only a proven earlier, completed PURGE belongs to
            # a different lifecycle; pending journals still fail in state().
            if operation == 'PURGE':
                before = inv.get('beforeProduct')
                try:
                    times = [datetime.datetime.strptime(value, '%Y-%m-%dT%H:%M:%SZ') for value in
                             (j['startedAtUtc'], j['updatedAtUtc'],
                              installation['startedAtUtc'], installation['updatedAtUtc'])]
                except ValueError:
                    raise Refused('Entfernungsjournal enthält keine eindeutige Zeitzuordnung.') from None
                if (j['state'] == 'FINALIZED' and j['errorCode'] is None
                        and installation['fromRevision'] == 0
                        and times[0] <= times[1] < times[2] <= times[3]
                        and inv.get('root') == str(root) and inv.get('operation') == 'PURGE'
                        and inv.get('irreversible') is True
                        and isinstance(before, dict) and before.get('product') == 'BTC Trader Pro'
                        and type(before.get('revision')) is int
                        and before['revision'] == j['fromRevision'] == j['toRevision']
                        and digest(json.dumps(before, sort_keys=True).encode()) == j['artifactSha256']):
                    continue
            raise Refused('Entfernungsjournal vorhanden. Zustand gezielt prüfen lassen.')
        before, after = inv.get('beforeProduct'), inv.get('afterProduct')
        remember(before)
        if before['revision'] != j['fromRevision'] or not isinstance(after, dict) or after.get('revision') != j['toRevision']:
            raise Refused('Revisionsangaben in Journal und Inventar widersprechen sich.')
        if operation == 'UPDATE':
            if j['toRevision'] != j['fromRevision'] + 1:
                raise Refused('Updatekette ist nicht fortlaufend.')
            if j['state'] == 'FINALIZED':
                if j['fromRevision'] in updates:
                    raise Refused('Mehrdeutiger abgeschlossener Revisionsübergang.')
                remember(after)
                updates[j['fromRevision']] = (j, inv)
        else:
            if before != after or j['fromRevision'] != j['toRevision']:
                raise Refused('Wartung verändert unerwartet die Produktidentität.')
        if j['state'] == 'FINALIZED' and operation in {'UPDATE', 'REPAIR'} and j['toRevision'] == current['revision']:
            if j['artifactSha256'] != digest(checked[2]) or after != current:
                raise Refused('Aktuelles Paket ist nicht durch das abgeschlossene Operationsjournal belegt.')
    revision = receipt['revision']
    visited = {revision}
    while revision in updates:
        revision = updates[revision][0]['toRevision']
        visited.add(revision)
    if revision != current['revision'] or set(updates) != visited - {revision} or not set(revisions) <= visited:
        raise Refused('Installationsbeleg, Updatekette und aktuelle Revision passen nicht zusammen.')
    if current['revision'] == receipt['revision'] and receipt['artifactSha256'] != digest(checked[2]):
        raise Refused('Paket stimmt nicht mit dem ursprünglichen Installationsbeleg überein.')


def installed(root=ROOT, key_path=KEY, ops=OPS, folder=None, with_package=False):
    from btctrader_customer.common import strict_json, safe
    if read(key_path, 32, owned=True) != public_key():
        raise Refused('Installierte Vertrauenskette stimmt nicht mit der TEST-Kette überein.')
    current = strict_json(read(root / 'product.json', 8 * 1024**2, owned=True))
    checked = current_package(current, folder)
    journal_chain(current, checked, root, ops)
    inventory = {f['path']: f for f in checked[0]['files']}
    for name, item in inventory.items():
        # The command executes tools, not arbitrary customer/program files.
        # Repair must still be able to replace a damaged non-tool payload.
        if not name.startswith('tools/'):
            continue
        path = root / name
        data = read(path, 512 * 1024**2, owned=True)
        if len(data) != item['size'] or digest(data) != item['sha256'] or stat.S_IMODE(path.stat().st_mode) != int(item['mode'], 8):
            raise Refused('Installierte Produktdatei weicht vom signierten Inventar ab.')
    # No extra executable imports. Bytecode is never loaded by the guarded runner.
    for path in (root / 'tools').rglob('*'):
        safe(path, root)
        if path.is_dir():
            continue
        name = path.relative_to(root).as_posix()
        if '__pycache__' in path.parts and path.suffix == '.pyc':
            read(path, 8 * 1024**2, owned=True)
            continue
        if name not in inventory:
            raise Refused('Nicht inventarisierte Verwaltungsdatei vorhanden.')
    return (current, checked) if with_package else current


@contextlib.contextmanager
def execution_guard(root=ROOT, ops=OPS, key_path=KEY, exclusive=True):
    """Own the original operations lock from authentication through CLI exit.
    The runner lends this *same* exclusive lock to common.lock; no lock gap.
    Shared mode is used only for CLI actions which never acquire an EX lock.
    """
    from btctrader_customer.common import safe
    lockpath = Path('/run/lock/btctrader-operations.lock') if ops == OPS else ops / 'operations.lock'
    # Existing operations directory only. Like common.lock, recreate the
    # volatile /run lock after reboot; never truncate/reset a journal or lock.
    directory = safe(ops)
    if not directory.is_dir() or directory.stat().st_uid != 0 or directory.stat().st_mode & 0o022:
        raise Refused('Operationsverzeichnis ist nicht rootgeschützt.')
    fd = os.open(safe(lockpath), os.O_CREAT | os.O_RDWR | os.O_NOFOLLOW, 0o600)
    try:
        info = os.fstat(fd)
        if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1 or info.st_uid != 0 or info.st_mode & 0o022:
            raise Refused('Wartungssperre ist nicht rootgeschützt.')
        fcntl.flock(fd, (fcntl.LOCK_EX if exclusive else fcntl.LOCK_SH) | fcntl.LOCK_NB)
        if info.st_ino != lockpath.stat().st_ino or info.st_dev != lockpath.stat().st_dev:
            raise Refused('Wartungssperre wurde ausgetauscht.')
        yield installed(root, key_path, ops, with_package=True)
    finally:
        os.close(fd)


def invoke(path, args):
    # Inherit the terminal for age, password and pairing. No transcript or secret capture.
    result = subprocess.run(['/usr/bin/python3', '-I', '-B', str(BASE / 'runner.py'), str(path), *args])
    if result.returncode == 3:
        raise Cancelled()
    if result.returncode:
        raise Refused('Vorgang nicht erfolgreich abgeschlossen. Status erneut lesen; Journale beibehalten.')


def bootstrap(checked, resume=False):
    meta, payload, raw, signature = checked
    if 'android' not in meta:
        raise Refused('Vollständiges Installationspaket mit kompatibler Android-App erforderlich.')
    # Use only authenticated bytes in a private staging directory. No extractall.
    with tempfile.TemporaryDirectory(prefix='btctrader-setup-') as directory:
        tmp = Path(directory)
        for n, data in payload.items():
            if n.startswith('tools/'):
                target = tmp / n
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(data)
        archive = tmp / 'customer.tar.gz'
        archive.write_bytes(raw)
        sig = tmp / 'customer.tar.gz.sig'; sig.write_bytes(signature)
        key = tmp / 'release-public.key'; key.write_bytes(public_key())
        args = ['--package', str(archive), '--signature', str(sig), '--public-key', str(key)]
        if resume:
            args.append('--resume')
        invoke(tmp / 'tools/install-bootstrap.py', args)


def package_action(action, checked, root=ROOT, ops=OPS):
    status, receipt = state(root, ops)
    meta, _, raw, signature = checked
    if action == '1':
        if status != 'ABSENT' or receipt and receipt['state'] != 'FINALIZED':
            raise Refused('Keine frische Installation möglich. Bei Abbruch Installation fortsetzen wählen.')
        bootstrap(checked)
    elif action == '2':
        if status != 'UNFINISHED' or receipt['artifactSha256'] != digest(raw) or receipt['revision'] != meta['toRevision']:
            raise Refused('Resume benötigt den offenen Installationsbeleg und exakt dasselbe signierte Paket.')
        bootstrap(checked, resume=True)
    else:
        if status != 'INSTALLED':
            raise Refused('Intakte Installation erforderlich. Bei Erstinstallationsabbruch Resume verwenden.')
        current = installed(root)
        expected = meta['toRevision'] if action == '3' else meta['fromRevision']
        if expected != current['revision']:
            raise Refused('Paketrevision passt nicht: Repair gleiche Zielrevision, Update genau ein Revisionsschritt.')
        with tempfile.TemporaryDirectory(prefix='btctrader-setup-package-') as directory:
            archive = Path(directory) / 'customer.tar.gz'; archive.write_bytes(raw)
            sig = Path(str(archive) + '.sig'); sig.write_bytes(signature)
            args = ['repair' if action == '3' else 'apply', '--package', str(archive), '--signature', str(sig)]
            invoke(root / 'tools' / ('btctrader-admin' if action == '3' else 'btctrader-update'), args)
        if action == '11':
            return verify_updated(meta, root, ops)


def password_reset(root=ROOT):
    invoke(root / 'tools/btctrader-admin', ['--setup-password-reset'])


def native_password_reset(root=ROOT):
    meta = installed(root)
    # Do not create a new identity/account while advertising a reset.
    from btctrader_customer.common import safe
    for n in ['local-security/installation.json', 'local-security/password.json']:
        p = safe(root / n, root)
        if not p.is_file():
            raise Refused('Bestehende lokale Identität und Passwortdatei fehlen. Kein Passwortreset.')
    files = {x['path']: x for x in meta.get('files', [])}
    for n in ['BTC_TRADER_PRO.dll', 'BTC_TRADER_PRO.deps.json', 'BTC_TRADER_PRO.runtimeconfig.json']:
        if n not in files or digest(read(root / n, 512 * 1024**2, owned=True)) != files[n]['sha256']:
            raise Refused('Installierte Programmdateien sind nicht unverändert nachgewiesen.')
    say('Nur das BTC-Trader-Passwort wird neu gesetzt. Benutzername bleibt; bestehende Websitzungen werden ungültig.')
    say('Passwort ausschließlich im folgenden Originaldialog eingeben. Keine Aufzeichnung verwenden.')
    result = subprocess.run(['/usr/sbin/runuser', '-u', 'btctrader', '--', '/usr/bin/dotnet',
                             str(root / 'BTC_TRADER_PRO.dll'), '--set-local-password'], cwd=root)
    if result.returncode:
        raise Refused('Passwort wurde nicht erfolgreich zurückgesetzt.')


def backup_path():
    value = ask('Vollständiger Pfad der verschlüsselten Backupdatei: ').strip()
    if not value or not Path(value).is_absolute():
        raise Refused('Bitte einen vollständigen absoluten Backupdateipfad angeben.')
    return value


def admin_args(action):
    if action == '4':
        say('Download nur lokal über den bestehenden administrativen SSH-Tunnel/SFTP. Keine öffentliche Freigabe.')
        say('Beispiel SSH-Weiterleitung vom Downloadgerät: ssh -L 38084:127.0.0.1:38084 Linuxbenutzer@VPS')
        say('Im Browser dieses Geräts die anschließend angezeigte Adresse öffnen. Angebot bewusst beenden.')
        return ['apk-download', '--host', '127.0.0.1']
    if action == '5':
        host = ask('Vom Handy erreichbare VPS-Adresse: ').strip()
        if not host or host.startswith('-') or any(c.isspace() or ord(c) < 32 for c in host):
            raise Refused('Serveradresse ungültig.')
        port = ask('Vorhandener SSH-Port [22]: ').strip() or '22'
        if not port.isdecimal() or not 1 <= int(port) <= 65535:
            raise Refused('SSH-Port ungültig.')
        mode = ask('1 Erstkopplung / 2 Ersatzkopplung nach App-Neuinstallation oder Handywechsel: ').strip()
        if mode not in {'1', '2'}:
            raise Refused('Kopplungsauswahl ungültig.')
        say('Ersatzkopplung ist kein vollständiger sofortiger Widerruf bereits bestehender SSH-Tunnel.')
        say('Neuer Geräteschlüssel: bisherige bezahlte LIVE-Lizenz wird nicht übertragen. '
            'TEST und Verwaltung bleiben verfügbar.', 'warning')
        return ['pair', '--host', host, '--port', port] + (['--replacement'] if mode == '2' else [])
    if action in {'7', '8'}:
        return ['backup' if action == '7' else 'restore', backup_path()]
    if action == '9':
        mode = ask('1 Am Alt-VPS Migrationsbackup erstellen / 2 Am neuen VPS Migrationsbackup übernehmen: ').strip()
        if mode not in {'1', '2'}:
            raise Refused('Migrationsauswahl ungültig.')
        say('Alttrading muss gestoppt bleiben. Keine parallele Nutzung; am Ziel Handy erneut koppeln.')
        say('Lizenzübernahme erfordert den ursprünglichen Smartphone-Schlüssel und den '
            'unabhängig geprüften Quellanker im Originaldialog. Ohne Nachweis nur Datenrettung.', 'warning')
        return ['backup', backup_path(), '--migration-source'] if mode == '1' else ['migrate', backup_path()]
    return {'10': ['updates'], '12': ['uninstall'], '13': ['purge']}[action]


MENU_GROUPS = [
    ('INSTALLATION', [('1', 'BTC Trader Pro installieren'), ('2', 'Installation fortsetzen'),
                      ('3', 'Installation reparieren')]),
    ('ANDROID', [('4', 'Android-App herunterladen'), ('5', 'Smartphone verbinden / koppeln')]),
    ('KONTO', [('6', 'Passwort vergessen / zurücksetzen')]),
    ('DATENSICHERUNG', [('7', 'Backup erstellen'), ('8', 'Backup wiederherstellen'),
                       ('9', 'Auf neuen VPS umziehen')]),
    ('UPDATES', [('10', 'Nach Updates suchen'), ('11', 'Update installieren')]),
    ('DEINSTALLATION', [('12', 'Programm entfernen – Daten behalten'),
                       ('13', 'Programm und Daten vollständig löschen')]),
]


def show_menu():
    say('─' * min(38, width()), 'muted')
    say('BTC TRADER PRO', 'title')
    say('Installation & Verwaltung')
    say('Setup V1.2', 'muted')
    for group, items in MENU_GROUPS:
        say('')
        say(group, 'heading')
        for number, label in items:
            say(number + '. ' + label, 'error' if group == 'DEINSTALLATION' else 'normal')
    say('')
    say('0. Beenden')
    say('─' * min(38, width()), 'muted')


def discovery_feedback(info, current):
    # Interpret only the result of the existing, verified discovery CLI.
    if not isinstance(info, dict) or info.get('enabled') is not True:
        raise Refused('Updateprüfung nicht möglich. Keine gültige Updatequelle bestätigt.')
    url = info.get('baseUrl')
    latest = info.get('latestRevision')
    steps = info.get('steps')
    if (not isinstance(url, str) or urlsplit(url).scheme != 'https' or not urlsplit(url).hostname
            or type(latest) is not int or latest < current or not isinstance(steps, list)):
        raise Refused('Updateprüfung nicht möglich. Unklares Prüfergebnis.')
    expected = current
    for step in steps:
        if (not isinstance(step, dict) or type(step.get('fromRevision')) is not int
                or type(step.get('toRevision')) is not int
                or step['fromRevision'] != expected or step['toRevision'] != expected + 1):
            raise Refused('Updateprüfung nicht möglich. Unklare Revisionsfolge.')
        expected = step['toRevision']
    if expected != latest:
        raise Refused('Updateprüfung nicht möglich. Updateangebot unvollständig.')
    if latest == current and not steps:
        return 'success', 'Kein Update verfügbar. Sie verwenden die aktuelle Version.\nInstallierte Revision: ' + str(current)
    return 'success', 'Neue Version verfügbar.\nInstallierte Revision: ' + str(current) + '\nVerfügbare Revision: ' + str(latest) + '\nEs wurde kein Update installiert.'


def cache_online_packages(root=ROOT):
    from btctrader_customer.common import strict_json, safe
    current=installed(root)['revision']
    result=subprocess.run(['/usr/bin/python3','-I','-B',str(BASE/'runner.py'),str(root/'tools/btctrader-admin'),'updates'],capture_output=True,timeout=180)
    if result.returncode or len(result.stdout)>2*1024**2:raise Refused('Signierte Updatekette nicht abrufbar.')
    info=strict_json(result.stdout);discovery_feedback(info,current)
    if not info.get('enabled'):return
    st=BASE.stat()
    if st.st_uid!=0 or st.st_mode&0o022:raise Refused('Setup-Verzeichnis muss rootgeschützt sein.')
    v=verifier()
    # This only retains authenticated packages. The existing installed updater
    # performs discovery, sequence checks, transactions and health checks itself.
    for step in info['steps']:
        data=v.download(info['baseUrl'],step['package'],step['size'])
        signature=v.download(info['baseUrl'],step['signature'],64)
        meta,_=v.package(data,signature,public_key())
        if (len(data)!=step['size'] or digest(data)!=step['sha256'] or
                (meta['fromRevision'],meta['toRevision'])!=(step['fromRevision'],step['toRevision'])):
            raise Refused('Signierte Update-Paketbindung ungültig.')
        for name,content in [(step['package'],data),(step['signature'],signature)]:
            target=safe(BASE/name,BASE)
            if target.exists():
                if read(target,max(len(content),1),owned=True)!=content:raise Refused('Vorhandene Paketdatei weicht ab; nicht überschrieben.')
            else:
                with target.open('xb') as f:f.write(content)
                target.chmod(0o600)


def check_updates(root=ROOT):
    before = installed(root)['revision']
    say('Updatequelle wird geprüft …', 'warning')
    try:
        result = subprocess.run(['/usr/bin/python3', '-I', '-B', str(BASE / 'runner.py'),
                                 str(root / 'tools/btctrader-admin'), 'updates'],
                                capture_output=True, timeout=180)
        if result.returncode or len(result.stdout) > 2 * 1024**2:
            raise ValueError('unavailable')
        from btctrader_customer.common import strict_json
        info = strict_json(result.stdout)
        if installed(root)['revision'] != before:
            raise ValueError('revision changed')
        return discovery_feedback(info, before)
    except Refused:
        raise
    except Exception:
        # No raw CLI JSON, source URLs, stderr or exception texts are displayed.
        raise Refused('Updateprüfung nicht möglich. Verbindung, Updatequelle oder Prüfergebnis nicht bestätigt.') from None


def verify_updated(meta, root=ROOT, ops=OPS):
    status, _ = state(root, ops)
    current = installed(root)
    if (status != 'INSTALLED' or current['revision'] != meta['toRevision']
            or current['productVersion'] != meta['productVersion']):
        raise Refused('Updateabschluss nicht bestätigt. Installierte Revision stimmt nicht mit dem Paket überein.')
    inventory = {f['path']: f for f in current.get('files', [])}
    for item in meta['files']:
        if inventory.get(item['path']) != item or digest(read(root / item['path'], 512 * 1024**2, owned=True)) != item['sha256']:
            raise Refused('Updateabschluss nicht bestätigt. Installierte Paketdateien stimmen nicht überein.')
    return current['revision']


def dispatch(choice):
    verifier()
    status, _ = state()
    if choice == '11':
        if status != 'INSTALLED':
            raise Refused('Update benötigt einen geklärten Installationszustand. Vorhandene Journale erhalten und Wiederaufnahme prüfen.')
        method = ask('1 – Auf neueste Version aktualisieren (online) / 2 – Lokales Paket [1/2]:').strip()
        if method == '1':
            before = installed()['revision']
            cache_online_packages()
            invoke(ROOT / 'tools/btctrader-admin', ['update'])
            after = installed()['revision']
            if after < before:raise Refused('Updateabschluss nicht bestätigt: Revisionsrücklauf.')
            return 'success', 'Updateprüfung abgeschlossen. Installierte Revision: ' + str(after)
        if method != '2':return 'warning', 'Aktion abgebrochen. Kein Update gestartet.'
    if choice in {'1', '2', '3', '11'}:
        checked = choose_package()
        if choice in {'1', '2', '3'}:
            say('Der Originalinstaller kann systemweite Pakete ändern, SSH neu laden und eigene Dienste verwalten. '
                'Auf einem gemeinsam genutzten VPS zuerst Kollisionsprüfung abschließen.', 'warning')
        if ask('Ausgewählten Vorgang ausdrücklich starten? [ja/NEIN]:').strip().lower() != 'ja':
            return 'warning', 'Aktion abgebrochen. Kein Erfolg bestätigt.'
        revision = package_action(choice, checked)
        if choice == '11':
            return 'success', 'Update erfolgreich abgeschlossen.\nInstallierte Revision: ' + str(revision)
        return 'success', 'Aktion erfolgreich abgeschlossen.'
    if status != 'INSTALLED':
        raise Refused('Verwaltung benötigt eine abgeschlossene Installation. Bei Abbruch Menüpunkt 2 verwenden.')
    installed()
    if choice == '6':
        if ask('BTC-Trader-Passwort zurücksetzen? [ja/NEIN]:').strip().lower() != 'ja':
            return 'warning', 'Aktion abgebrochen. Kein Erfolg bestätigt.'
        password_reset()
        return 'success', 'Passwort erfolgreich zurückgesetzt.'
    if choice == '10':
        if ask('Updatequelle jetzt prüfen? [ja/NEIN]:').strip().lower() != 'ja':
            return 'warning', 'Updateprüfung abgebrochen.'
        return check_updates()
    args = admin_args(choice)
    if ask('Vorgang starten? [ja/NEIN]:').strip().lower() != 'ja':
        return 'warning', 'Aktion abgebrochen. Kein Erfolg bestätigt.'
    invoke(ROOT / 'tools/btctrader-admin', args)
    if args[0] == 'backup':
        from btctrader_customer.common import safe
        target = safe(Path(args[1]))
        if not target.is_file() or target.stat().st_size == 0:
            raise Refused('Datensicherung nicht bestätigt: Backupdatei fehlt oder ist leer.')
        message = 'Datensicherung erfolgreich erstellt.\nBackupdateipfad:\n' + str(target)
        if '--migration-source' in args:
            message += '\nMigrationsbackup: Alttrading bleibt gestoppt.'
        return 'success', message
    if choice == '5':
        return 'normal', 'Kopplungsdialog beendet. Bitte Verbindung in der Android-App prüfen.'
    return 'success', 'Aktion erfolgreich abgeschlossen.'


def perform(choice):
    try:
        level, message = dispatch(choice)
        say(message, level)
    except Cancelled:
        say('Aktion abgebrochen. Kein Erfolg bestätigt.', 'warning')
    except (KeyboardInterrupt, EOFError):
        say('Datensicherung fehlgeschlagen.' if choice == '7' else 'Aktion konnte nicht abgeschlossen werden.', 'error')
        say('Abgebrochen. Kein Erfolg bestätigt; Wartungszustand prüfen.', 'warning')
    except Exception as error:
        say({'7': 'Datensicherung fehlgeschlagen.', '10': 'Updateprüfung nicht möglich.'}.get(
            choice, 'Aktion konnte nicht abgeschlossen werden.'), 'error')
        if isinstance(error, Refused):
            say(str(error), 'error')
        say('Bitte prüfen Sie die angezeigte Fehlermeldung. Keine Journale löschen.', 'warning')
    try:
        ask('Enter drücken, um zum Hauptmenü zurückzukehren.')
        return True
    except (KeyboardInterrupt, EOFError):
        say('Setup beendet.', 'warning')
        return False


def main():
    if os.geteuid() != 0:
        say('Bitte mit sudo bash start.sh starten.', 'error'); return 1
    if not sys.stdin.isatty() or not sys.stdout.isatty():
        say('Ein interaktives privates Terminal ist erforderlich. Keine Sitzungsaufzeichnung verwenden.', 'error'); return 1
    while True:
        show_menu()
        try:
            status, _ = state()
            say({'UNFINISHED': 'Installation unvollständig: Resume mit demselben Paket über Menüpunkt 2.',
                 'INSTALLED': 'Vorhandene Installation erkannt.', 'ABSENT': 'Keine Installation erkannt.'}[status],
                'warning' if status == 'UNFINISHED' else 'muted')
        except Exception:
            say('Zustand nicht sicher lesbar oder Prüfabhängigkeiten fehlen. Keine Freigabe durch diese Anzeige.', 'warning')
        try:
            choice = ask('Auswahl:').strip()
            if choice == '0': return 0
            if choice not in {str(n) for n in range(1, 14)}:
                say('Bitte eine angezeigte Nummer wählen.', 'warning'); continue
            if not perform(choice): return 0
        except (KeyboardInterrupt, EOFError):
            say('Setup beendet.', 'warning'); return 0


if __name__ == '__main__':
    sys.exit(main())
