"""Interactive error boundary around existing Python CLI entry points."""
import pathlib
import runpy
import sys
import builtins
import contextlib
import importlib.abc
import importlib.util
import tempfile
import threading

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
import setup as ui


def native_run(path, args):
    path = pathlib.Path(path)
    sys.path.insert(0, str(path.parent / 'customer'))
    sys.argv = [str(path), *args]
    original_input = builtins.input
    cancelled = False

    def observed_input(prompt=''):
        nonlocal cancelled
        answer = original_input(prompt)
        # The native replacement-pairing dialog returns normally on rejection.
        # Preserve its answer and behavior, but do not report that as success.
        if prompt == 'Ersatzkopplung ausdrücklich erlauben? [ja/NEIN]: ' and answer.strip().lower() != 'ja':
            cancelled = True
        return answer

    builtins.input = observed_input
    try:
        runpy.run_path(str(path), run_name='__main__')
        return 3 if cancelled else 0
    except SystemExit as error:
        return error.code if isinstance(error.code, int) else (0 if error.code is None else 1)
    except (KeyboardInterrupt, EOFError):
        print('Vorgang abgebrochen. Kein Erfolg bestätigt; Journale beibehalten.', file=sys.stderr)
        return 1
    except Exception:
        # Never print arbitrary exception messages, paths or Python tracebacks.
        print('Vorgang fehlgeschlagen. Voraussetzungen und Wartungszustand prüfen; '
              'kein Erfolg bestätigt. Keine Journale löschen.', file=sys.stderr)
        return 1
    finally:
        builtins.input = original_input


class AuthenticatedModules(importlib.abc.MetaPathFinder, importlib.abc.Loader):
    """Execute authenticated installed Python bytes; never cached pyc files.
    This is a transient import view, not another on-disk administration tree.
    """
    def __init__(self, root, payload, https_context):
        self.root, self.payload = root, payload
        self.https_context = https_context

    def member(self, name):
        base = 'tools/customer/' + name.replace('.', '/')
        return base + '/__init__.py' if base + '/__init__.py' in self.payload else base + '.py'

    def find_spec(self, fullname, path=None, target=None):
        if fullname == 'btctrader_customer' or fullname.startswith('btctrader_customer.'):
            name = self.member(fullname)
            if name not in self.payload:
                raise ModuleNotFoundError('Unbekanntes Verwaltungsmodul')
            return importlib.util.spec_from_loader(fullname, self, is_package=name.endswith('/__init__.py'))

    def create_module(self, spec):
        return None

    def exec_module(self, module):
        name = self.member(module.__name__)
        module.__file__ = str(self.root / name)
        if name.endswith('/__init__.py'):
            module.__path__ = [str((self.root / name).parent)]
        exec(compile(self.payload[name], module.__file__, 'exec'), module.__dict__)
        if module.__name__ == 'btctrader_customer.artifacts':
            # Schemas are contract-pinned byte-identical vendor resources. Keep
            # them available when uninstall removes the installed tool tree.
            module.SCHEMAS = ui.BASE / 'vendor/btctrader_customer/schemas'
            # Older signed packages lack HTTPSConnection's context protocol.
            # Reuse only the corrected verifier's close-on-exit methods. DNS,
            # TLS, redirect, size and signature checks remain the original ones.
            for name, method in self.https_context.items():
                if not hasattr(module.PinnedHTTPS, name):
                    setattr(module.PinnedHTTPS, name, method)


@contextlib.contextmanager
def authenticated_imports(root, payload, ops, exclusive):
    https_context = {name: getattr(ui.verifier().PinnedHTTPS, name)
                     for name in ('__enter__', '__exit__')}
    names = lambda: [n for n in sys.modules if n == 'btctrader_customer' or n.startswith('btctrader_customer.')]
    previous = {n: sys.modules.pop(n) for n in names()}
    finder = AuthenticatedModules(root, payload, https_context)
    sys.meta_path.insert(0, finder)
    active = True
    borrowed = False
    owner_thread = threading.get_ident()
    try:
        from btctrader_customer import common
        original_lock = common.lock
        @contextlib.contextmanager
        def same_operation_lock(directory):
            nonlocal borrowed
            # Called only inside execution_guard. No release/reacquire window,
            # no second flock on a separate file description, no persistent patch.
            if pathlib.Path(directory).absolute() == ops.absolute():
                if not active or not exclusive or borrowed or threading.get_ident() != owner_thread:
                    raise ui.Refused('Exklusive Wartungsberechtigung fehlt oder wird bereits verwendet.')
                borrowed = True
                try:
                    yield
                finally:
                    borrowed = False
            else:
                with original_lock(directory):
                    yield
        common.lock = same_operation_lock
        yield
    finally:
        active = False
        sys.meta_path.remove(finder)
        for n in names():
            sys.modules.pop(n, None)
        sys.modules.update(previous)


def run(path, args, root=ui.ROOT, ops=ui.OPS, key_path=ui.KEY):
    path = pathlib.Path(path)
    try:
        if path == root / 'tools/btctrader-admin' or path == root / 'tools/btctrader-update':
            password = args == ['--setup-password-reset'] and path.name == 'btctrader-admin'
            shared = password or path.name == 'btctrader-admin' and args and args[0] in {'pair', 'apk-download'}
            with ui.execution_guard(root, ops, key_path, exclusive=not shared) as (_, checked):
                if password:
                    # No Python product imports or secrets are needed by the native dialog.
                    ui.native_password_reset(root)
                    return 0
                with authenticated_imports(root, checked[1], ops, not shared):
                    return native_run(path, args)
        # Only the already authenticated bootstrap has a separate staged path.
        if path.name != 'install-bootstrap.py' or len(args) not in {6, 7}:
            raise ui.Refused('Unbekannter Setup-Aufruf.')
        if args[::2][:3] != ['--package', '--signature', '--public-key'] or len(args) == 7 and args[-1] != '--resume':
            raise ui.Refused('Unbekannter Bootstrap-Vertrag.')
        checked = ui.verify_package(pathlib.Path(args[1]))
        if pathlib.Path(args[3]) != pathlib.Path(args[1] + '.sig') or pathlib.Path(args[5]).read_bytes() != ui.public_key():
            raise ui.Refused('Bootstrap-Nachweis ungültig.')
        stage = path.parent.parent
        if stage.stat().st_uid != 0 or stage.stat().st_mode & 0o077:
            raise ui.Refused('Bootstrap benötigt ein privates Root-Stagingverzeichnis.')
        for name, data in checked[1].items():
            if name.startswith('tools/') and ui.read(stage / name, 8 * 1024**2) != data:
                raise ui.Refused('Bootstrap-Dateien weichen vom signierten Paket ab.')
        # Its private staging path cannot be changed by the installed updater.
        # Ignore bytecode caches in this verified private staging tree.
        # The original installer owns its normal lock itself (no adapter).
        previous = {n: m for n, m in sys.modules.items()
                    if n == 'btctrader_customer' or n.startswith('btctrader_customer.')}
        old_prefix = sys.pycache_prefix
        old_path = list(sys.path)
        try:
            with tempfile.TemporaryDirectory(prefix='btctrader-setup-bytecode-') as cache:
                sys.pycache_prefix = cache
                for name in previous:
                    del sys.modules[name]
                return native_run(path, args)
        finally:
            sys.pycache_prefix = old_prefix
            sys.path[:] = old_path
            for name in list(sys.modules):
                if name == 'btctrader_customer' or name.startswith('btctrader_customer.'):
                    del sys.modules[name]
            sys.modules.update(previous)
    except (KeyboardInterrupt, EOFError):
        print('Aktion abgebrochen. Kein Erfolg bestätigt.', file=sys.stderr)
        return 1
    except Exception:
        print('Aktion verweigert: Paketnachweis, Verwaltungsvertrag oder Wartungszustand prüfen. '
              'Keine Journale löschen.', file=sys.stderr)
        return 1


if __name__ == '__main__':
    sys.exit(run(sys.argv[1], sys.argv[2:]))
