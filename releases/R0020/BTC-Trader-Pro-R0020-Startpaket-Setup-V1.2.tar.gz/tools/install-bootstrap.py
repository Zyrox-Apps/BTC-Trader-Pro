#!/usr/bin/env python3
"""Trusted starting-package bootstrap; standard library only until distro dependencies installed."""
import argparse,os,pathlib,subprocess,sys
p=argparse.ArgumentParser(description='BTC Trader Pro Kundeninstallation Ubuntu24.04 amd64')
p.add_argument('--repair',action='store_true');p.add_argument('--package');p.add_argument('--signature');p.add_argument('--public-key');p.add_argument('--resume',action='store_true');p.add_argument('--resume-from-package',help='Originales signiertes Paket einer abgebrochenen Erstinstallation; .sig daneben erforderlich');args=p.parse_args()
if os.geteuid()!=0:raise PermissionError('Mit sudo als lokale VM-Verwaltung starten')
location=pathlib.Path(__file__).resolve().parent;sys.path.insert(0,str(location));sys.path.insert(0,str(location/'customer'))
# OS/source validation remains a single implementation in install.preflight (imports deferred).
from btctrader_customer.install import preflight
preflight(dependencies_only=True,verification_only=True)
package=args.package or input('Signiertes Kundenpaket (.tar.gz), vollständiger Pfad: ').strip()
signature=args.signature or input('Zugehörige Ed25519-Signatur (.sig), vollständiger Pfad: ').strip()
key=args.public_key or input('Vertrauenswürdig erhaltene release-public.key, vollständiger Pfad: ').strip()
from btctrader_customer.install import Installer
if args.repair:
 from btctrader_customer.update import Updater
 trusted=pathlib.Path(key).read_bytes()
 if pathlib.Path('/usr/share/btctrader/release-public.key').read_bytes()!=trusted:raise ValueError('installed release key differs; no repair mutation')
 Updater().apply(pathlib.Path(package),pathlib.Path(signature),trusted,repair=True,before_health=lambda:Installer().repair_structure(trusted))
else:Installer().install(pathlib.Path(package),pathlib.Path(signature),pathlib.Path(key).read_bytes(),resume=args.resume,resume_from_package=pathlib.Path(args.resume_from_package) if args.resume_from_package else None)
