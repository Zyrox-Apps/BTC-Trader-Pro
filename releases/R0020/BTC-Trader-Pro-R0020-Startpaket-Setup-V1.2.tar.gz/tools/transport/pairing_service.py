#!/usr/bin/env python3
"""Customer root pairing broker; Customer transport protocol unchanged."""
import argparse,base64,hashlib,hmac,json,os,pathlib,re,socket,sqlite3,stat,struct,subprocess,sys,threading,time,uuid
from cryptography.hazmat.primitives.asymmetric import ec,rsa,padding
from cryptography.hazmat.primitives import hashes,serialization
MAX_LINE=16384
DOMAIN='BTC-TRADER-PRO/PAIR/V1\n'
LEVELS={'SOFTWARE','HARDWARE_UNSPECIFIED','TRUSTED_ENVIRONMENT','STRONGBOX','UNKNOWN'}
QR_FIELDS=['schemaVersion','purpose','pairId','sshHost','sshPort','hostKey','hostKeySha256','expiresAt','bootstrapPublic','token']
REQUEST_FIELDS=['pairId','token','devicePublic','transportPublic','deviceSecurityLevel','signature']

def encode(value):return base64.b64encode(value).decode('ascii')
def decode(value,max_bytes=2048):
 if not isinstance(value,str) or not re.fullmatch(r'[A-Za-z0-9+/]+={0,2}',value):raise ValueError('Invalid base64')
 result=base64.b64decode(value,validate=True)
 if not result or len(result)>max_bytes or encode(result)!=value:raise ValueError('Invalid encoded size')
 return result

def canonical(value):return json.dumps(value,ensure_ascii=True,separators=(',',':'))
def parse(raw):
 if isinstance(raw,bytes):raw=raw.decode('ascii')
 if len(raw)>MAX_LINE:raise ValueError('Record too large')
 def unique(pairs):
  out={}
  for key,value in pairs:
   if key in out:raise ValueError('Duplicate field')
   out[key]=value
  return out
 result=json.loads(raw,object_pairs_hook=unique)
 if not isinstance(result,dict) or canonical(result)!=raw:raise ValueError('Noncanonical record')
 return result

def fingerprint(key):return 'SHA256:'+base64.b64encode(hashlib.sha256(key).digest()).decode().rstrip('=')
def ssh_blob(key):return base64.b64decode(key.public_bytes(serialization.Encoding.OpenSSH,serialization.PublicFormat.OpenSSH).split()[1],validate=True)
def public_rsa(blob):
 fields=[];offset=0
 for _ in range(3):
  if offset+4>len(blob):raise ValueError('Truncated SSH blob')
  size=struct.unpack('>I',blob[offset:offset+4])[0];offset+=4
  if not 0<size<=1024 or offset+size>len(blob):raise ValueError('SSH field bounds')
  fields.append(blob[offset:offset+size]);offset+=size
 if offset!=len(blob) or fields[0]!=b'ssh-rsa':raise ValueError('Wrong transport key type')
 exponent=int.from_bytes(fields[1],'big',signed=True);modulus=int.from_bytes(fields[2],'big',signed=True)
 if not 2048<=modulus.bit_length()<=4096 or exponent<3 or exponent%2==0:raise ValueError('Invalid transport RSA key')
 return rsa.RSAPublicNumbers(exponent,modulus).public_key()

def signing_bytes(qr,device,transport,level):
 return (DOMAIN+qr['pairId']+'\n'+qr['sshHost']+'\n'+str(qr['sshPort'])+'\n'+qr['hostKeySha256']+'\n'+str(qr['expiresAt'])+'\n'+encode(hashlib.sha256(decode(qr['token'],32)).digest())+'\n'+device+'\n'+transport+'\n'+level+'\n').encode('ascii')

class Catalog:
 def __init__(self,path):
  self.path=pathlib.Path(path)
  if self.path.is_symlink():raise ValueError('Symlink database refused')
  self.path.parent.mkdir(parents=True,exist_ok=True)
  try:
   fd=os.open(self.path,os.O_CREAT|os.O_EXCL|os.O_WRONLY|os.O_NOFOLLOW,0o600);os.close(fd)
  except FileExistsError:
   info=self.path.lstat()
   if not stat.S_ISREG(info.st_mode) or info.st_nlink!=1:raise ValueError('Unsafe database file')
  os.chmod(self.path,0o600) # SQLite creates WAL/SHM with the already restricted DB permissions.
  with self.connect() as db:
   db.execute('PRAGMA journal_mode=WAL');db.execute('CREATE TABLE IF NOT EXISTS pending(id TEXT PRIMARY KEY, public_qr TEXT NOT NULL, token_sha256 TEXT NOT NULL, bootstrap_key TEXT NOT NULL, consumed INTEGER NOT NULL DEFAULT 0)');db.execute('CREATE TABLE IF NOT EXISTS binding(singleton INTEGER PRIMARY KEY CHECK(singleton=1), pair_id TEXT NOT NULL, device_public TEXT NOT NULL, transport_public TEXT NOT NULL, device_level_reported TEXT NOT NULL, bound_at INTEGER NOT NULL)')
  with self.connect() as db:
   db.execute('CREATE TABLE IF NOT EXISTS candidate(singleton INTEGER PRIMARY KEY CHECK(singleton=1),pair_id TEXT NOT NULL,device_public TEXT NOT NULL,transport_public TEXT NOT NULL,device_level_reported TEXT NOT NULL,bound_at INTEGER NOT NULL)')
   if 'replacement' not in {x[1] for x in db.execute('PRAGMA table_info(pending)')}:db.execute('ALTER TABLE pending ADD COLUMN replacement INTEGER NOT NULL DEFAULT 0')
   # Keep the original binding columns intact: R0011 rollback still inserts six
   # positional values. Historical pairs have no protocol marker and remain V1.
   db.execute('CREATE TABLE IF NOT EXISTS binding_protocol(pair_id TEXT PRIMARY KEY,version INTEGER NOT NULL CHECK(version=2))')
   # Preserve a previously confirmed local transport revocation when retiring the
   # old projection. Import once; no RPC/contract remains in this transport path.
   db.execute('CREATE TABLE IF NOT EXISTS transport_policy(singleton INTEGER PRIMARY KEY CHECK(singleton=1),revoked_device TEXT NOT NULL)')
   if not db.execute('SELECT 1 FROM transport_policy').fetchone():
    policy=self.path.parent/'registry-device.json';revoked=''
    if policy.exists() or policy.is_symlink():
     info=policy.lstat()
     if not stat.S_ISREG(info.st_mode) or info.st_uid!=os.geteuid() or info.st_mode&0o022:raise ValueError('Unsafe legacy transport policy')
     current=json.loads(policy.read_bytes())['devicePublic'];bound=db.execute('SELECT device_public FROM binding WHERE singleton=1').fetchone()
     if bound and current!=bound[0]:revoked=bound[0]
    db.execute('INSERT INTO transport_policy VALUES(1,?)',(revoked,))
  os.chmod(self.path,0o600)
 def connect(self):
  db=sqlite3.connect(self.path,timeout=5);db.execute('PRAGMA synchronous=FULL');return db
 def mint(self,host,port,host_blob,ttl=300,now=None,replacement=False):
  now=int(time.time()) if now is None else now
  if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9.-]{0,252}|[0-9a-fA-F:]+',host) or not 1<=port<=65535 or not 30<=ttl<=300:raise ValueError('Invalid pairing endpoint/lifetime')
  host_key=serialization.load_ssh_public_key((b'ecdsa-sha2-nistp256 ' if host_blob.startswith(struct.pack('>I',19)+b'ecdsa-sha2-nistp256') else b'ssh-rsa ')+base64.b64encode(host_blob))
  if isinstance(host_key,ec.EllipticCurvePublicKey):
   if not isinstance(host_key.curve,ec.SECP256R1):raise ValueError('Hostkey must be P256')
  elif not isinstance(host_key,rsa.RSAPublicKey) or host_key.key_size<3072:raise ValueError('Hostkey algorithm/size refused')
  ephemeral=ec.generate_private_key(ec.SECP256R1());secret=ephemeral.private_numbers().private_value.to_bytes(32,'big')
  qr=dict(zip(QR_FIELDS,[1,'BTC-TRADER-PRO-P02-PAIR',str(uuid.uuid4()),host,port,encode(host_blob),fingerprint(host_blob),now+ttl,encode(ephemeral.public_key().public_bytes(serialization.Encoding.DER,serialization.PublicFormat.SubjectPublicKeyInfo)),encode(secret)]))
  public={k:v for k,v in qr.items() if k!='token'}
  with self.connect() as db:
   db.execute('BEGIN IMMEDIATE')
   if bool(db.execute('SELECT 1 FROM binding').fetchone())!=replacement:raise ValueError('Use normal initial pairing or explicitly authorized replacement pairing')
   # Exactly one pending attempt. New operator-issued attempt revokes previous pending QR.
   db.execute('UPDATE pending SET consumed=1');db.execute('INSERT INTO pending(id,public_qr,token_sha256,bootstrap_key,replacement) VALUES(?,?,?,?,?)',(qr['pairId'],canonical(public),hashlib.sha256(secret).hexdigest(),encode(ssh_blob(ephemeral.public_key())),int(replacement)))
  return qr
 def authorize(self,blob_b64,now=None):
  now=int(time.time()) if now is None else now;decode(blob_b64)
  with self.connect() as db:
   bound=db.execute('SELECT transport_public,device_public,pair_id FROM binding WHERE singleton=1').fetchone()
   revoked=db.execute('SELECT revoked_device FROM transport_policy WHERE singleton=1').fetchone()[0]
   if bound and bound[1]!=revoked and hmac.compare_digest(bound[0],blob_b64):
    return 'restrict,port-forwarding,permitopen="127.0.0.1:8081" ssh-rsa '+blob_b64
   for public,key,used in db.execute('SELECT public_qr,bootstrap_key,consumed FROM pending'):
    qr=json.loads(public)
    # A lost PAIRED reply may be replayed within the original QR lifetime.
    # The forced broker accepts only the identical signed committed request;
    # this bootstrap key never gains forwarding or a new pairing operation.
    if (not used or bound and bound[2]==qr['pairId']) and qr['expiresAt']>now and hmac.compare_digest(key,blob_b64):return 'restrict ecdsa-sha2-nistp256 '+blob_b64
  return ''
 def pair(self,request,now=None):
  now=int(time.time()) if now is None else now
  if list(request)!=REQUEST_FIELDS or not all(isinstance(v,str) for v in request.values()) or request['deviceSecurityLevel'] not in LEVELS:raise ValueError('Wrong pairing request schema')
  token=decode(request['token'],32)
  if len(token)!=32:raise ValueError('Wrong token size')
  device_bytes=decode(request['devicePublic'],256);transport=decode(request['transportPublic'],1024);public_rsa(transport)
  device=serialization.load_der_public_key(device_bytes)
  if not isinstance(device,ec.EllipticCurvePublicKey) or not isinstance(device.curve,ec.SECP256R1):raise ValueError('Device key must be P256')
  signature=decode(request['signature'],80)
  with self.connect() as db:
   db.execute('BEGIN IMMEDIATE');row=db.execute('SELECT public_qr,token_sha256,consumed,replacement FROM pending WHERE id=?',(request['pairId'],)).fetchone()
   if row is None:raise ValueError('Unknown pairing')
   bound=db.execute('SELECT pair_id,device_public,transport_public,device_level_reported FROM binding WHERE singleton=1').fetchone()
   retry=bool(row[2] and bound==tuple(request[k] for k in ['pairId','devicePublic','transportPublic','deviceSecurityLevel']))
   if row[2] and not retry or bound and not row[3] and not retry:raise ValueError('Consumed/already bound pairing')
   qr=json.loads(row[0])
   if (qr['expiresAt']<=now and not retry) or not hmac.compare_digest(hashlib.sha256(token).hexdigest(),row[1]):raise ValueError('Expired/invalid one-time secret')
   qr['token']=request['token'];device.verify(signature,signing_bytes(qr,request['devicePublic'],request['transportPublic'],request['deviceSecurityLevel']),ec.ECDSA(hashes.SHA256()))
   if retry:return {'status':'PAIRED','pairId':request['pairId']}
   # Replacement requires an explicit root-minted one-time QR and the new device proof.
   # Replace atomically: the old transport key no longer authorizes a new SSH connection.
   if row[3]:
    db.execute('DELETE FROM binding WHERE singleton=1');db.execute('DELETE FROM candidate');db.execute("UPDATE transport_policy SET revoked_device='' WHERE singleton=1")
   db.execute('INSERT INTO binding(singleton,pair_id,device_public,transport_public,device_level_reported,bound_at) VALUES(1,?,?,?,?,?)',(request['pairId'],request['devicePublic'],request['transportPublic'],request['deviceSecurityLevel'],now));db.execute('INSERT INTO binding_protocol(pair_id,version) VALUES(?,2)',(request['pairId'],));db.execute('UPDATE pending SET consumed=1 WHERE id=?',(request['pairId'],))
  return {'status':'PAIRED','pairId':request['pairId']}

class Broker:
 """Unix-only local root broker. Checks actual peer UID before parsing one bounded request."""
 def __init__(self,catalog,path,transport_uid,transport_gid=None):self.catalog=catalog;self.path=pathlib.Path(path);self.uid=transport_uid;self.gid=transport_gid
 def serve_one(self,connection):
  try:
   _,uid,_=struct.unpack('3i',connection.getsockopt(socket.SOL_SOCKET,socket.SO_PEERCRED,12))
   if uid!=self.uid:raise PermissionError('Wrong transport peer UID')
   deadline=time.monotonic()+10;connection.settimeout(10);data=bytearray()
   while not data.endswith(b'\n'):
    remaining=deadline-time.monotonic()
    if remaining<=0:raise TimeoutError("Pairing request deadline")
    connection.settimeout(remaining);byte=connection.recv(1)
    if not byte:raise ValueError('Incomplete pairing request')
    data.extend(byte)
    if len(data)>MAX_LINE:raise ValueError('Oversized pairing request')
   answer=self.catalog.pair(parse(bytes(data[:-1])))
   connection.sendall((canonical(answer)+'\n').encode('ascii'))
  except Exception:
   # A malformed/disconnected client must not terminate the broker listener.
   try:connection.sendall(b'{"status":"REJECTED"}\n')
   except OSError:pass
  finally:connection.close()
 def listen(self,ready=None,stop=None):
  if self.path.exists() or self.path.is_symlink():raise ValueError('Never replace existing broker socket')
  sock=socket.socket(socket.AF_UNIX,socket.SOCK_STREAM)
  try:
   sock.bind(str(self.path));os.chmod(self.path,0o660)
   if self.gid is not None:os.chown(self.path,0,self.gid)
   sock.listen(4);sock.settimeout(.25)
   if ready:ready.set()
   while stop is None or not stop.is_set():
    try:connection,_=sock.accept()
    except socket.timeout:continue
    self.serve_one(connection)
  finally:sock.close();self.path.unlink(missing_ok=True)

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--database',required=True);sub=p.add_subparsers(dest='mode',required=True)
 m=sub.add_parser('mint');m.add_argument('--host',required=True);m.add_argument('--port',type=int,required=True);m.add_argument('--host-public',required=True);m.add_argument('--ttl',type=int,default=300);m.add_argument('--qr-file',required=True);m.add_argument('--qr-image',required=True);m.add_argument('--replacement',action='store_true')
 a=sub.add_parser('authorized-key');a.add_argument('--key',required=True)
 b=sub.add_parser('broker');b.add_argument('--socket',required=True);b.add_argument('--transport-uid',required=True,type=int);b.add_argument('--transport-gid',required=True,type=int)
 args=p.parse_args();catalog=Catalog(args.database)
 if args.mode=='authorized-key':
  key=catalog.authorize(args.key)
  if key:print(key)
 elif args.mode=='broker':Broker(catalog,args.socket,args.transport_uid,args.transport_gid).listen()
 else:
  public=serialization.load_ssh_public_key(pathlib.Path(args.host_public).read_bytes());qr=catalog.mint(args.host,args.port,ssh_blob(public),args.ttl,replacement=args.replacement);link='btctraderpro://pair/v1?p='+base64.urlsafe_b64encode(canonical(qr).encode()).decode().rstrip('=')
  # The QR file is an ephemeral secret, owner-only, never printed/logged or packaged.
  target=pathlib.Path(args.qr_file);fd=os.open(target,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
  with os.fdopen(fd,'w') as f:f.write(link)
  image=pathlib.Path(args.qr_image);fd=os.open(image,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
  with os.fdopen(fd,'wb') as f:
   encoded=subprocess.run(['/usr/bin/qrencode','-t','PNG','-o','-','-l','M','-s','6'],input=link.encode('ascii'),capture_output=True,check=True)
   f.write(encoded.stdout)
  print('ONE_TIME_PAIRING_QR_CREATED; expiresAt='+str(qr['expiresAt']))
if __name__=='__main__':
 try:main()
 except Exception as e:print('Customer pairing refused: '+type(e).__name__,file=sys.stderr);sys.exit(1)
