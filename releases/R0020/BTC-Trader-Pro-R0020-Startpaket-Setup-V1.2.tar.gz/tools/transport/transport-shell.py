#!/usr/bin/python3
"""Customer restricted login shell / forced command. No interactive shell, exec or SFTP."""
import json,os,socket,sys
# Fixed P06 customer installation locations.
BROKER='/run/btctrader-pairing/pairing.sock'
DONGLE='/run/btctrader-instance/proof.sock'
FORCED='/opt/btctrader/tools/transport/transport-shell.py'

def permitted(argv,original):return argv==['-c',FORCED] and original in {'btctrader-pair-v1','btctrader-dongle-v1'}
def main():
 if not permitted(sys.argv[1:],os.environ.get('SSH_ORIGINAL_COMMAND','')):return 126
 raw=sys.stdin.buffer.readline(16385)
 if len(raw)>16384 or not raw.endswith(b'\n'):return 126
 connection=socket.socket(socket.AF_UNIX,socket.SOCK_STREAM);connection.settimeout(15)
 try:
  dongle=os.environ.get('SSH_ORIGINAL_COMMAND','')=='btctrader-dongle-v1'
  connection.connect(DONGLE if dongle else BROKER);connection.sendall(raw);response=bytearray()
  while not response.endswith(b'\n'):
   byte=connection.recv(1)
   if not byte or len(response)>=4096:return 126
   response.extend(byte)
  sys.stdout.buffer.write(response);sys.stdout.buffer.flush()
  return 0 if json.loads(response).get('status') in ({'CHALLENGE','CONFIRMED'} if dongle else {'PAIRED'}) else 126
 finally:connection.close()
if __name__=='__main__':sys.exit(main())
