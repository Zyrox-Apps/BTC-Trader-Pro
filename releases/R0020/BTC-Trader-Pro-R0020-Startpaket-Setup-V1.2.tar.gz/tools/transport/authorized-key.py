#!/usr/bin/python3
"""Root-owned Customer AuthorizedKeysCommand adapter; returns constrained public keys only."""
import pathlib,sys
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parent))
from pairing_service import Catalog
if len(sys.argv)!=2:sys.exit(1)
try:
 line=Catalog('/var/lib/btctrader-pairing/pairing.db').authorize(sys.argv[1])
 if line:print(line)
except Exception:sys.exit(1)
