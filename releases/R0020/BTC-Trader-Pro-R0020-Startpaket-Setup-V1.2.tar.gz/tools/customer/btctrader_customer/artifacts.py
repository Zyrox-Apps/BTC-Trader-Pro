"""Exact-byte signature, bounded strict metadata and pre-extraction TAR validation."""
import http.client,ssl,io,ipaddress,json,pathlib,re,tarfile,urllib.parse,urllib.request,socket,datetime
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
from jsonschema import Draft202012Validator
from .common import digest,strict_json,safe,atomic
SCHEMAS=pathlib.Path(__file__).parent/'schemas'
PROTECTED={'state','local-security','license-state','installation','users','entitlement-state','logs','reports','WeeklyReports','Optimizer','backup','config.json','update-status.json','product.json','customer-v1.json','binance_credentials.enc','trading.db','analyzer.db','live_execution.db','testwallet_state.json','trading_control.json','shock_guard_up_state.json'}
def schema_validator(name):return Draft202012Validator(strict_json((SCHEMAS/(name+'.schema.json')).read_bytes()))
def schema(name,value):schema_validator(name).validate(value)
def verify(data,signature,key):
 if len(key)!=32 or len(signature)!=64:raise ValueError('signature/key size')
 Ed25519PublicKey.from_public_bytes(key).verify(signature,data)
def name(value):
 if not isinstance(value,str) or len(value)>240 or not re.fullmatch(r'[A-Za-z0-9_-][A-Za-z0-9_.-]*(/[A-Za-z0-9_-][A-Za-z0-9_.-]*)*',value) or any(x in ('.','..') for x in value.split('/')):raise ValueError('unsafe name')
 return value
def inspect_tar(data,limit=2*1024**3,output_dir=None):
 result={};total=0
 opened=tarfile.open(fileobj=io.BytesIO(data),mode='r:gz') if isinstance(data,bytes) else tarfile.open(safe(data),'r:gz')
 with opened as tar:
  for item in tar:
   n=name(item.name.rstrip('/') if item.isdir() else item.name)
   if n in result or len(result)>=20000 or item.pax_headers or item.sparse or item.mode&0o7000 or not(item.isdir() or item.isfile()) or item.size<0 or item.isdir() and item.size:raise ValueError('unsafe TAR member')
   total+=item.size
   if total>limit:raise ValueError('expanded size limit')
   if any(str(p) in result and result[str(p)] is not None for p in pathlib.PurePosixPath(n).parents if str(p)!='.') or item.isfile() and any(k.startswith(n+'/') for k in result):raise ValueError('member hierarchy')
   if item.isdir():result[n]=None;continue
   if output_dir is None:result[n]=tar.extractfile(item).read();continue
   target=safe(output_dir/n,output_dir);target.parent.mkdir(parents=True,exist_ok=True)
   with target.open('xb') as out,tar.extractfile(item) as src:
    remaining=item.size
    while remaining:
     chunk=src.read(min(65536,remaining))
     if not chunk:raise ValueError('truncated TAR')
     out.write(chunk);remaining-=len(chunk)
   target.chmod(0o600);result[n]=target
 return result
def package(data,signature,key):
 if len(data)>512*1024**2:raise ValueError('package size')
 verify(data,signature,key);entries=inspect_tar(data);files={k:v for k,v in entries.items() if v is not None}
 if not {'package.json','SHA256SUMS.txt','RELEASE.md'}<=files.keys():raise ValueError('package metadata')
 meta=strict_json(files['package.json']);schema('package',meta)
 installer=meta['minInstallerVersion']
 if not re.fullmatch(r'[0-9]+(?:\.[0-9]+){0,2}',installer) or tuple(map(int,installer.split('.')))+(0,)*(3-len(installer.split('.')))>(2,0,0):raise ValueError('installer version incompatible')
 if meta['toRevision']!=meta['fromRevision']+1:raise ValueError('revision step')
 inventory={name(x['path']):x for x in meta['files']}
 if len(inventory)!=len(meta['files']) or set(files)!= {'package.json','SHA256SUMS.txt','RELEASE.md'}|{'payload/'+x for x in inventory}:raise ValueError('payload set')
 hashes={}
 for line in files['SHA256SUMS.txt'].decode('ascii').splitlines():
  if not re.fullmatch(r'[0-9a-f]{64}  .+',line):raise ValueError('hash manifest')
  h,n=line.split('  ',1);name(n)
  if n in hashes:raise ValueError('duplicate hash')
  hashes[n]=h
 if set(hashes)!=set(files)-{'SHA256SUMS.txt'} or any(digest(files[n])!=h for n,h in hashes.items()):raise ValueError('hash set/digest')
 for path,item in inventory.items():
  if path.split('/')[0] in PROTECTED or any(x in {'state','local-security','license-state'} for x in path.split('/')):raise ValueError('protected payload')
  payload=files['payload/'+path]
  if len(payload)!=item['size'] or digest(payload)!=item['sha256']:raise ValueError('payload inventory')
 required={'BTC_TRADER_PRO.dll','BTC_TRADER_PRO.deps.json','BTC_TRADER_PRO.runtimeconfig.json','www/btctrader.html'}
 if not required<=inventory.keys():raise ValueError('incomplete FDD payload')
 if 'android' in meta:
  apk=meta['android'];p='android/'+apk['file']
  if p not in inventory or digest(files['payload/'+p])!=apk['sha256'] or len(files['payload/'+p])!=apk['size'] or not apk['minServerRevision']<=meta['toRevision']<=apk['maxServerRevision']:raise ValueError('APK binding')
 return meta,{n:files['payload/'+n] for n in inventory}
def manifest(data,signature,key,current,previous=None,now=None):
 if len(data)>1024**2:raise ValueError('manifest size')
 verify(data,signature,key);m=strict_json(data);schema('latest',m)
 now=now or datetime.datetime.now(datetime.timezone.utc)
 parse=lambda v:datetime.datetime.strptime(v,'%Y-%m-%dT%H:%M:%SZ').replace(tzinfo=datetime.timezone.utc)
 if not parse(m['publishedAtUtc'])<=now<parse(m['expiresAtUtc']):raise ValueError('manifest date')
 seq=m['manifestSequence'];hash=digest(data)
 if previous and (seq<previous['sequence'] or seq==previous['sequence'] and hash!=previous['sha256']):raise ValueError('manifest rollback')
 expected=m['minimumSupportedRevision'];steps=[]
 for x in m['updates']:
  if x['fromRevision']!=expected or x['toRevision']!=expected+1:raise ValueError('manifest gap')
  if '/' in name(x['package']) or '/' in name(x['signature']):raise ValueError('artifact basename')
  if expected>=current:steps.append(x)
  expected+=1
 if expected!=m['latestRevision'] or not m['minimumSupportedRevision']<=current<=expected:raise ValueError('unsupported revision')
 return m,steps,{'sequence':seq,'sha256':hash}
def public_url(url):
 p=urllib.parse.urlsplit(url)
 if p.scheme!='https' or not p.hostname or p.username or p.password or p.query or p.fragment or '\\' in url:raise ValueError('source URL')
 addresses=socket.getaddrinfo(p.hostname,p.port or 443,type=socket.SOCK_STREAM)
 if not addresses or any(not ipaddress.ip_address(x[4][0]).is_global for x in addresses):raise ValueError('nonpublic source')
 return p
class PinnedHTTPS(http.client.HTTPSConnection):
 def __enter__(self):return self
 def __exit__(self,exc_type,exc_value,traceback):self.close()
 def connect(self):
  addresses=socket.getaddrinfo(self.host,self.port,type=socket.SOCK_STREAM)
  if not addresses or any(not ipaddress.ip_address(a[4][0]).is_global for a in addresses):raise ValueError('nonpublic source')
  last=None
  for family,type,protocol,_,address in addresses:
   raw=socket.socket(family,type,protocol);raw.settimeout(self.timeout)
   try:
    raw.connect(address);self.sock=self._context.wrap_socket(raw,server_hostname=self.host);return
   except Exception as e:last=e;raw.close()
  raise last
def download(base,filename,limit):
 origin=public_url(base)
 if not base.endswith('/') or '/' in name(filename):raise ValueError('source/name')
 url=base+filename
 for redirects in range(4):
  p=public_url(url)
  if (p.scheme,p.hostname,p.port or 443)!=(origin.scheme,origin.hostname,origin.port or 443):raise ValueError('cross-origin redirect')
  with PinnedHTTPS(p.hostname,p.port or 443,timeout=20,context=ssl.create_default_context()) as connection:
   connection.request('GET',p.path or '/',headers={'Accept-Encoding':'identity'})
   response=connection.getresponse()
   if response.status in {301,302,303,307,308}:
    if redirects==3:raise ValueError('redirect limit')
    url=urllib.parse.urljoin(url,response.getheader('Location',''));continue
   if response.status!=200 or response.getheader('Content-Encoding','identity')!='identity':raise ValueError('HTTP response')
   length=response.getheader('Content-Length')
   if length is not None and (not length.isdigit() or int(length)>limit):raise ValueError('download length')
   data=response.read(limit+1)
   if len(data)>limit or length is not None and len(data)!=int(length):raise ValueError('download limit/truncation')
   return data
 raise ValueError('redirect limit')

def inspect_tar_files(archive,directory,limit):return inspect_tar(archive,limit,output_dir=directory)
