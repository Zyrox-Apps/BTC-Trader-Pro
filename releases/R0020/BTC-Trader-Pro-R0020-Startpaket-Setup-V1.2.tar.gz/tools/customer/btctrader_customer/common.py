"""Shared private-files/operation primitives; contains no second update engine."""
import contextlib,fcntl,hashlib,json,os,pathlib,stat,subprocess,tempfile,urllib.request,time
PRODUCT='BTC Trader Pro'
def digest(data):return hashlib.sha256(data).hexdigest()
def strict_json(data):
 def unique(pairs):
  result={}
  for k,v in pairs:
   if k in result:raise ValueError('duplicate JSON key')
   result[k]=v
  return result
 if data.startswith(b'\xef\xbb\xbf'):raise ValueError('BOM')
 return json.loads(data.decode('utf-8'),object_pairs_hook=unique,parse_constant=lambda x:(_ for _ in ()).throw(ValueError('JSON constant')))
def safe(path,root=None):
 raw=pathlib.Path(path)
 if '..' in raw.parts:raise ValueError('parent path component')
 p=raw.absolute()
 if root is not None:
  boundary=pathlib.Path(root)
  if '..' in boundary.parts:raise ValueError('parent root component')
  p.relative_to(boundary.absolute())
 for item in [p,*p.parents]:
  if item.exists() or item.is_symlink():
   st=item.lstat()
   if stat.S_ISLNK(st.st_mode):raise ValueError('symlink path')
   if item==p and stat.S_ISREG(st.st_mode) and st.st_nlink!=1:raise ValueError('hardlinked file')
 return p
def atomic(path,data,mode=0o600):
 p=safe(path);missing=[];ancestor=p.parent
 while not ancestor.exists():missing.append(ancestor);ancestor=ancestor.parent
 owner=ancestor.stat()
 for directory in reversed(missing):directory.mkdir(mode=0o755);os.chown(directory,owner.st_uid,owner.st_gid)
 safe(p.parent)
 fd,tmp=tempfile.mkstemp(prefix='.atomic-',dir=p.parent)
 try:
  os.fchmod(fd,mode)
  with os.fdopen(fd,'wb') as f:f.write(data);f.flush();os.fsync(f.fileno())
  owner=p.stat() if p.exists() else p.parent.stat();os.chown(tmp,owner.st_uid,owner.st_gid)
  os.replace(tmp,p)
  d=os.open(p.parent,os.O_DIRECTORY);os.fsync(d);os.close(d)
 finally:
  if os.path.exists(tmp):os.unlink(tmp)
def write_json(path,value):atomic(path,(json.dumps(value,separators=(',',':'))+'\n').encode())
@contextlib.contextmanager
def lock(directory):
 d=safe(directory);d.mkdir(parents=True,exist_ok=True,mode=0o700)
 lockpath=pathlib.Path('/run/lock/btctrader-operations.lock') if d==pathlib.Path('/var/lib/btctrader-operations') else d/'operations.lock'
 fd=os.open(safe(lockpath),os.O_CREAT|os.O_RDWR|os.O_NOFOLLOW,0o600)
 try:
  fcntl.flock(fd,fcntl.LOCK_EX|fcntl.LOCK_NB);yield
 finally:os.close(fd)
class System:
 def active(self):return subprocess.run(['systemctl','is-active','--quiet','btctrader.service']).returncode==0
 def stop(self):
  load=subprocess.run(['systemctl','show','btctrader.service','--property=LoadState,MainPID'],capture_output=True,text=True,check=True)
  fields=dict(line.split('=',1) for line in load.stdout.splitlines() if '=' in line)
  if fields.get('LoadState')=='not-found':return
  was_active=int(fields.get('MainPID','0'))>0;subprocess.run(['systemctl','stop','btctrader.service'],check=True)
  if was_active:
   result=subprocess.run(['systemctl','show','btctrader.service','--property=ExecMainCode,ExecMainStatus,Result'],capture_output=True,text=True,check=True)
   values=dict(line.split('=',1) for line in result.stdout.splitlines() if '=' in line)
   if values.get('Result')!='success' or values.get('ExecMainStatus')!='0':raise RuntimeError('product did not stop cleanly; maintenance refused')
 def start(self):
  # Helpers must load the same installed transport code after update or rollback.
  subprocess.run(['systemctl','try-restart','btctrader-instance.service','btctrader-pairing.service'],check=True)
  subprocess.run(['systemctl','start','btctrader.service'],check=True)
 def build_identity(self,root,revision):
  result=subprocess.run(['dotnet',str(root/'BTC_TRADER_PRO.dll'),'--build-info'],capture_output=True,check=True,text=True,timeout=20,cwd=root)
  info=strict_json(result.stdout.encode())
  capable=revision>=14
  if info['product']!=PRODUCT or info['revision']!=revision or info['realOrderSubmissionEnabled'] is not capable or info['liveExecutionRouteEnabled'] is not capable or capable and info.get('liveExecutionPolicy')!='runtime-gated-v1':raise ValueError('build identity/execution policy')
 def health(self,root,revision):
  self.build_identity(root,revision)
  end=time.monotonic()+30
  while True:
   remaining=end-time.monotonic()
   if remaining<=0:raise RuntimeError('product HTTP health unavailable')
   try:
    with urllib.request.urlopen('http://127.0.0.1:8081/api/system/identity',timeout=min(3,remaining)) as response:
     body=strict_json(response.read(16384))
     if response.status==200 and body.get('product')==PRODUCT and body.get('revision')==revision:return
   except (OSError,ValueError):pass
   remaining=end-time.monotonic()
   if remaining<=0:raise RuntimeError('product HTTP health unavailable')
   time.sleep(min(1,remaining))

def file_digest(path):
 h=hashlib.sha256()
 with safe(path).open('rb') as f:
  while b:=f.read(65536):h.update(b)
 return h.hexdigest()
def atomic_copy(path,source,mode=0o600):
 p=safe(path);source=safe(source);missing=[];ancestor=p.parent
 while not ancestor.exists():missing.append(ancestor);ancestor=ancestor.parent
 owner=ancestor.stat()
 for directory in reversed(missing):directory.mkdir(mode=0o755);os.chown(directory,owner.st_uid,owner.st_gid)
 fd,tmp=tempfile.mkstemp(prefix='.atomic-',dir=p.parent)
 try:
  os.fchmod(fd,mode)
  with os.fdopen(fd,'wb') as out,source.open('rb') as src:
   while b:=src.read(65536):out.write(b)
   out.flush();os.fsync(out.fileno())
  owner=p.stat() if p.exists() else p.parent.stat();os.chown(tmp,owner.st_uid,owner.st_gid);os.replace(tmp,p)
  fd=os.open(p.parent,os.O_DIRECTORY);os.fsync(fd);os.close(fd)
 finally:
  if os.path.exists(tmp):os.unlink(tmp)

# Public deployment facts; update ownership/key verification remains unchanged.
UPDATE_REGISTRY='0x929408E6298bed1A65Bce4dF5E8Ee0f6Fe9bE8dA'
UPDATE_REGISTRY_CODE_HASH='0x2655d4e8b999409d3fa705c3ad770098ca6e14538abb938d4e6a99885782c013'
def customer_configuration(config):
 result=dict(config)
 result.pop('RegistryAddress',None);result.pop('RegistryCodeHash',None)
 address=result.get('UpdateRegistryAddress','');pin=result.get('UpdateRegistryCodeHash','')
 if not address and not pin:
  result['UpdateRegistryAddress']=UPDATE_REGISTRY;result['UpdateRegistryCodeHash']=UPDATE_REGISTRY_CODE_HASH
 elif not address or not pin:raise ValueError('incomplete existing update registry configuration retained; repair configuration first')
 return result
