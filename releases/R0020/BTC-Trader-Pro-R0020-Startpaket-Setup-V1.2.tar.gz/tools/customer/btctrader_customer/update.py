"""The existing btctrader-update engine and its shared durable file transaction."""
import argparse,datetime,os,pathlib,shutil,uuid
from .common import safe,atomic,write_json,strict_json,lock,digest,System,file_digest,atomic_copy,customer_configuration
from .artifacts import package,schema,schema_validator,PROTECTED
class MaintenanceError(RuntimeError):
 def __init__(self,primary,recovery=None):
  self.code=primary;self.recovery_code=recovery
  super().__init__(primary if recovery is None else primary+'; '+recovery)
def protected_snapshot(root):
 result={}
 for name in sorted(PROTECTED-{'product.json','update-status.json'}):
  path=safe(root/name,root)
  if path.is_dir():
   for f in sorted(path.rglob('*')):
    safe(f,root)
    if f.is_file():
     st=f.stat();result[str(f.relative_to(root))]={'sha256':file_digest(f),'mode':st.st_mode&0o777,'uid':st.st_uid,'gid':st.st_gid}
  elif path.is_file():
   st=path.stat();result[name]={'sha256':file_digest(path),'mode':st.st_mode&0o777,'uid':st.st_uid,'gid':st.st_gid}
 return result
TERMINAL={'FINALIZED','ROLLED_BACK'}
def identity(root):return strict_json(safe(root/'product.json').read_bytes())
def utc():return datetime.datetime.now(datetime.timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')
class Updater:
 def __init__(self,root=pathlib.Path('/opt/btctrader'),operations=pathlib.Path('/var/lib/btctrader-operations'),system=None):
  self.root=safe(root);self.ops=safe(operations);self.system=system or System()
  # Removal may delete the installed schemas; retain the validator before mutation.
  self._journal_validator=schema_validator('operationsjournal')
 def journal(self,d,j):
  j['sequence']+=1;j['updatedAtUtc']=utc();self._journal_validator.validate(j);write_json(d/'journal.json',j)
 def apply(self,archive,signature,key,repair=False,before_health=None):
  raw=safe(archive).read_bytes();meta,payload=package(raw,safe(signature).read_bytes(),key)
  with lock(self.ops):
   self.recover_locked();current=identity(self.root)
   if (meta['toRevision'] if repair else meta['fromRevision'])!=current['revision']:raise ValueError('FROM revision')
   if current.get('android') and meta.get('android'):
    a=current['android'];b=meta['android']
    if a['signerCertificateSha256']!=b['signerCertificateSha256'] or b['versionCode']<a['versionCode'] or b['versionCode']==a['versionCode'] and b['sha256']!=a['sha256']:raise ValueError('APK continuity')
   android=meta.get('android') or current.get('android')
   if android and not android['minServerRevision']<=meta['toRevision']<=android['maxServerRevision']:raise ValueError('installed APK/server incompatibility')
   inventory=list(meta['files']);newpaths={x['path'] for x in inventory}
   if not meta.get('android') and current.get('android'):
    keep='android/'+current['android']['file'];inventory.extend(x for x in current.get('files',[]) if x['path']==keep);newpaths.add(keep)
   changes=[(x['path'],payload[x['path']],int(x['mode'],8)) for x in meta['files']]
   config_path=self.root/'customer-v1.json'
   if config_path.exists():
    original=strict_json(safe(config_path).read_bytes());updated=customer_configuration(original)
    if updated!=original:changes.append(('customer-v1.json',(__import__('json').dumps(updated,separators=(',',':'))+'\n').encode(),config_path.stat().st_mode&0o777))
   from .artifacts import PROTECTED
   for old in current.get('files',[]):
    if old['path'] not in newpaths:
     if old['path'].split('/')[0] in PROTECTED:raise ValueError('protected previous inventory')
     changes.append((old['path'],None,0o644))
   self.transaction_locked(changes,'REPAIR' if repair else 'UPDATE',digest(raw),current,{'product':'BTC Trader Pro','revision':meta['toRevision'],'productVersion':meta['productVersion'],'android':android,'files':inventory},before_health=before_health)
 def transaction_locked(self,changes,operation,artifact,before_product=None,after_product=None,quiesced_action=None,health=True,before_health=None,remain_stopped=False):
  """Caller already verifies inputs and owns the common lock; restores reuse this engine."""
  self.recover_locked();before_product=before_product or identity(self.root);after_product=after_product or before_product
  opid=str(uuid.uuid4());d=self.ops/opid;d.mkdir(mode=0o700);files=[]
  inventory={'files':[],'beforeProduct':before_product,'afterProduct':after_product};write_json(d/'inventory.json',inventory)
  active=self.system.active();now=utc();j={'schemaVersion':1,'operationId':opid,'operation':operation,'state':'PREPARED','sequence':0,'bootId':pathlib.Path('/proc/sys/kernel/random/boot_id').read_text().strip(),'pid':os.getpid(),'fromRevision':before_product['revision'],'toRevision':after_product['revision'],'startedAtUtc':now,'updatedAtUtc':now,'previousServiceState':'running' if active and not remain_stopped else 'stopped','artifactSha256':artifact,'inventoryFile':'inventory.json','steps':[{'name':f'file-{i:05}','status':'INTENT','beforeSha256':f['before'],'afterSha256':f['after']} for i,f in enumerate(files)],'errorCode':None};self.journal(d,j)
  phase='SERVICE_STOP'
  try:
   self.system.stop();j['state']='QUIESCED';self.journal(d,j)
   for n,data,mode in changes:
    target=safe(self.root/n,self.root);exists=target.exists();old=file_digest(target) if exists else None
    if exists:atomic_copy(d/'before'/n,target,target.stat().st_mode&0o777)
    if isinstance(data,pathlib.Path):atomic_copy(d/'after'/n,data,mode)
    elif data is not None:atomic(d/'after'/n,data,mode)
    files.append({'path':n,'before':old,'after':file_digest(d/'after'/n) if data is not None else None,'beforeMode':target.stat().st_mode&0o777 if old is not None else 0o600,'afterMode':mode})
   inventory['files']=files;write_json(d/'inventory.json',inventory)
   j['steps']=[{'name':f'file-{i:05}','status':'INTENT','beforeSha256':f['before'],'afterSha256':f['after']} for i,f in enumerate(files)]
   j['state']='APPLYING';self.journal(d,j)
   for i,f in enumerate(files):
    target=safe(self.root/f['path'],self.root)
    if f['after'] is None:target.unlink(missing_ok=True)
    else:atomic_copy(target,safe(d/'after'/f['path']),f['afterMode'])
    j['steps'][i]['status']='COMPLETE';self.journal(d,j)
   if operation=='BACKUP':
    inventory['protectedBefore']=protected_snapshot(self.root);write_json(d/'inventory.json',inventory)
   if quiesced_action:
    phase='QUIESCED_ACTION'
    result=quiesced_action()
    if operation=='BACKUP' and isinstance(result,dict):
     inventory['backupArtifact']=result;write_json(d/'inventory.json',inventory);j['artifactSha256']=result['sha256']
    elif result:j['artifactSha256']=result
   j['state']='COMMITTED';self.journal(d,j)
   if before_health:
    phase='STRUCTURE_REPAIR';inventory['structureStarted']=True;write_json(d/'inventory.json',inventory)
    before_health()
    inventory['structureCompleted']=True;write_json(d/'inventory.json',inventory)
   phase='SERVICE_HEALTH'
   if j['previousServiceState']=='running' and (health or operation=='BACKUP'):
    inventory['healthStarted']=True;write_json(d/'inventory.json',inventory);self.system.start();self.system.health(self.root,j['toRevision'])
   elif health:
    self.system.build_identity(self.root,j['toRevision'])
    inventory['onlineHealth']='NOT_RUN_PREVIOUSLY_STOPPED';write_json(d/'inventory.json',inventory)
   j['state']='HEALTH_PASSED';self.journal(d,j)
   phase='FINALIZATION';self.finish(d,j,inventory)
  except BaseException as e:
   primary=e.code if isinstance(e,MaintenanceError) else {'SERVICE_STOP':'SERVICE_STOP_FAILED','QUIESCED_ACTION':'BACKUP_OR_RESTORE_ACTION_FAILED','STRUCTURE_REPAIR':'STRUCTURE_REPAIR_FAILED','SERVICE_HEALTH':'SERVICE_HEALTH_FAILED','FINALIZATION':'FINALIZATION_FAILED'}.get(phase,'OPERATION_FAILED')
   inventory['primaryErrorPhase']=phase
   inventory['primaryErrorClass']=type(e).__name__ if type(e).__module__ in {'builtins','subprocess'} or isinstance(e,MaintenanceError) else 'OtherException'
   inventory['primaryErrorCode']=primary;write_json(d/'inventory.json',inventory)
   j['errorCode']=primary;self.journal(d,j)
   try:self.recover_operation(d,j)
   except BaseException as recovery:
    inventory['recoveryErrorClass']=type(recovery).__name__ if type(recovery).__module__ in {'builtins','subprocess'} or isinstance(recovery,MaintenanceError) else 'OtherException'
    inventory['recoveryErrorCode']='RECOVERY_FAILED';write_json(d/'inventory.json',inventory)
    failure=MaintenanceError(primary,'RECOVERY_FAILED');failure.operation_id=opid;failure.phase=phase
    raise failure from None
   failure=MaintenanceError(primary);failure.operation_id=opid;failure.phase=phase
   raise failure from None
 def finish(self,d,j,inventory):
  if j['operation']=='BACKUP':
   artifact=inventory.get('backupArtifact')
   if not artifact or file_digest(safe(artifact['path']))!=artifact['sha256'] or artifact['sha256']!=j['artifactSha256']:self.require_recovery(d,j,'backup artifact unavailable')
  write_json(self.root/'product.json',inventory['afterProduct'])
  try:
   if j['previousServiceState']=='running':
    self.system.start()
    if j['operation']=='BACKUP':self.system.health(self.root,j['toRevision'])
   else:self.system.stop()
  except Exception:self.require_recovery(d,j,'service finalization failed')
  j['state']='FINALIZED';self.journal(d,j);self.cleanup(d)
 def cleanup(self,d):
  for n in ['before','after']:
   if (d/n).exists():shutil.rmtree(safe(d/n))
 def recover_operation(self,d,j):
  if j['state']=='RECOVERY_REQUIRED':raise MaintenanceError('RECOVERY_REQUIRED')
  if j['state'] in TERMINAL:self.cleanup(d);return
  if j['operation'] in {'UNINSTALL','PURGE'}:self.require_recovery(d,j,'REMOVAL_EXPLICIT_RESUME_REQUIRED')
  if j['operation']=='INSTALL':
   self.system.stop();raise RuntimeError('installation incomplete; resume the same verified artifact with installer --resume')
  inv=strict_json(safe(d/j['inventoryFile']).read_bytes())
  if inv.get('structureStarted') and not inv.get('structureCompleted'):self.require_recovery(d,j,'STRUCTURE_REPAIR_INCOMPLETE')
  if j['state']=='HEALTH_PASSED':
   for f in inv['files']:
    target=safe(self.root/f['path'],self.root);actual=file_digest(target) if target.exists() else None
    if actual!=f['after']:self.require_recovery(d,j,'committed file differs')
   self.finish(d,j,inv);return
  if j['operation'] in {'RESTORE','MIGRATE'} and inv.get('healthStarted'):self.require_recovery(d,j,'restored service ran; retain customer state for recovery')
  self.system.stop();j['state']='ROLLING_BACK';self.journal(d,j)
  for i in reversed(range(len(inv['files']))):
   f=inv['files'][i];target=safe(self.root/f['path'],self.root);actual=file_digest(target) if target.exists() else None
   if actual not in (f['before'],f['after']):self.require_recovery(d,j,'ambiguous file')
   j['steps'][i]['status']='ROLLBACK_INTENT';self.journal(d,j)
   if f['before'] is None:target.unlink(missing_ok=True)
   else:
    old=safe(d/'before'/f['path'])
    if file_digest(old)!=f['before']:self.require_recovery(d,j,'corrupt rollback snapshot')
    atomic_copy(target,old,f['beforeMode'])
   j['steps'][i]['status']='ROLLBACK_COMPLETE';self.journal(d,j)
  write_json(self.root/'product.json',inv['beforeProduct'])
  if j['previousServiceState']=='running':
   try:
    self.system.start();self.system.health(self.root,j['fromRevision'])
   except Exception:self.require_recovery(d,j,'rollback health failed')
  j['state']='ROLLED_BACK';self.journal(d,j);self.cleanup(d)
 def require_recovery(self,d,j,error):
  j['state']='RECOVERY_REQUIRED';j['errorCode']=error;self.journal(d,j)
  try:self.system.stop()
  except Exception:raise MaintenanceError('RECOVERY_REQUIRED','SERVICE_STOP_FAILED') from None
  raise MaintenanceError('RECOVERY_REQUIRED')
 def recover_locked(self):
  for d in sorted(self.ops.iterdir()) if self.ops.exists() else []:
   if not d.is_dir():continue
   safe(d,self.ops)
   if not (d/'journal.json').exists():continue # no mutation before durable journal
   j=strict_json(safe(d/'journal.json').read_bytes());schema('operationsjournal',j)
   if j['operationId']!=d.name:raise ValueError('journal directory binding')
   if j['state']=='RECOVERY_REQUIRED':self.system.stop();raise RuntimeError('operation requires explicit recovery investigation: '+d.name)
   self.recover_operation(d,j)
 def _recover_confirmed(self,operation_id,confirmed=False,restore=False):
  if not confirmed:raise MaintenanceError('RECOVERY_CONFIRMATION_REQUIRED')
  if not __import__('re').fullmatch(r'[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}',operation_id):raise MaintenanceError('RECOVERY_ID_INVALID')
  with lock(self.ops):
   d=safe(self.ops/operation_id,self.ops);j=strict_json(safe(d/'journal.json').read_bytes());schema('operationsjournal',j)
   if j['operationId']!=operation_id or j['operation'] not in ({'RESTORE','MIGRATE'} if restore else {'BACKUP'}) or j['state']!='RECOVERY_REQUIRED':raise MaintenanceError('RECOVERY_OPERATION_STATE_REQUIRED')
   for other in self.ops.iterdir():
    if other.is_dir() and other!=d and (other/'journal.json').exists():
     previous=strict_json(safe(other/'journal.json').read_bytes());schema('operationsjournal',previous)
     if previous['operationId']!=other.name or previous['state'] not in TERMINAL:raise MaintenanceError('RECOVERY_CONFLICTING_OPERATION')
   for path in [d,d/'journal.json',safe(d/j['inventoryFile'])]:
    st=path.stat()
    if st.st_uid!=os.geteuid() or st.st_mode&0o022:raise MaintenanceError('RECOVERY_UNSAFE_JOURNAL_PERMISSIONS')
   inv=strict_json(safe(d/j['inventoryFile']).read_bytes());current=identity(self.root)
   if restore:
    # Deliberately limited forward completion: never roll back state that ran.
    # No automatic start, no waiver for changed files or unavailable evidence.
    if not inv.get('healthStarted') or inv.get('afterProduct')!=current or j['fromRevision']!=j['toRevision'] or current['revision']!=j['toRevision']:raise MaintenanceError('RECOVERY_RESTORE_EVIDENCE_INVALID')
    if self.system.active():raise MaintenanceError('RECOVERY_SERVICE_MUST_BE_STOPPED')
    if not current.get('files'):raise MaintenanceError('RECOVERY_PRODUCT_INVENTORY_MISSING')
    for f in current['files']:
     path=safe(self.root/f['path'],self.root)
     if file_digest(path)!=f['sha256'] or path.stat().st_mode&0o777!=int(f['mode'],8):raise MaintenanceError('RECOVERY_PRODUCT_CHANGED')
    for f in inv['files']:
     path=safe(self.root/f['path'],self.root);actual=file_digest(path) if path.exists() else None
     if actual!=f['after'] or actual is not None and path.stat().st_mode&0o777!=f['afterMode']:raise MaintenanceError('RECOVERY_RESTORED_STATE_CHANGED')
    from .backup import verify_state,resolve
    import sqlite3
    before=protected_snapshot(self.root)
    self.system.build_identity(self.root,j['toRevision'])
    verify_state(self.root,self.root)
    for name,path in resolve(self.root).items():
     if path.suffix in {'.db','.sqlite'}:
      with sqlite3.connect('file:'+str(path)+'?mode=ro',uri=True) as db:
       if db.execute('PRAGMA integrity_check').fetchone()[0]!='ok':raise MaintenanceError('RECOVERY_DATABASE_INVALID')
    if self.system.active() or before!=protected_snapshot(self.root) or identity(self.root)!=current:raise MaintenanceError('RECOVERY_CUSTOMER_STATE_CHANGED')
    inv['explicitRecovery']={'confirmed':True,'previousErrorCode':j['errorCode'],'verifiedAtUtc':utc(),'result':'FORWARD_VALIDATED_SERVICE_STOPPED','onlineHealth':'NOT_RUN'}
    write_json(d/'inventory.json',inv);j['state']='FINALIZED';j['errorCode']='RESTORE_OFFLINE_RECOVERY_CONFIRMED';self.journal(d,j)
    # Keep snapshots as evidence. No restored file, credential or setting is rewritten.
    return
   if inv.get('files')!=[] or j['steps'] or j['fromRevision']!=j['toRevision'] or current['revision']!=j['fromRevision'] or inv.get('beforeProduct')!=current or inv.get('afterProduct')!=current:raise MaintenanceError('RECOVERY_INVENTORY_MISMATCH')
   if not isinstance(inv.get('protectedBefore'),dict):raise MaintenanceError('RECOVERY_LEGACY_EVIDENCE_MISSING')
   if protected_snapshot(self.root)!=inv['protectedBefore']:raise MaintenanceError('RECOVERY_CUSTOMER_STATE_CHANGED')
   if not current.get('files'):raise MaintenanceError('RECOVERY_PRODUCT_INVENTORY_MISSING')
   for f in current['files']:
    path=safe(self.root/f['path'],self.root)
    if file_digest(path)!=f['sha256'] or path.stat().st_mode&0o777!=int(f['mode'],8):raise MaintenanceError('RECOVERY_PRODUCT_CHANGED')
   # Never repair permissions or run the formerly mutating validator here.
   if self.root.stat().st_mode & 0o005 != 0o005:raise MaintenanceError('RECOVERY_DIRECTORY_ACCESS')
   if j['previousServiceState']=='running':
    if not self.system.active():raise MaintenanceError('RECOVERY_SERVICE_NOT_RUNNING')
    self.system.health(self.root,j['fromRevision'])
   elif self.system.active():raise MaintenanceError('RECOVERY_SERVICE_STATE_MISMATCH')
   if protected_snapshot(self.root)!=inv['protectedBefore'] or identity(self.root)!=current:raise MaintenanceError('RECOVERY_CUSTOMER_STATE_CHANGED')
   # Retain the original journal and inventory; terminal state rejects replay.
   inv['explicitRecovery']={'confirmed':True,'previousErrorCode':j['errorCode'],'verifiedAtUtc':utc()};write_json(d/'inventory.json',inv)
   j['state']='ROLLED_BACK';j['errorCode']='BACKUP_RECOVERY_CONFIRMED';self.journal(d,j)
 def recover_backup(self,operation_id,confirmed=False):
  return self._recover_confirmed(operation_id,confirmed)
 def recover_restored(self,operation_id,confirmed=False):
  return self._recover_confirmed(operation_id,confirmed,restore=True)
 def recover(self):
  with lock(self.ops):self.recover_locked()
def main():
 p=argparse.ArgumentParser(description='BTC Trader Pro authentische sequenzielle Updates');p.add_argument('action',choices=['apply','recover']);p.add_argument('--package');p.add_argument('--signature');p.add_argument('--backup-operation');p.add_argument('--confirm-backup-recovery',action='store_true');p.add_argument('--restore-operation');p.add_argument('--confirm-restore-recovery',action='store_true');a=p.parse_args()
 if os.geteuid()!=0:raise PermissionError('root required')
 engine=Updater()
 if a.action=='recover':
  if a.backup_operation and a.restore_operation:p.error('one recovery operation at a time')
  if a.restore_operation:
   engine.recover_restored(a.restore_operation,a.confirm_restore_recovery)
   print('Wiederhergestellte Dateien offline geprüft. Dienst bleibt GESTOPPT; Online-Gesundheit und Handelsfreigabe nicht bestätigt.')
  elif a.confirm_restore_recovery:p.error('--restore-operation required')
  elif a.backup_operation:engine.recover_backup(a.backup_operation,a.confirm_backup_recovery)
  elif a.confirm_backup_recovery:p.error('--backup-operation required')
  else:engine.recover()
 else:
  if not a.package or not a.signature:p.error('package and signature required')
  engine.apply(pathlib.Path(a.package),pathlib.Path(a.signature),safe('/usr/share/btctrader/release-public.key').read_bytes())
