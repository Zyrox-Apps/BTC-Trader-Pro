"""Guided fresh installation and lifecycle management; updates delegate to btctrader-update."""
import contextlib,argparse,json,os,pathlib,pwd,grp,shutil,socket,stat,subprocess,tempfile,uuid
from .common import safe,atomic,strict_json,write_json,lock,System,digest,customer_configuration
def package(*args):
 from .artifacts import package as verify
 return verify(*args)
ROOT=pathlib.Path('/opt/btctrader');OPS=pathlib.Path('/var/lib/btctrader-operations')
def run(*args):return subprocess.run(args,check=True)
def managed_atomic(path,data,mode):
 # Fixed systemd units are only created or refreshed byte-identically.
 # A foreign/locally changed file must be reviewed, never silently overwritten.
 path=safe(path)
 if path.exists():
  info=path.stat()
  if not stat.S_ISREG(info.st_mode) or info.st_uid!=0 or info.st_gid!=0 or info.st_mode&0o022 or path.read_bytes()!=data:raise ValueError('changed system integration file retained')
 atomic(path,data,mode)
def unit_action(action,*units):
 for unit in units:
  result=subprocess.run(['systemctl','show',unit,'--property=LoadState','--value'],check=True,capture_output=True,text=True)
  state=result.stdout.strip()
  if state=='not-found':continue
  if state not in {'loaded','masked'}:raise ValueError('unexpected unit load state')
  run('systemctl',action,unit)
def preflight(dependencies_only=False,verification_only=False):
 release={}
 for line in pathlib.Path('/etc/os-release').read_text().splitlines():
  if '=' in line:k,v=line.split('=',1);release[k]=v.strip('"')
 if os.geteuid()!=0 or release.get('ID')!='ubuntu' or release.get('VERSION_ID')!='24.04' or os.uname().machine!='x86_64':raise ValueError('Ubuntu24.04 amd64/root required')
 if shutil.disk_usage('/opt').free<2*1024**3:raise ValueError('insufficient staging space')
 socket.getaddrinfo('archive.ubuntu.com',443)
 if not dependencies_only:
  with socket.socket() as s:s.bind(('127.0.0.1',8081))
 # Trust only distribution sources or the explicitly configured official Microsoft source.
 files=list(pathlib.Path('/etc/apt/sources.list.d').glob('*.sources'))+list(pathlib.Path('/etc/apt/sources.list.d').glob('*.list'))
 if pathlib.Path('/etc/apt/sources.list').exists():files.append(pathlib.Path('/etc/apt/sources.list'))
 from urllib.parse import urlsplit
 for file in files:
  text=file.read_text()
  for line in text.splitlines():
   if line.lstrip().startswith('#'):continue
   for part in line.split():
    if part.startswith(('https://','http://')):
     host=urlsplit(part).hostname
     if not(host and (host=='archive.ubuntu.com' or host.endswith('.archive.ubuntu.com') or host in {'security.ubuntu.com','packages.microsoft.com'})):raise ValueError('unapproved apt source; use Ubuntu official sources')
 if verification_only:
  # Only verification dependencies may precede authentication of the payload.
  try:__import__('cryptography');__import__('jsonschema')
  except ImportError:
   print('Installiere ausschließlich die Ubuntu-Paketprüfer; noch keine Produktinstallation.')
   run('apt-get','update');run('apt-get','install','-y','python3-cryptography','python3-jsonschema')
  return []
 run('apt-get','update');run('apt-get','install','-y','dotnet-runtime-10.0','openssh-server','python3','python3-cryptography','python3-jsonschema','qrencode','age')
 r=subprocess.run(['dotnet','--list-runtimes'],capture_output=True,text=True,check=True)
 if not any(line.startswith('Microsoft.NETCore.App 10.') for line in r.stdout.splitlines()):raise ValueError('.NET10 runtime unavailable')
 ssh=subprocess.run(['/usr/sbin/sshd','-T'],capture_output=True,text=True,check=True)
 ports=[int(line.split()[1]) for line in ssh.stdout.splitlines() if line.startswith('port ')]
 if not ports:raise ValueError('administrative SSH port unknown')
 return ports
def product_ssh_config(transport):
 return f'''Match User btctrader-app
     PasswordAuthentication no
     KbdInteractiveAuthentication no
     AuthenticationMethods publickey
     PubkeyAcceptedAlgorithms rsa-sha2-512,rsa-sha2-256,ecdsa-sha2-nistp256
     AuthorizedKeysFile none
     AuthorizedKeysCommand {transport}/authorized-key.py %k
     AuthorizedKeysCommandUser root
     AllowAgentForwarding no
     X11Forwarding no
     PermitTTY no
     PermitUserRC no
     AllowStreamLocalForwarding no
     GatewayPorts no
     AllowTcpForwarding local
     PermitOpen 127.0.0.1:8081
     PermitListen none
     ForceCommand {transport}/transport-shell.py
 Match all
 '''
def configure_product_ssh(transport,path=pathlib.Path('/etc/ssh/sshd_config.d/90-btctrader.conf'),validator=None):
 path=safe(path);data=product_ssh_config(transport).encode();previous=path.read_bytes() if path.exists() else None
 if previous is not None and previous!=data:raise ValueError('existing changed SSH product configuration retained')
 atomic(path,data,0o644)
 try:(validator or (lambda:run('/usr/sbin/sshd','-t')))()
 except BaseException:
  if previous is None:path.unlink(missing_ok=True)
  else:atomic(path,previous,0o644)
  raise

def validate_resume_replacement(previous,meta,payload,key,old_archive):
 if previous.get('operation')!='INSTALL' or previous.get('revision')!=meta['toRevision'] or previous.get('state') not in {'PRECHECK','PREPARED','QUIESCED','APPLYING','COMMITTED','HEALTH_PASSED','RECOVERY_REQUIRED'}:raise ValueError('replacement requires unfinished first installation')
 old_archive=safe(old_archive);raw=old_archive.read_bytes()
 if digest(raw)!=previous['artifactSha256']:raise ValueError('resume source package hash mismatch')
 old_meta,old_payload=package(raw,safe(str(old_archive)+'.sig').read_bytes(),key)
 if {k:v for k,v in old_meta.items() if k!='files'}!={k:v for k,v in meta.items() if k!='files'}:raise ValueError('resume replacement metadata mismatch')
 old_files={f['path']:f for f in old_meta['files']};new_files={f['path']:f for f in meta['files']}
 allowed={'tools/customer/btctrader_customer/install.py','tools/install-bootstrap.py'}
 if set(old_files)!=set(new_files) or any(old_files[n]!=new_files[n] or old_payload[n]!=payload[n] for n in old_files if n not in allowed):raise ValueError('resume replacement changes non-installer payload')
 for n in allowed:
  if n not in new_files or old_files[n]['mode']!=new_files[n]['mode']:raise ValueError('resume replacement installer inventory')
 return digest(raw)

class Installer:
 def __init__(self,root=ROOT,ops=OPS,system=None):self.root=safe(root);self.ops=safe(ops);self.system=system or System()
 def stage(self,data,signature,key):
  meta,payload=package(data,signature,key)
  if self.root.exists():raise ValueError('existing customer directory; use repair/restore')
  self.root.parent.mkdir(parents=True,exist_ok=True)
  temporary=pathlib.Path(tempfile.mkdtemp(prefix='.btctrader-install-',dir=self.root.parent))
  try:
   for item in meta['files']:atomic(temporary/item['path'],payload[item['path']],int(item['mode'],8))
   write_json(temporary/'product.json',{'product':'BTC Trader Pro','revision':meta['toRevision'],'productVersion':meta['productVersion'],'android':meta.get('android'),'files':meta['files']})
   os.chmod(temporary,0o755);os.chmod(temporary/'product.json',0o644);os.rename(temporary,self.root)
  finally:
   if temporary.exists():shutil.rmtree(temporary)
  return meta
 def install(self,archive,signature,key,resume=False,already_locked=False,repair_mode=False,resume_from_package=None):
  data=safe(archive).read_bytes();signature=safe(signature).read_bytes();meta,payload=package(data,signature,key)
  if not meta.get('android'):raise ValueError('initial installer requires compatible APK')
  installed_key=pathlib.Path('/usr/share/btctrader/release-public.key')
  if installed_key.exists() and safe(installed_key).read_bytes()!=key:raise ValueError('installed release key differs; no mutation')
  if resume_from_package is not None and (not resume or repair_mode):raise ValueError('resume-from-package requires first-install --resume')
  if not resume:self.check_accounts() # no ownership receipt for a conflicting account
  with contextlib.nullcontext() if already_locked else lock(self.ops):
   receipt=self.ops/'installation.json'
   previous=None
   if resume:
    previous=strict_json(safe(receipt).read_bytes())
    if not repair_mode:
     if previous['state']=='FINALIZED':raise ValueError('resume installation already finalized')
     if resume_from_package is not None:validate_resume_replacement(previous,meta,payload,key,resume_from_package)
     elif previous['artifactSha256']!=digest(data):raise ValueError('resume artifact/state mismatch')
   elif self.root.exists():raise ValueError('existing installation; choose repair/restore')
   from .update import Updater,utc
   engine=Updater(self.root,self.ops,self.system)
   for other in self.ops.iterdir():
    if not other.is_dir() or not (other/'journal.json').exists():continue
    from .artifacts import schema
    check=strict_json(safe(other/'journal.json',self.ops).read_bytes());schema('operationsjournal',check)
    if check['operationId']!=other.name:raise ValueError('journal binding')
    own=previous and previous.get('operationId')==other.name and check['operation']=='INSTALL'
    if check['state'] not in {'FINALIZED','ROLLED_BACK'} and not own:raise ValueError('conflicting maintenance operation')
   if resume:self.system.stop()
   opid=previous.get('operationId') if resume and not repair_mode else None
   if not opid:opid=str(uuid.uuid4())
   operation_dir=self.ops/opid;operation_dir.mkdir(mode=0o700,exist_ok=True)
   original_journal=strict_json(safe(operation_dir/'journal.json').read_bytes()) if resume and not repair_mode and (operation_dir/'journal.json').exists() else None
   if resume_from_package is not None:
    if original_journal is None or original_journal['operationId']!=opid or original_journal['operation']!='INSTALL' or original_journal['artifactSha256']!=previous['artifactSha256'] or original_journal['state']=='FINALIZED':raise ValueError('resume source journal mismatch')
    from .artifacts import schema
    schema('operationsjournal',original_journal)
    if original_journal['toRevision']!=meta['toRevision']:raise ValueError('resume source journal revision mismatch')
    history=operation_dir/'resume-history'/str(uuid.uuid4());history.mkdir(parents=True,mode=0o700)
    atomic(history/'installation.json',safe(receipt).read_bytes());atomic(history/'journal.json',safe(operation_dir/'journal.json').read_bytes())
   now=utc();j={'schemaVersion':1,'operationId':opid,'operation':'INSTALL','state':'PRECHECK','sequence':0,'bootId':pathlib.Path('/proc/sys/kernel/random/boot_id').read_text().strip(),'pid':os.getpid(),'fromRevision':identity_revision(self.root) if self.root.exists() else 0,'toRevision':meta['toRevision'],'startedAtUtc':now,'updatedAtUtc':now,'previousServiceState':'stopped','artifactSha256':digest(data),'inventoryFile':'inventory.json','steps':[{'name':'idempotent-install-structure','status':'INTENT','beforeSha256':None,'afterSha256':digest(data)}],'errorCode':None}
   if original_journal is not None:
    j['sequence']=original_journal['sequence'];j['startedAtUtc']=original_journal['startedAtUtc'];j['fromRevision']=original_journal['fromRevision']
   write_json(operation_dir/'inventory.json',{'files':[],'installerManaged':True})
   def save(state):
    j['state']=state
    if state=='FINALIZED':j['steps'][0]['status']='COMPLETE'
    engine.journal(operation_dir,j)
    write_json(receipt,{'schemaVersion':1,'operation':'INSTALL','operationId':opid,'artifactSha256':digest(data),'revision':meta['toRevision'],'state':state})
   save('PRECHECK')
   try:
    self.check_accounts(allow_existing=resume)
    ports=preflight()
    if not self.root.exists():self.stage(data,signature,key)
    elif identity_revision(self.root)!=meta['toRevision']:raise ValueError('resume revision')
    save('PREPARED');save('QUIESCED');save('APPLYING')
    if resume:
     for item in meta['files']:atomic(safe(self.root/item['path'],self.root),payload[item['path']],int(item['mode'],8))
     write_json(self.root/'product.json',{'product':'BTC Trader Pro','revision':meta['toRevision'],'productVersion':meta['productVersion'],'android':meta['android'],'files':meta['files']});os.chmod(self.root/'product.json',0o644)
    self.structure(key,fresh=not repair_mode)
    save('COMMITTED')
    run('systemctl','enable','--now','btctrader.service');self.system.health(self.root,meta['toRevision'])
    save('HEALTH_PASSED');save('FINALIZED')
    print('Installation bereit. TEST bleibt lizenzfrei. Keine automatische LIVE-Aktivierung.')
    print('APK SHA256: '+meta['android']['sha256']);print('APK Signer SHA256: '+meta['android']['signerCertificateSha256'])
    print('Nächste Schritte: btctrader-admin (geführte lokale Verwaltung: APK, Pairing, Update, Backup).')
    print('APK-SFTP-Pfad: '+str(self.root/'android'/meta['android']['file']))
    print('Vorhandene SSH-Ports: '+','.join(map(str,ports)))
   except BaseException:
    j['errorCode']='INSTALLATION_FAILED';save('RECOVERY_REQUIRED')
    try:self.system.stop()
    except Exception:
     j['errorCode']='INSTALLATION_AND_STOP_FAILED';save('RECOVERY_REQUIRED')
    raise
 def check_accounts(self,allow_existing=False):
  for name in ['btctrader','btctrader-app']:
   try:pwd.getpwnam(name)
   except KeyError:continue
   if not allow_existing:
    owned=False
    for receipt in self.ops.glob('*/journal.json'):
     from .artifacts import schema
     j=strict_json(safe(receipt,self.ops).read_bytes());schema('operationsjournal',j)
     if j['operation']!='PURGE' or j['state']!='FINALIZED' or j['operationId']!=receipt.parent.name:continue
     inv=strict_json(safe(receipt.parent/j['inventoryFile'],self.ops).read_bytes());account=pwd.getpwnam(name)
     if inv.get('root')==str(self.root) and inv.get('accounts',{}).get(name)==[account.pw_uid,account.pw_gid]:owned=True
    if not owned:raise ValueError('reserved account exists without verified resume/repair')
   self.validate_account(name)
 def validate_account(self,name):
  account=pwd.getpwnam(name);group=grp.getgrgid(account.pw_gid)
  allowed_shells={'/usr/sbin/nologin'}
  if name=='btctrader-app':allowed_shells.add(str(self.root/'tools/transport/transport-shell.py'))
  if not 0<account.pw_uid<1000 or not 0<account.pw_gid<1000 or group.gr_name!=name or account.pw_dir!='/nonexistent' or account.pw_shell not in allowed_shells:raise ValueError('reserved account collision')
  if any(g.gr_gid!=account.pw_gid and name in g.gr_mem for g in grp.getgrall()):raise ValueError('reserved account supplementary privileges')
  return account
 def repair_structure(self,key):
  # Called only inside the existing REPAIR transaction and common lock.
  self.check_accounts(allow_existing=True)
  preflight(dependencies_only=True)
  self.structure(key)
 def structure(self,key,fresh=False):
  for user in ['btctrader','btctrader-app']:
   try:pwd.getpwnam(user)
   except KeyError:run('useradd','--system','--user-group','--no-create-home','--home-dir','/nonexistent','--shell','/usr/sbin/nologin',user)
   self.validate_account(user)
  user=pwd.getpwnam('btctrader')
  root=safe(self.root)
  if root.stat().st_uid!=0 or root.stat().st_gid!=0:raise ValueError('unexpected product root owner')
  os.chmod(root,0o755)
  private=[]
  for directory in ['state','local-security','license-state','logs','reports','WeeklyReports','Optimizer','backup']:
   d=safe(self.root/directory,self.root)
   if d.exists() and (not d.is_dir() or d.stat().st_uid not in {0,user.pw_uid} or d.stat().st_gid not in {0,user.pw_gid}):raise ValueError('unexpected private directory owner/type')
   # Validate the complete known private tree before repairing its permissions.
   # Never follow a link or take ownership of an unrelated user's files.
   if d.exists():
    for entry in d.rglob('*'):
     entry=safe(entry,self.root);info=entry.lstat()
     if not (stat.S_ISDIR(info.st_mode) or stat.S_ISREG(info.st_mode)) or info.st_uid not in {0,user.pw_uid} or info.st_gid not in {0,user.pw_gid}:raise ValueError('unexpected private entry owner/type')
     private.append((entry,0o700 if stat.S_ISDIR(info.st_mode) else 0o600))
  for directory in ['state','local-security','license-state','logs','reports','WeeklyReports','Optimizer','backup']:
   d=safe(self.root/directory,self.root)
   d.mkdir(mode=0o700,exist_ok=True);os.chown(d,user.pw_uid,user.pw_gid);os.chmod(d,0o700)
  for entry,mode in private:
   safe(entry,self.root);os.chown(entry,user.pw_uid,user.pw_gid);os.chmod(entry,mode)
  # Deployment addresses are supplied only from checked deployment, never guessed.
  config_path=self.root/'customer-v1.json'
  config=strict_json(safe(config_path).read_bytes()) if config_path.exists() else {'Version':1,'ReleasePublicKey':key.hex()}
  write_json(config_path,customer_configuration(config))
  os.chmod(self.root/'customer-v1.json',0o644)
  if not (self.root/'config.json').exists():write_json(self.root/'config.json',{'TestWallet':True,'AllowLiveBuyReBuy':False,'AllowLiveSell':False,'WebServerEnabled':True,'WebServerHost':'127.0.0.1','WebServerPort':8081})
  config_file=safe(self.root/'config.json',self.root)
  local_config=strict_json(config_file.read_bytes())
  if local_config.get('WebServerHost','127.0.0.1')!='127.0.0.1' or local_config.get('WebServerPort',8081)!=8081 or not local_config.get('WebServerEnabled',True):raise ValueError('customer loopback configuration required')
  os.chown(self.root/'config.json',user.pw_uid,user.pw_gid);os.chmod(self.root/'config.json',0o600)
  keypath=pathlib.Path('/usr/share/btctrader/release-public.key')
  if keypath.exists() and safe(keypath).read_bytes()!=key:raise ValueError('installed release key differs; retained')
  atomic(keypath,key,0o644)
  transport=self.root/'tools'/'transport'
  if not (transport/'pairing_service.py').is_file():raise ValueError('transport payload missing')
  run('usermod','--shell',str(transport/'transport-shell.py'),'btctrader-app')
  # Publickey-only account must be usable without enabling password authentication.
  run('usermod','--password','*','btctrader-app')
  atomic('/usr/local/bin/btctrader-update',(self.root/'tools'/'btctrader-update').read_bytes(),0o755)
  atomic('/usr/local/bin/btctrader-admin',(self.root/'tools'/'btctrader-admin').read_bytes(),0o755)
  self.units(user)
  managed_atomic('/etc/systemd/system/btctrader-discovery.service',b'[Unit]\nAfter=network-online.target\n[Service]\nType=oneshot\nExecStart=/usr/local/bin/btctrader-admin updates\nUMask=0077\n',0o644)
  managed_atomic('/etc/systemd/system/btctrader-discovery.timer',b'[Unit]\nDescription=BTC Trader Pro Updatehinweise\n[Timer]\nOnBootSec=120\nOnUnitActiveSec=3600\n[Install]\nWantedBy=timers.target\n',0o644)
  sshfile=pathlib.Path('/etc/ssh/sshd_config.d/90-btctrader.conf')
  configure_product_ssh(transport)
  run('systemctl','reload','ssh');run('systemctl','daemon-reload')
  from .instance import prepare_installation
  installation=prepare_installation('/var/lib/btctrader-instance',self.root,fresh)
  run('runuser','-u','btctrader','--','dotnet',str(self.root/'BTC_TRADER_PRO.dll'),'--initialize-customer-identity',installation)
  # Existing hostkeys and administrative SSH ports are retained.
  run('systemctl','enable','--now','btctrader-instance.service','btctrader-pairing.service','btctrader-discovery.timer')
  if not (self.root/'local-security/password.json').exists():
   print('Lokales Webpasswort jetzt eingeben; kein SSH- oder Binance-Passwort.')
   run('runuser','-u','btctrader','--','dotnet',str(self.root/'BTC_TRADER_PRO.dll'),'--set-local-password')
 def units(self,user):
  base='[Unit]\nAfter=network-online.target\nWants=network-online.target\n[Service]\n'
  product=base+f'User=btctrader\nGroup=btctrader\nWorkingDirectory={self.root}\nExecStart=/usr/bin/dotnet {self.root}/BTC_TRADER_PRO.dll\nRestart=on-failure\nUMask=0077\nNoNewPrivileges=true\n[Install]\nWantedBy=multi-user.target\n'
  instance=base+f'ExecStart=/usr/local/bin/btctrader-admin instance\nRuntimeDirectory=btctrader-instance\nUMask=0077\n[Install]\nWantedBy=multi-user.target\n'
  transport=pwd.getpwnam('btctrader-app')
  pairing=base+f'ExecStart=/usr/bin/python3 {self.root}/tools/transport/pairing_service.py --database /var/lib/btctrader-pairing/pairing.db broker --socket /run/btctrader-pairing/pairing.sock --transport-uid {transport.pw_uid} --transport-gid {transport.pw_gid}\nRuntimeDirectory=btctrader-pairing\nUMask=0077\n[Install]\nWantedBy=multi-user.target\n'
  for name,content in [('btctrader',product),('btctrader-instance',instance),('btctrader-pairing',pairing)]:managed_atomic('/etc/systemd/system/'+name+'.service',content.encode(),0o644)
 def uninstall(self,purge=False,resume=False):
  from .update import Updater,utc,MaintenanceError,TERMINAL
  from .artifacts import schema,PROTECTED,name
  with lock(self.ops):
   operation='PURGE' if purge else 'UNINSTALL';engine=Updater(self.root,self.ops,self.system)
   pending=[]
   for directory in self.ops.iterdir():
    if not directory.is_dir() or not (directory/'journal.json').exists():continue
    journal=strict_json(safe(directory/'journal.json',self.ops).read_bytes());schema('operationsjournal',journal)
    if journal['operationId']!=directory.name:raise MaintenanceError('REMOVAL_JOURNAL_BINDING')
    if journal['state'] not in TERMINAL:pending.append((directory,journal))
   if pending and (not resume or len(pending)!=1 or pending[0][1]['operation']!=operation):raise MaintenanceError('RECOVERY_REQUIRED')
   if resume and not pending:raise MaintenanceError('REMOVAL_RESUME_NOT_FOUND')
   sshfile=safe('/etc/ssh/sshd_config.d/90-btctrader.conf')
   if sshfile.exists() and sshfile.read_bytes()!=product_ssh_config(self.root/'tools/transport').encode():raise ValueError('changed SSH configuration retained')
   if purge and input('Alle BTC-Trader-Kundendaten endgültig löschen? Tippe PURGE: ')!='PURGE':raise ValueError('purge not confirmed')
   if pending:
    operation_dir,j=pending[0];inventory=strict_json(safe(operation_dir/j['inventoryFile']).read_bytes())
    if inventory.get('root')!=str(self.root) or inventory.get('operation')!=operation:raise MaintenanceError('REMOVAL_INVENTORY_MISMATCH')
    product=inventory['beforeProduct']
    if digest(json.dumps(product,sort_keys=True).encode())!=j['artifactSha256']:raise MaintenanceError('REMOVAL_INVENTORY_MISMATCH')
    if self.root.exists() and (self.root/'product.json').exists() and strict_json(safe(self.root/'product.json').read_bytes())!=product:raise MaintenanceError('REMOVAL_PRODUCT_CHANGED')
    if purge:
     accounts=inventory.get('accounts')
     if not isinstance(accounts,dict) or set(accounts)-{'btctrader','btctrader-app'}:raise MaintenanceError('REMOVAL_ACCOUNT_BINDING')
     for name_ in ['btctrader','btctrader-app']:
      binding=accounts.get(name_)
      if name_ in accounts and (not isinstance(binding,list) or len(binding)!=2 or any(type(value) is not int or not 0<value<1000 for value in binding)):raise MaintenanceError('REMOVAL_ACCOUNT_BINDING')
      try:pwd.getpwnam(name_)
      except KeyError:
       if name_ in accounts:raise MaintenanceError('REMOVAL_ACCOUNT_BINDING')
       continue
      if name_ not in accounts:raise MaintenanceError('REMOVAL_ACCOUNT_BINDING')
      try:account=self.validate_account(name_)
      except KeyError:raise MaintenanceError('REMOVAL_ACCOUNT_BINDING') from None
      if binding!=[account.pw_uid,account.pw_gid]:raise MaintenanceError('REMOVAL_ACCOUNT_BINDING')
   else:
    product=strict_json(safe(self.root/'product.json').read_bytes())
    opid=str(uuid.uuid4());operation_dir=self.ops/opid;operation_dir.mkdir(mode=0o700)
    accounts={}
    for name_ in ['btctrader','btctrader-app']:
     try:account=pwd.getpwnam(name_)
     except KeyError:continue
     self.validate_account(name_);accounts[name_]=[account.pw_uid,account.pw_gid]
    inventory={'root':str(self.root),'operation':operation,'beforeProduct':product,'files':[],'irreversible':purge,'accounts':accounts}
    write_json(operation_dir/'inventory.json',inventory)
    now=utc();j={'schemaVersion':2,'operationId':opid,'operation':operation,'state':'PREPARED','sequence':0,'bootId':pathlib.Path('/proc/sys/kernel/random/boot_id').read_text().strip(),'pid':os.getpid(),'fromRevision':product['revision'],'toRevision':product['revision'],'startedAtUtc':now,'updatedAtUtc':now,'previousServiceState':'running' if self.system.active() else 'stopped','artifactSha256':digest(json.dumps(product,sort_keys=True).encode()),'inventoryFile':'inventory.json','steps':[],'errorCode':None}
   for item in product.get('files',[]):
    n=name(item['path'])
    if n.split('/')[0] in PROTECTED:raise MaintenanceError('REMOVAL_PROTECTED_INVENTORY')
    path=safe(self.root/n,self.root)
    if path.exists() and digest(path.read_bytes())!=item['sha256']:raise MaintenanceError('REMOVAL_PRODUCT_CHANGED')
   j['state']='PREPARED';engine.journal(operation_dir,j)
   try:
    self.system.stop();j['state']='QUIESCED';engine.journal(operation_dir,j)
    self.remove_structure(purge,sshfile,operation_dir)
    j['state']='FINALIZED';j['errorCode']=None;engine.journal(operation_dir,j)
   except BaseException:
    j['state']='RECOVERY_REQUIRED';j['errorCode']='REMOVAL_INCOMPLETE';engine.journal(operation_dir,j)
    try:self.system.stop()
    except Exception:
     j['errorCode']='REMOVAL_AND_STOP_FAILED';engine.journal(operation_dir,j)
    error=MaintenanceError('REMOVAL_INCOMPLETE');error.operation_id=j['operationId'];error.phase='REMOVAL'
    raise error from None
 def remove_structure(self,purge,sshfile,operation_dir):
  self.system.stop();unit_action('disable','btctrader.service')
  unit_action('stop','btctrader-instance.service','btctrader-pairing.service','btctrader-discovery.service','btctrader-discovery.timer')
  unit_action('disable','btctrader-instance.service','btctrader-pairing.service','btctrader-discovery.timer')
  previous=sshfile.read_bytes() if sshfile.exists() else None
  sshfile.unlink(missing_ok=True)
  try:run('/usr/sbin/sshd','-t');run('systemctl','reload','ssh')
  except BaseException:
   if previous is not None:atomic(sshfile,previous,0o644)
   raise
  for n in ['btctrader','btctrader-instance','btctrader-pairing','btctrader-discovery']:pathlib.Path('/etc/systemd/system/'+n+'.service').unlink(missing_ok=True)
  pathlib.Path('/etc/systemd/system/btctrader-discovery.timer').unlink(missing_ok=True)
  run('systemctl','daemon-reload')
  if purge:
   
   if self.root.exists():shutil.rmtree(safe(self.root))
   for external in ['/var/lib/btctrader-pairing','/var/lib/btctrader-instance']:
    path=safe(external)
    if path.exists():shutil.rmtree(path)
   # Restore/repair snapshots may contain customer secrets; full purge includes them.
   # Keep only this non-secret removal receipt; erase old secret snapshots.
   for entry in self.ops.iterdir():
    if entry==operation_dir or entry.name=='operations.lock':continue
    safe(entry,self.ops)
    if entry.is_dir():shutil.rmtree(entry)
    else:entry.unlink()
   for file in ['/usr/local/bin/btctrader-update','/usr/local/bin/btctrader-admin','/usr/share/btctrader/release-public.key']:safe(file).unlink(missing_ok=True)
  else:
   from .artifacts import PROTECTED
   meta=strict_json(safe(self.root/'product.json').read_bytes())
   for item in meta.get('files',[]):
    n=item['path']
    if n.split('/')[0] in PROTECTED:raise ValueError('protected uninstall inventory')
    safe(self.root/n,self.root).unlink(missing_ok=True)
   for file in ['/usr/local/bin/btctrader-update','/usr/local/bin/btctrader-admin']:safe(file).unlink(missing_ok=True)
   print('Deinstalliert; Kundendaten und Identity bleiben unter '+str(self.root))

def identity_revision(root):return strict_json(safe(root/'product.json').read_bytes())['revision']
