"""Explicitly opened, operator-closed APK download. Never shares a directory."""
import hashlib,http.server,re,secrets,shutil,socket,subprocess,sys,threading
from .common import safe

def serve(apk,bind,port=38084,advertised_host=None,*,expected_sha256,expected_size):
 # APK first trust must use the existing authenticated administrative SSH path.
 if bind!='127.0.0.1':raise ValueError('APK_LOOPBACK_REQUIRED')
 host='127.0.0.1'

 apk=safe(apk)
 if apk.suffix!='.apk' or not 0<expected_size<=64*1024**2 or apk.stat().st_size!=expected_size:raise ValueError('APK-Größe ungültig; Download nicht geöffnet.')
 data=apk.read_bytes()
 if hashlib.sha256(data).hexdigest()!=expected_sha256:raise ValueError('APK-Integrität ungültig; Download nicht geöffnet.')
 route='/'+secrets.token_urlsafe(24)+'.apk';closed=threading.Event();active=set();guard=threading.Lock()
 class Handler(http.server.BaseHTTPRequestHandler):
  def setup(self):
   super().setup();self.connection.settimeout(3)
   with guard:active.add(self.connection)
  def finish(self):
   try:super().finish()
   finally:
    with guard:active.discard(self.connection)
  def log_message(self,*args):pass
  def do_GET(self):
   if closed.is_set() or self.path!=route:self.send_error(404);return
   try:
    self.send_response(200);self.send_header('Content-Type','application/vnd.android.package-archive');self.send_header('Content-Length',str(len(data)));self.send_header('Cache-Control','no-store');self.end_headers();self.wfile.write(data)
   except (BrokenPipeError,ConnectionResetError,TimeoutError,OSError):pass
 class Server(http.server.ThreadingHTTPServer):
  daemon_threads=True
 with Server((bind,port),Handler) as server:
  url=f'http://{host}:38084{route}'
  print('APK nur lokal erreichbar. Auf dem Handy einen administrativen SSH-Tunnel öffnen:')
  print('ssh -N -o ExitOnForwardFailure=yes -L 38084:127.0.0.1:'+str(server.server_port)+' Ihr-bestehender-SSH-Login')
  print('Loginangabe ersetzen; Hostkey wie beim bisherigen administrativen Zugang prüfen. Alternativ SFTP verwenden.')
  print('APK SHA256: '+expected_sha256)
  print('Nur die geprüfte TEST-APK wird angeboten; keine privaten Dateien und keine Pairingrechte.')
  print('Downloadlink: '+url)
  encoded=subprocess.run(['qrencode','-t','ANSIUTF8','-l','M','-m','4'],input=url.encode('ascii'),capture_output=True,check=True).stdout.decode('utf-8')
  lines=re.sub(r'\x1b\[[0-9;]*m','',encoded).splitlines();columns,rows=shutil.get_terminal_size(fallback=(80,24))
  if sys.stdout.isatty() and max(map(len,lines),default=0)<columns and len(lines)<=rows-8:print(encoded,end='')
  else:print('QR passt nicht vollständig ins Terminal. Obigen Link auf dem Handy öffnen; es wird kein QR abgeschnitten.')
  thread=threading.Thread(target=server.serve_forever,kwargs={'poll_interval':.2},daemon=True);thread.start()
  try:input('Download bleibt ohne Zeitlimit offen. Nach dem Herunterladen Enter drücken, um den Zugang zu schließen: ')
  finally:
   closed.set();server.shutdown()
   with guard:
    for connection in list(active):
     try:connection.shutdown(socket.SHUT_RDWR);connection.close()
     except OSError:pass
   thread.join(timeout=5)
 print('APK-Download geschlossen; temporärer Listener beendet.')
