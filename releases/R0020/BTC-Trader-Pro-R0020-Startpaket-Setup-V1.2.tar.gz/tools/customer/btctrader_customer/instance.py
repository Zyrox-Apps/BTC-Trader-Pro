"""Root-only external installation anchor. Service peer receives nonce-scoped proof only."""
import threading,argparse,base64,hashlib,json,os,pathlib,pwd,re,socket,sqlite3,struct,time,stat,secrets,fcntl,contextlib,subprocess
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives import hashes,serialization
from .common import safe,atomic,strict_json
DOMAIN=b'BTCINSTANCE1\n'
# Public deployment facts, identical to V2IntegrationFacts. No payment RPC here.
DONGLE_DOMAIN=b'BTC-TRADER-PRO/DONGLE/V1\n'
STATUS_DOMAIN=b'BTC-TRADER-PRO/DONGLE-STATUS/V1\n'
MAINTENANCE_DOMAIN=b'BTC-TRADER-PRO/MAINTENANCE-STATUS/V1\n'
STATE_DOMAIN=b'BTC-TRADER-PRO/DONGLE-STATE/V1\n'
TRANSFER_DOMAIN=b'BTC-TRADER-PRO/DONGLE-TRANSFER/V1\n'
CHAIN=8453
HUB='0xc2bb5c332d8782560575a2857b698c37b290fa93'
PRODUCT='eff49021129643a33bfed20154477f37e97bcce5f507725eb6a200d6038def2c'
LEASE_SECONDS=30*24*60*60
CHALLENGE_SECONDS=120
def encoded(data):return base64.b64encode(data).decode('ascii')
def canonical(value):return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=True).encode('ascii')
def public_bytes(key):return key.public_bytes(serialization.Encoding.DER,serialization.PublicFormat.SubjectPublicKeyInfo)
def device_key(value):
 raw=base64.b64decode(value,validate=True)
 if len(raw)>256 or encoded(raw)!=value:raise ValueError('DONGLE_KEY')
 key=serialization.load_der_public_key(raw)
 if not isinstance(key,ec.EllipticCurvePublicKey) or not isinstance(key.curve,ec.SECP256R1) or public_bytes(key)!=raw:raise ValueError('DONGLE_KEY')
 return key
def reference(device,salt):
 point=device_key(device).public_bytes(serialization.Encoding.X962,serialization.PublicFormat.UncompressedPoint)
 if not re.fullmatch('0x[0-9a-f]{64}',salt):raise ValueError('DONGLE_SALT')
 return '0x'+hashlib.sha256(b'BTC-TRADER-PRO-LICENSE-V1'+CHAIN.to_bytes(32,'big')+bytes.fromhex(HUB[2:])+bytes.fromhex(PRODUCT)+point+bytes.fromhex(salt[2:])).hexdigest()
def verify_transfer(proof,expected_anchor,installation,backup_id):
 raw=base64.b64decode(proof['payload'],validate=True);pub=base64.b64decode(proof['public'],validate=True)
 if not re.fullmatch('[0-9a-f]{64}',expected_anchor) or hashlib.sha256(pub).hexdigest()!=expected_anchor:raise ValueError('DONGLE_SOURCE_TRUST')
 device_key(proof['public']).verify(base64.b64decode(proof['signature'],validate=True),TRANSFER_DOMAIN+raw,ec.ECDSA(hashes.SHA256()))
 p=strict_json(raw);validate_binding(p['binding'])
 if p['version']!=1 or p['purpose']!='migration' or p['backupId']!=backup_id or p['sourceAnchor']!=expected_anchor or p['sourceInstallation']==installation:raise ValueError('DONGLE_TRANSFER_CONTEXT')
 return p

def binding(device):
 salt='0x'+secrets.token_hex(32)
 return {'Version':1,'PaymentLicenseReference':reference(device,salt),'InitialDevicePublic':device,'Salt':salt}
def validate_binding(value):
 if set(value)!={'Version','PaymentLicenseReference','InitialDevicePublic','Salt'} or value['Version']!=1 or reference(value['InitialDevicePublic'],value['Salt'])!=value['PaymentLicenseReference']:raise ValueError('DONGLE_BINDING')
 return value

def maintenance_lock(operations=pathlib.Path('/var/lib/btctrader-operations'),lockpath=pathlib.Path('/run/lock/btctrader-operations.lock')):
 """Own the EXISTING maintenance lock until the caller closes its descriptor."""
 from .artifacts import schema
 directory=safe(operations);lp=safe(lockpath)
 for path in (directory,lp):
  st=path.stat()
  if st.st_uid!=os.geteuid() or st.st_mode&0o022:raise ValueError('MAINTENANCE_PERMISSIONS')
 fd=os.open(lp,os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC)
 try:
  st=os.fstat(fd)
  if not stat.S_ISREG(st.st_mode) or st.st_nlink!=1:raise ValueError('MAINTENANCE_LOCK_FILE')
  fcntl.flock(fd,fcntl.LOCK_SH|fcntl.LOCK_NB)
  for d in directory.iterdir():
   safe(d,directory)
   if not d.is_dir():continue
   path=d/'journal.json'
   if not path.exists():continue
   for item in (d,safe(path,directory)):
    st=item.stat()
    if st.st_uid!=os.geteuid() or st.st_mode&0o022:raise ValueError('MAINTENANCE_JOURNAL_PERMISSIONS')
   st=path.stat()
   if not stat.S_ISREG(st.st_mode) or st.st_size>1048576:raise ValueError('MAINTENANCE_JOURNAL_FILE')
   journal=strict_json(path.read_bytes());schema('operationsjournal',journal)
   if journal['operationId']!=d.name or journal['state'] not in {'FINALIZED','ROLLED_BACK'}:raise ValueError('MAINTENANCE_JOURNAL_ACTIVE')
  return fd
 except BaseException:
  os.close(fd);raise

def maintenance_clear(operations=pathlib.Path('/var/lib/btctrader-operations'),lockpath=pathlib.Path('/run/lock/btctrader-operations.lock')):
 try:
  fd=maintenance_lock(operations,lockpath);os.close(fd);return True
 except Exception:return False

class DongleState:
 """Authoritative state in the existing external anchor directory, never a portable grant.

 All mutations take the same filesystem lock. Product data and clock are not trust roots.
 The existing root helper is the only online writer; no additional daemon/database.
 """
 def __init__(self,directory,key,clock=time.time,monotonic=time.monotonic):
  self.directory=safe(directory);self.key=key;self.clock=clock;self.monotonic=monotonic
  self.pending={};self.mutex=threading.Lock();self.wall=clock();self.tick=monotonic()
  self.anchor=hashlib.sha256(public_bytes(key.public_key())).hexdigest()
 @contextlib.contextmanager
 def locked(self):
  with self.mutex:
   fd=os.open(safe(self.directory/'dongle.lock'),os.O_CREAT|os.O_NOFOLLOW|os.O_RDWR,0o600)
   try:
    st=os.fstat(fd)
    if not stat.S_ISREG(st.st_mode) or st.st_nlink!=1 or st.st_uid!=os.geteuid() or st.st_mode&0o077:raise ValueError('DONGLE_LOCK')
    fcntl.flock(fd,fcntl.LOCK_EX);yield
   finally:os.close(fd)
 def load(self):
  path=safe(self.directory/'dongle-state.json');st=path.stat()
  if not stat.S_ISREG(st.st_mode) or st.st_uid!=os.geteuid() or st.st_mode&0o077 or st.st_size>1048576:raise ValueError('DONGLE_STATE_FILE')
  env=strict_json(path.read_bytes());raw=base64.b64decode(env['payload'],validate=True)
  self.key.public_key().verify(base64.b64decode(env['signature'],validate=True),STATE_DOMAIN+raw,ec.ECDSA(hashes.SHA256()))
  s=strict_json(raw)
  if s['version']!=1 or s['anchor']!=self.anchor:raise ValueError('DONGLE_STATE_ANCHOR')
  if not re.fullmatch('[0-9a-f]{32}',s['installation']) or s['state'] not in {'unbound','active','clock-error','migrating','import-pending','import-ready'}:raise ValueError('DONGLE_STATE_FORMAT')
  if any(type(s[n]) is not int or s[n]<0 for n in ['generation','verified','expires','highwater']) or s['expires'] and s['expires']!=s['verified']+LEASE_SECONDS:raise ValueError('DONGLE_STATE_TIME')
  if not isinstance(s['retired'],list) or len(s['retired'])>1000:raise ValueError('DONGLE_HISTORY')
  for old in s['retired']:validate_binding(old)
  if s['binding'] is not None:validate_binding(s['binding'])
  if s.get('pairId') is not None and not re.fullmatch('[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}',s['pairId']):raise ValueError('DONGLE_PAIR_ID')
  if 'localCommitted' in s and type(s['localCommitted']) is not bool:raise ValueError('DONGLE_PAIR_COMMIT')
  return s
 def save(self,s):
  raw=canonical(s);atomic(self.directory/'dongle-state.json',canonical({'payload':encoded(raw),'signature':encoded(self.key.sign(STATE_DOMAIN+raw,ec.ECDSA(hashes.SHA256())))}))
 def enroll(self,installation):
  # Called only by installer BEFORE its new identity is put into service. Missing
  # state for an existing installation is deliberately not repaired/adopted.
  if not re.fullmatch('[0-9a-f]{32}',installation):raise ValueError('DONGLE_INSTALLATION')
  with self.locked():
   if (self.directory/'dongle-state.json').exists():
    s=self.load()
    if s['installation']!=installation:raise ValueError('DONGLE_ENROLLMENT_CONFLICT')
    return
   self.save({'version':1,'anchor':self.anchor,'installation':installation,'binding':None,'generation':0,'state':'unbound','verified':0,'expires':0,'highwater':int(self.clock()),'retired':[],'transfer':None})
 def observed_time(self,s):
  now=int(self.clock());elapsed=self.monotonic()-self.tick
  # Small scheduling/NTP tolerance is not a new entitlement grace period.
  if now<s['highwater'] or self.clock()+2<self.wall+elapsed:
   s['expires']=0;s['state']='clock-error' if s['state'] not in {'migrating','import-pending','import-ready'} else s['state']
  if s['expires'] and now>=s['expires']:s['expires']=0
  s['highwater']=max(s['highwater'],now)
  return now
 def challenge(self,device,host,pair_id=None,pairing_version=1):
  device_key(device)
  with self.locked():
   s=self.load();now=self.observed_time(s);self.save(s)
   if s['state']=='migrating':raise ValueError('DONGLE_SOURCE_SUSPENDED')
   if now<s['highwater'] or self.clock()+2<self.wall+self.monotonic()-self.tick:raise ValueError('DONGLE_CLOCK')
   if s['state']=='import-pending':raise ValueError('DONGLE_MIGRATION_NOT_COMMITTED')
   if s['state']=='import-ready' and device!=s['binding']['InitialDevicePublic']:raise ValueError('DONGLE_ORIGINAL_DEVICE_REQUIRED')
   same_pair=s.get('pairId')==pair_id or (not s.get('pairId') and pairing_version==1) or s['state']=='import-ready'
   value=s['binding'] if same_pair and s['binding'] and s['binding']['InitialDevicePublic']==device else binding(device)
   # Canonical ASCII JSON is signed as opaque domain-prefixed bytes by Android.
   body={'version':1,'purpose':'confirm','nonce':secrets.token_hex(32),'installation':s['installation'],'anchor':self.anchor,'host':host,'chain':CHAIN,'hub':HUB,'product':PRODUCT,'generation':s['generation'],'devicePublic':value['InitialDevicePublic'],'salt':value['Salt'],'paymentReference':value['PaymentLicenseReference'],'issued':now,'deadline':now+CHALLENGE_SECONDS}
   self.pending={k:v for k,v in self.pending.items() if v[1]>self.monotonic()}
   if len(self.pending)>=8:raise ValueError('DONGLE_CHALLENGE_LIMIT')
   raw=DONGLE_DOMAIN+canonical(body);self.pending[body['nonce']]=(body,self.monotonic()+CHALLENGE_SECONDS,raw,pair_id)
   return {'status':'CHALLENGE','challenge':encoded(raw),'anchorPublic':encoded(public_bytes(self.key.public_key()))}
 def confirm(self,nonce,signature,current_device,current_pair=None):
  with self.locked():
   # Consume before signature validation; never retry the same nonce after error.
   item=self.pending.pop(nonce,None)
   if item is None or self.monotonic()>=item[1]:raise ValueError('DONGLE_CHALLENGE_EXPIRED')
   b,_,raw,pair_id=item
   if pair_id!=current_pair:raise ValueError('DONGLE_PAIR_CHANGED')
   b=dict(b);b['binding']={'Version':1,'InitialDevicePublic':b['devicePublic'],'Salt':b['salt'],'PaymentLicenseReference':b['paymentReference']};validate_binding(b['binding']);s=self.load();now=self.observed_time(s);self.save(s)
   if now<s['highwater'] or self.clock()+2<self.wall+self.monotonic()-self.tick:raise ValueError('DONGLE_CLOCK')
   if s['state'] in {'migrating','import-pending'} or now<b['issued'] or now>=b['deadline'] or b['generation']!=s['generation'] or b['installation']!=s['installation'] or current_device!=b['binding']['InitialDevicePublic']:raise ValueError('DONGLE_CONTEXT')
   sig=base64.b64decode(signature,validate=True)
   if len(sig)>80:raise ValueError('DONGLE_SIGNATURE')
   device_key(current_device).verify(sig,raw,ec.ECDSA(hashes.SHA256()))
   if s['state']=='import-ready' and b['binding']!=s['binding']:raise ValueError('DONGLE_TRANSFER_BINDING')
   if b['binding']!=s['binding']:
    if s['binding']:s['retired'].append(s['binding'])
    if len(s['retired'])>1000:raise ValueError('DONGLE_HISTORY_LIMIT')
    s['generation']+=1;s['binding']=b['binding']
   s['state']='active';s['verified']=now;s['expires']=now+LEASE_SECONDS;s['highwater']=max(s['highwater'],now)
   if s.get('pairId')!=pair_id:s['localCommitted']=False
   s['pairId']=pair_id
   self.save(s) # Durable commit must precede ACK; payment paths never call this.
   return {'status':'CONFIRMED','expires':s['expires']}
 def mark_completed(self,pair_id,reference):
  with self.locked():
   s=self.load()
   if s.get('pairId')!=pair_id or not s['binding'] or s['binding']['PaymentLicenseReference']!=reference:raise ValueError('DONGLE_PAIR_COMPLETION_CONFLICT')
   s['localCommitted']=True;self.save(s)
 def status(self,installation,nonce,device,pair_id=None,pairing_version=1):
  if not re.fullmatch('[0-9a-f]{64}',nonce):raise ValueError('DONGLE_NONCE')
  with self.locked():
   s=self.load();now=self.observed_time(s);self.save(s)
   if installation!=s['installation']:raise ValueError('DONGLE_INSTALLATION_MISMATCH')
   good=s['state']=='active' and s['binding'] is not None and s['binding']['InitialDevicePublic']==device and now<s['expires'] and now>=s['verified']
   # Descriptor remains available for an authorized switch, but is not a grant.
   result={'version':1,'nonce':nonce,'installation':installation,'anchor':self.anchor,'generation':s['generation'],'binding':s['binding'],'retiredReferences':[v['PaymentLicenseReference'] for v in s['retired']],'state':s['state'],'allowed':good,'verified':s['verified'],'expires':s['expires'],'now':now}
   legacy=not s.get('pairId') and pairing_version==1
   confirmed=bool(pair_id and s['binding'] and s['binding']['InitialDevicePublic']==device and (s.get('pairId')==pair_id or legacy) and s['state'] not in {'unbound','migrating','import-pending','import-ready'})
   result.update(pairId=pair_id,pairingConfirmed=confirmed,pairingComplete=confirmed and (legacy or s.get('localCommitted',False)),legacyPairing=legacy)
   raw=canonical(result)
   return {'status':'STATUS','payload':encoded(raw),'signature':encoded(self.key.sign(STATUS_DOMAIN+raw,ec.ECDSA(hashes.SHA256()))),'public':encoded(public_bytes(self.key.public_key()))}
 def export(self,installation,backup_id):
  with self.locked():
   s=self.load()
   if installation!=s['installation'] or not s['binding'] or not re.fullmatch('[0-9a-f-]{36}',backup_id):raise ValueError('DONGLE_EXPORT_CONTEXT')
   if s['state']=='migrating' and s['transfer']!=backup_id:raise ValueError('DONGLE_EXPORT_PENDING')
   s['state']='migrating';s['expires']=0;s['transfer']=backup_id;self.save(s)
   proof={'version':1,'sourceInstallation':installation,'sourceAnchor':self.anchor,'backupId':backup_id,'binding':s['binding'],'generation':s['generation'],'purpose':'migration'}
   raw=canonical(proof)
   return {'payload':encoded(raw),'public':encoded(public_bytes(self.key.public_key())),'signature':encoded(self.key.sign(TRANSFER_DOMAIN+raw,ec.ECDSA(hashes.SHA256())))}
 def import_transfer(self,proof,expected_anchor,installation,backup_id):
  # expected_anchor is explicit independently verified operator input, NEVER
  # taken from the same archive. A fresh original-device proof is still mandatory.
  p=verify_transfer(proof,expected_anchor,installation,backup_id)
  with self.locked():
   s=self.load()
   if s['installation']!=installation:raise ValueError('DONGLE_TARGET_IDENTITY')
   if s['transfer']==backup_id:
    if s['binding']!=p['binding']:raise ValueError('DONGLE_TRANSFER_CONFLICT')
    return # Do not reset or renew a previously committed proof on retries.
   if s['binding'] is not None:raise ValueError('DONGLE_TARGET_ALREADY_BOUND')
   s['binding']=p['binding'];s['generation']+=1;s['transfer']=backup_id;s['state']='import-pending';s['verified']=0;s['expires']=0;self.save(s)
 def finish_import(self,installation,backup_id):
  with self.locked():
   s=self.load()
   if s['installation']==installation and s['transfer']==backup_id and s['state']=='active':return # Verified retry never renews a lease.
   if s['installation']!=installation or s['transfer']!=backup_id or s['state'] not in {'import-pending','import-ready'}:raise ValueError('DONGLE_MIGRATION_COMMIT_CONTEXT')
   s['state']='import-ready';self.save(s)

def external_state(directory='/var/lib/btctrader-instance'):
 directory=safe(directory)
 if not (directory/'anchor.pem').is_file() or not (directory/'dongle-state.json').is_file():raise ValueError('DONGLE_ANCHOR_NOT_ENROLLED')
 return DongleState(directory,ensure(directory))

def prepare_installation(directory,product,fresh=False):
 """Root-only installer enrollment, deliberately unavailable on the socket.
 Reserve ID durably BEFORE creating the existing local identity; resume uses it.
 A copied/already initialized folder cannot create its own trusted enrollment.
 """
 directory=safe(directory);identity=safe(pathlib.Path(product)/'local-security/installation.json')
 if not (directory/'dongle-state.json').exists():
  if not fresh or identity.exists():raise ValueError('DONGLE_TRUSTED_FRESH_INSTALL_REQUIRED')
  state=DongleState(directory,ensure(directory));state.enroll(secrets.token_hex(16))
 else:
  if not (directory/'anchor.pem').exists():raise ValueError('DONGLE_ANCHOR_MISSING')
  state=DongleState(directory,ensure(directory))
 with state.locked():record=state.load()
 if identity.exists() and strict_json(identity.read_bytes()).get('InstallationId')!=record['installation']:raise ValueError('DONGLE_INSTALLATION_MISMATCH')
 return record['installation']

def ensure(directory):
 directory=safe(directory);directory.mkdir(mode=0o700,parents=True,exist_ok=True)
 if not directory.is_dir() or directory.stat().st_uid!=os.geteuid() or directory.stat().st_mode&0o077:raise ValueError('DONGLE_ANCHOR_DIRECTORY')
 path=directory/'anchor.pem'
 if not path.exists():
  if (directory/'dongle-state.json').exists():raise ValueError('DONGLE_ANCHOR_KEY_LOST')
  key=ec.generate_private_key(ec.SECP256R1());atomic(path,key.private_bytes(serialization.Encoding.PEM,serialization.PrivateFormat.PKCS8,serialization.NoEncryption()))
 st=safe(path).stat()
 if not stat.S_ISREG(st.st_mode) or st.st_uid!=os.geteuid() or st.st_mode&0o077 or st.st_size>4096:raise ValueError('DONGLE_ANCHOR_KEY_FILE')
 key=serialization.load_pem_private_key(path.read_bytes(),password=None)
 if not isinstance(key,ec.EllipticCurvePrivateKey) or not isinstance(key.curve,ec.SECP256R1):raise ValueError('anchor algorithm')
 return key
class ProofServer:
 def __init__(self,directory,uid,host_public,transport_uid=None):
  self.key=ensure(directory);self.uid=uid;self.host_public=pathlib.Path(host_public);self.transport_uid=transport_uid
  self.dongle=DongleState(directory,self.key)
 def dispatch(self,request,uid):
  # Socket is reachable by both dedicated users. Every command has an explicit
  # peer-credential ACL; payload fields never select filesystem paths or users.
  if not isinstance(request,dict):raise ValueError('DONGLE_REQUEST')
  command=request.get('command')
  if uid==self.uid and command=='status' and set(request)=={'command','installation','nonce'}:
   pair_id,device,version=self.pairing()
   return self.dongle.status(request['installation'],request['nonce'],device,pair_id,version)
  if uid==self.uid and command=='maintenance' and set(request)=={'command','installation','nonce'}:
   if not re.fullmatch('[0-9a-f]{64}',request['nonce']) or not re.fullmatch('[0-9a-f]{32}',request['installation']):raise ValueError('MAINTENANCE_CONTEXT')
   # Independent of phone, license or dongle-state health; it only authorizes
   # the maintenance condition, never an order or a positive entitlement.
   public=public_bytes(self.key.public_key())
   raw=canonical({'version':1,'nonce':request['nonce'],'installation':request['installation'],'anchor':hashlib.sha256(public).hexdigest(),'maintenanceClear':self.maintenance_clear()})
   return {'status':'MAINTENANCE','payload':encoded(raw),'signature':encoded(self.key.sign(MAINTENANCE_DOMAIN+raw,ec.ECDSA(hashes.SHA256()))),'public':encoded(public)}
  if uid==self.transport_uid and command=='challenge' and set(request)=={'command'}:
   pair_id,device,version=self.pairing()
   if not pair_id:raise ValueError('DONGLE_PAIR_REQUIRED')
   return self.dongle.challenge(device,'0x'+self.host_digest().hex(),pair_id,version)
  if uid==self.transport_uid and command=='confirm' and set(request)=={'command','nonce','signature'}:
   pair_id,device,_=self.pairing()
   answer=self.dongle.confirm(request['nonce'],request['signature'],device,pair_id)
   with self.dongle.locked():reference=self.dongle.load()['binding']['PaymentLicenseReference']
   # The existing license engine commits locally before the phone receives ACK.
   # A failure leaves the same root reference pending, resumable by confirmation.
   self.complete_pairing(pair_id)
   self.dongle.mark_completed(pair_id,reference)
   return answer
  raise PermissionError('DONGLE_PEER_COMMAND')
 def maintenance_clear(self):return maintenance_clear()
 def acquire_maintenance(self):return maintenance_lock()
 def host_digest(self):
  host=serialization.load_ssh_public_key(safe(self.host_public).read_bytes());blob=base64.b64decode(host.public_bytes(serialization.Encoding.OpenSSH,serialization.PublicFormat.OpenSSH).split()[1],validate=True);return hashlib.sha256(blob).digest()
 def device(self):
  return self.pairing()[1]
 def pairing(self):
  path=pathlib.Path('/var/lib/btctrader-pairing/pairing.db')
  if not path.exists():return None,'',1
  with sqlite3.connect('file:'+str(safe(path))+'?mode=ro',uri=True) as db:
   row=db.execute('SELECT pair_id,device_public FROM binding WHERE singleton=1').fetchone()
   if row and not re.fullmatch('[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}',row[0]):raise ValueError('DONGLE_PAIR_ID')
   version=1
   if row and db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='binding_protocol'").fetchone():
    marker=db.execute('SELECT version FROM binding_protocol WHERE pair_id=?',(row[0],)).fetchone()
    if marker:
     if marker[0]!=2:raise ValueError('DONGLE_PAIR_VERSION')
     version=2
   return (*row,version) if row else (None,'',1)
 def complete_pairing(self,pair_id):
  if not pair_id or not re.fullmatch('[0-9a-f-]{36}',pair_id):raise ValueError('DONGLE_PAIR_ID')
  user=pwd.getpwuid(self.uid)
  if user.pw_uid==0 or user.pw_name!='btctrader':raise ValueError('DONGLE_PRODUCT_ACCOUNT')
  subprocess.run(['/usr/sbin/runuser','-u',user.pw_name,'--','/usr/bin/dotnet','/opt/btctrader/BTC_TRADER_PRO.dll','--complete-customer-pairing',pair_id],cwd='/opt/btctrader',stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,timeout=12,check=True)
 def serve(self,connection):
  try:
   _,uid,_=struct.unpack('3i',connection.getsockopt(socket.SOL_SOCKET,socket.SO_PEERCRED,12))
   if uid not in {self.uid,self.transport_uid}:raise PermissionError('peer')
   connection.settimeout(3);data=bytearray();deadline=time.monotonic()+3
   while not data.endswith(b'\n'):
    if time.monotonic()>=deadline:raise TimeoutError('deadline')
    b=connection.recv(1)
    if not b:raise ValueError('incomplete')
    data+=b
    if len(data)>4096:raise ValueError('size')
   if data.startswith(b'{'):
    request=strict_json(bytes(data))
    if isinstance(request,dict) and request.get('command')=='submit':
     if uid!=self.uid or set(request)!={'command','installation','nonce'} or not re.fullmatch('[0-9a-f]{64}',request['nonce']) or not re.fullmatch('[0-9a-f]{32}',request['installation']):raise PermissionError('MAINTENANCE_PEER_CONTEXT')
     fd=self.acquire_maintenance()
     try:
      public=public_bytes(self.key.public_key())
      raw=canonical({'version':1,'nonce':request['nonce'],'installation':request['installation'],'anchor':hashlib.sha256(public).hexdigest(),'maintenanceClear':True})
      response={'status':'SUBMIT','payload':encoded(raw),'signature':encoded(self.key.sign(MAINTENANCE_DOMAIN+raw,ec.ECDSA(hashes.SHA256()))),'public':encoded(public)}
      # SCM_RIGHTS transfers the same open file description: its shared flock
      # survives closing our copy and helper restart until the trader closes it.
      connection.sendmsg([b'!'],[(socket.SOL_SOCKET,socket.SCM_RIGHTS,struct.pack('i',fd))])
      connection.sendall(canonical(response)+b'\n')
     finally:os.close(fd)
     return
    connection.sendall(canonical(self.dispatch(strict_json(bytes(data)),uid))+b'\n');return
   if uid!=self.uid:raise PermissionError('peer')
   encode=lambda b:base64.b64encode(b).decode()
   public=self.key.public_key().public_bytes(serialization.Encoding.DER,serialization.PublicFormat.SubjectPublicKeyInfo)
   host=self.host_digest();device=self.device()
   if not re.fullmatch(b'[0-9a-f]{64}\n',data):raise ValueError('nonce format')
   proof={'Public':encode(public),'Signature':encode(self.key.sign(DOMAIN+bytes.fromhex(data[:-1].decode()),ec.ECDSA(hashes.SHA256()))),'HostDigest':'0x'+host.hex(),'DevicePublic':device}
   connection.sendall(json.dumps(proof,separators=(',',':')).encode()+b'\n')
  except Exception:
   try:connection.sendall(b'{"status":"DONGLE_UNAVAILABLE"}\n')
   except OSError:pass
  finally:connection.close()
 def listen(self,path,gid):
  path=safe(path);path.parent.mkdir(mode=0o755,parents=True,exist_ok=True)
  if path.parent.stat().st_uid!=0 or path.parent.stat().st_mode&0o022:raise ValueError('proof socket directory')
  os.chmod(path.parent,0o755)
  if path.exists():raise ValueError('existing proof socket')
  with socket.socket(socket.AF_UNIX,socket.SOCK_STREAM) as server:
   try:
    server.bind(str(path));os.chown(path,0,gid);os.chmod(path,0o666);server.listen(8)
    # Bounded concurrency lets the service-account completion CLI obtain its
    # authenticated status proof while the phone confirmation is pending.
    slots=threading.BoundedSemaphore(8)
    def serve_bounded(connection):
     try:self.serve(connection)
     finally:slots.release()
    while True:
     connection,_=server.accept()
     if not slots.acquire(blocking=False):connection.close();continue
     threading.Thread(target=serve_bounded,args=(connection,),daemon=True).start()
   finally:path.unlink(missing_ok=True)
def main():
 p=argparse.ArgumentParser();p.add_argument('--service-user',default='btctrader');p.add_argument('--host-public',default='/etc/ssh/ssh_host_ecdsa_key.pub');a=p.parse_args()
 if os.geteuid()!=0:raise PermissionError('root')
 user=pwd.getpwnam(a.service_user);transport=pwd.getpwnam('btctrader-app');ProofServer('/var/lib/btctrader-instance',user.pw_uid,a.host_public,transport.pw_uid).listen('/run/btctrader-instance/proof.sock',user.pw_gid)
