"""Portable age-v1 backup with explicit source persistence roots, quiesced service and SQLite backup."""
import base64,hashlib,hmac,datetime,io,json,os,pathlib,shutil,sqlite3,stat,subprocess,sys,tarfile,tempfile,uuid
from .common import safe,atomic,strict_json,write_json,digest,lock,System,file_digest,atomic_copy
from .artifacts import inspect_tar_files,schema,name
# Source roots: ConfigManager, standalone security, user storage layout, reporter/logger.
ROOT_FILES={'config.json','trading.db','analyzer.db','live_execution.db','testwallet_state.json','trading_control.json','shock_guard_up_state.json','binance_credentials.enc'}
ROOT_DIRS={'state','local-security','license-state','logs','reports','WeeklyReports','Optimizer','backup'}
REQUIRED={'local-security/installation.json','state/config.json'}
def resolve(root,replacing_databases=frozenset()):
 result={}
 for name_ in ROOT_FILES:
  p=root/name_
  if p.exists() or p.is_symlink():
   safe(p,root)
   if not p.is_file():raise ValueError('backup root file type')
   result[name_]=p
 for directory in ROOT_DIRS:
  p=root/directory
  safe(p,root)
  if not p.exists():continue
  if not p.is_dir():raise ValueError('backup root directory type')
  for f in p.rglob('*'):
   safe(f,root)
   # Regenerable scanner lease, not license state. Keep its live inode untouched.
   # resolve() also drives restore cleanup, so the same exclusion preserves it there.
   if f.relative_to(root).as_posix() in {'license-state/.scanner.lock','local-security/.setup.lock'}:
    st=f.lstat()
    if not stat.S_ISREG(st.st_mode) or st.st_nlink!=1 or st.st_size!=0:
     from .update import MaintenanceError
     raise MaintenanceError('BACKUP_SCANNER_LOCK_INVALID' if f.relative_to(root).as_posix()=='license-state/.scanner.lock' else 'BACKUP_SETUP_LOCK_INVALID')
    continue
   if f.is_dir():continue
   if not f.is_file():raise ValueError('backup special file refused')
   if f.name.endswith(('-wal','-shm')):
    database=safe(f.with_name(f.name[:-4]),root)
    if database.suffix not in {'.db','.sqlite'} or not database.is_file():raise ValueError('unbound database sidecar')
    # During restore, an already validated replacement DB authorizes cleanup
    # of its own old sidecars even if the damaged target header is unreadable.
    if database.relative_to(root).as_posix() not in replacing_databases:
     with database.open('rb') as stream:
      if stream.read(16)!=b'SQLite format 3\x00':raise ValueError('invalid database sidecar')
    continue
   result[str(f.relative_to(root))]=f
 if not REQUIRED<=result.keys():raise ValueError('missing required identity/state component')
 return result
def verify_state(product_root,state_root):
 from .update import MaintenanceError
 try:p=subprocess.run(['dotnet',str(product_root/'BTC_TRADER_PRO.dll'),'--customer-state-verify',str(state_root)],capture_output=True,check=True,timeout=60)
 except subprocess.TimeoutExpired:raise MaintenanceError('BACKUP_VALIDATION_TIMEOUT') from None
 except subprocess.CalledProcessError:raise MaintenanceError('BACKUP_VALIDATION_FAILED') from None
 return strict_json(p.stdout)
def sqlite_copy(source,target):
 with sqlite3.connect('file:'+str(source)+'?mode=ro',uri=True) as src,sqlite3.connect(target) as dst:
  if src.execute('PRAGMA integrity_check').fetchone()[0]!='ok':raise ValueError('source DB integrity')
  src.backup(dst)
  if dst.execute('PRAGMA integrity_check').fetchone()[0]!='ok':raise ValueError('backup DB integrity')
def age(mode,source,target):
 version=subprocess.run(['age','--version'],capture_output=True,text=True,check=True).stdout.strip()
 if version not in {'v1.1.1','1.1.1'}:raise ValueError('age 1.1.1 required; verify distro package before changing pin')
 command=['age','-p'] if mode=='encrypt' else ['age','-d']
 # age requests the passphrase directly from the user's controlling terminal.
 with safe(target).open('xb') as out:
  os.chmod(target,0o600)
  try:
   if mode=='decrypt':
    limit=min(2*1024**3,max(0,shutil.disk_usage(pathlib.Path(target).parent).free//2-64*1024*1024))
    if limit<=0:raise ValueError('restore workspace space')
    with subprocess.Popen(command+[str(safe(source))],stdout=subprocess.PIPE) as process:
     try:
      count=0
      while chunk:=process.stdout.read(65536):
       count+=len(chunk)
       if count>limit:raise ValueError('restore cleartext limit')
       out.write(chunk)
      if process.wait()!=0:raise ValueError('restore decryption failed')
     finally:
      process.stdout.close()
      if process.poll() is None:process.kill();process.wait()
   else:subprocess.run(command+[str(safe(source))],stdout=out,check=True)
   out.flush();os.fsync(out.fileno())
  except BaseException:out.close();pathlib.Path(target).unlink(missing_ok=True);raise
 fd=os.open(pathlib.Path(target).parent,os.O_RDONLY|os.O_DIRECTORY)
 try:os.fsync(fd)
 finally:os.close(fd)
def preflight_backup(root,target):
 from .update import MaintenanceError
 if target.exists():raise MaintenanceError('BACKUP_TARGET_EXISTS')
 parent=safe(target.parent)
 if not parent.is_dir() or not os.access(parent,os.W_OK|os.X_OK):raise MaintenanceError('BACKUP_TARGET_NOT_WRITABLE')
 if target.is_relative_to(root):raise MaintenanceError('BACKUP_TARGET_INSIDE_PRODUCT')
 try:files=resolve(root)
 except (ValueError,OSError):raise MaintenanceError('BACKUP_REQUIRED_STATE_INVALID') from None
 required=sum(p.stat().st_size for p in files.values())*2+64*1024*1024
 if shutil.disk_usage(parent).free<required or shutil.disk_usage(root).free<required:raise MaintenanceError('BACKUP_SPACE_INSUFFICIENT')
 if not shutil.which('age'):raise MaintenanceError('BACKUP_AGE_MISSING')
 try:version=subprocess.run(['age','--version'],capture_output=True,text=True,check=True,timeout=5).stdout.strip()
 except (subprocess.SubprocessError,OSError):raise MaintenanceError('BACKUP_AGE_VERSION_CHECK_FAILED') from None
 if version not in {'v1.1.1','1.1.1'}:raise MaintenanceError('BACKUP_AGE_VERSION_UNSUPPORTED')
 try:
  fd=os.open('/dev/tty',os.O_RDWR|os.O_NOCTTY);os.close(fd)
 except OSError:raise MaintenanceError('BACKUP_TERMINAL_REQUIRED') from None
 return files
class Backup:
 def __init__(self,root=pathlib.Path('/opt/btctrader'),ops=pathlib.Path('/var/lib/btctrader-operations'),system=None):self.root=safe(root);self.ops=safe(ops);self.system=system or System()
 def create(self,target,migration_source=False):
  target=safe(target)
  preflight_backup(self.root,target)
  with lock(self.ops):
   from .update import Updater
   engine=Updater(self.root,self.ops,self.system)
   required=sum(p.stat().st_size for p in resolve(self.root).values())*2+64*1024*1024
   if shutil.disk_usage(self.ops).free<required:
    from .update import MaintenanceError
    raise MaintenanceError('BACKUP_WORKSPACE_SPACE_INSUFFICIENT')
   def create_quiesced():
    with tempfile.TemporaryDirectory(prefix='backup-',dir=self.ops) as tmp:
     tmp=pathlib.Path(tmp);backup_id=str(uuid.uuid4())
     marker=safe(self.root/'state/migration-source-quiesced.json',self.root)
     if marker.exists():raise ValueError('migration source already quiesced; explicit recovery required')
     facts=verify_state(self.root,self.root)
     if migration_source and (self.root/'customer-v1.json').exists() and facts.get('binding') is not None:
      from .instance import external_state
      anchor=external_state()
      with anchor.locked():external=anchor.load()
      if external['installation']!=facts['installationId'] or external['binding']!=facts['binding']:raise ValueError('DONGLE_EXPORT_BINDING_MISMATCH')
     if migration_source:
      # Persist source start inhibition BEFORE any usable export can exist.
      write_json(marker,{'version':1,'backupId':backup_id,'sourceInstallationId':facts['installationId'],'targetTradingMustNotRunInParallel':True})
      if (self.root/'customer-v1.json').exists() and facts.get('binding') is not None:
       from .instance import external_state
       anchor=external_state();proof=anchor.export(facts['installationId'],backup_id)
       write_json(self.root/'license-state/dongle-transfer.json',proof)
       print('Quellanker SHA256 (am Ziel unabhängig prüfen): '+anchor.anchor)
     files=resolve(self.root);inventory=[];contents={};versions={} 
     for relative,p in sorted(files.items()):
      if p.suffix in {'.db','.sqlite'}:
       snapshot=tmp/(uuid.uuid4().hex+'.sqlite');sqlite_copy(p,snapshot);data=snapshot
       with sqlite3.connect(snapshot) as db:versions[relative]=db.execute('PRAGMA user_version').fetchone()[0]
      else:data=p
      contents[relative]=data;inventory.append({'path':relative,'size':data.stat().st_size,'sha256':file_digest(data),'mode':'0600'})
     identity=strict_json(contents['local-security/installation.json'].read_bytes());product=strict_json((self.root/'product.json').read_bytes())
     meta={'schemaVersion':1,'product':'BTC Trader Pro','backupId':backup_id,'createdAtUtc':datetime.datetime.now(datetime.timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ'),'sourceRevision':product['revision'],'productVersion':product['productVersion'],'sourceInstallationId':identity['InstallationId'],'paymentLicenseReference':facts['paymentLicenseReference'],'databaseSchemaVersions':versions,'consistency':'quiesced','files':inventory,'requiredComponents':sorted(REQUIRED),'containsIdentitySecrets':True,'encryption':'age-v1-scrypt'}
     schema('backupmanifest',meta);body={'manifest.json':json.dumps(meta,separators=(',',':')).encode(),**{'data/'+n:d for n,d in contents.items()}}
     body['FILESHA256SUMS']=''.join((file_digest(d) if isinstance(d,pathlib.Path) else digest(d))+'  '+n+'\n' for n,d in sorted(body.items())).encode()
     archive=tmp/'clear.tar.gz'
     with tarfile.open(archive,'w:gz') as tar:
      for n,d in sorted(body.items()):
       i=tarfile.TarInfo(n);i.size=d.stat().st_size if isinstance(d,pathlib.Path) else len(d);i.mode=0o600
       with d.open('rb') if isinstance(d,pathlib.Path) else io.BytesIO(d) as stream:tar.addfile(i,stream)
     age('encrypt',archive,target)
     # Source marker is already part of the encrypted, hashed inventory.
     # Never automatically remove it after an export/encryption failure.
    return {'path':str(target),'sha256':file_digest(target)}
   engine.transaction_locked([],'BACKUP','0'*64,quiesced_action=create_quiesced,health=False,remain_stopped=migration_source)
   if migration_source:print('Migrationsbackup erstellt; Alttrading bleibt gestoppt. Vor Zielbetrieb Altquelle nicht parallel starten.')
 def restore(self,source,migrate=False,source_anchor=None):
  with lock(self.ops):
   with tempfile.TemporaryDirectory(prefix='restore-',dir=self.ops) as tmp:
    tmp=pathlib.Path(tmp);clear=tmp/'clear.tar.gz';age('decrypt',safe(source),clear)
    data=inspect_tar_files(clear,tmp/'validate',limit=shutil.disk_usage(self.root).free);files={k:v for k,v in data.items() if v is not None}
    meta=strict_json(files['manifest.json'].read_bytes());schema('backupmanifest',meta)
    if meta['sourceRevision']>strict_json(safe(self.root/'product.json').read_bytes())['revision']:raise ValueError('backup needs newer product revision')
    inventory={name(x['path']):x for x in meta['files']}
    if len(inventory)!=len(meta['files']) or set(files)!= {'manifest.json','FILESHA256SUMS'}|{'data/'+n for n in inventory}:raise ValueError('backup set')
    hashes={}
    for line in files['FILESHA256SUMS'].read_text(encoding='ascii').splitlines():
     h,n=line.split('  ',1)
     if n in hashes:raise ValueError('duplicate backup hash')
     hashes[n]=h
    if set(hashes)!=set(files)-{'FILESHA256SUMS'} or any(file_digest(files[n])!=h for n,h in hashes.items()):raise ValueError('backup integrity')
    if not REQUIRED<=inventory.keys() or not REQUIRED<=set(meta['requiredComponents']):raise ValueError('backup required components')
    for n,item in inventory.items():
     if n.split('/')[0] not in ROOT_DIRS|ROOT_FILES or n.split('/')[0] in ROOT_FILES and n not in ROOT_FILES or files['data/'+n].stat().st_size!=item['size'] or file_digest(files['data/'+n])!=item['sha256']:raise ValueError('backup inventory')
     safe(self.root/n,self.root)
    marker_name='state/migration-source-quiesced.json'
    if migrate:
     if marker_name not in inventory:raise ValueError('planned migration requires quiesced migration export')
     proof=strict_json(files['data/'+marker_name].read_bytes())
     if proof.get('version')!=1 or proof.get('backupId')!=meta['backupId'] or proof.get('sourceInstallationId')!=meta['sourceInstallationId'] or proof.get('targetTradingMustNotRunInParallel') is not True:raise ValueError('migration export binding')
    elif marker_name in inventory or safe(self.root/marker_name,self.root).exists():raise ValueError('source quiescence requires explicit migration recovery')
    validation=tmp/'validate'
    for n in inventory:atomic_copy(validation/n,files['data/'+n])
    if set(meta['databaseSchemaVersions'])!={n for n in inventory if n.endswith(('.db','.sqlite'))}:raise ValueError('incomplete DB schema inventory')
    for n,expected in meta['databaseSchemaVersions'].items():
     if n not in inventory or not n.endswith(('.db','.sqlite')):raise ValueError('DB schema inventory')
     with sqlite3.connect('file:'+str(safe(validation/n))+'?mode=ro',uri=True) as db:
      if db.execute('PRAGMA integrity_check').fetchone()[0]!='ok' or db.execute('PRAGMA user_version').fetchone()[0]!=expected:raise ValueError('backup DB schema/integrity')
    facts=verify_state(self.root,validation)
    if facts['installationId']!=meta['sourceInstallationId'] or facts['paymentLicenseReference']!=meta['paymentLicenseReference'] and not (meta['sourceRevision']<=5 and meta['paymentLicenseReference'] is None and facts.get('binding') is None):raise ValueError('backup identity/reference binding')
    current=strict_json(safe(self.root/'local-security/installation.json').read_bytes())
    if not migrate and current['InstallationId']!=meta['sourceInstallationId']:raise ValueError('identity mismatch; use migration')
    if migrate and current['InstallationId']==meta['sourceInstallationId']:raise ValueError('migration needs new installation identity')
    # Same-install restore must preserve the exact master, not merely a copied public ID.
    if not migrate and files['data/local-security/installation.json'].read_bytes()!=safe(self.root/'local-security/installation.json').read_bytes():raise ValueError('same-install master/identity mismatch')
    dongle=None;transfer_proof=None
    if (self.root/'customer-v1.json').exists():
     from .instance import external_state
     dongle=external_state()
     with dongle.locked():external=dongle.load()
     if external['installation']!=current['InstallationId']:raise ValueError('DONGLE_TARGET_IDENTITY')
     if not migrate:
      expected=external['binding']['PaymentLicenseReference'][2:] if external['binding'] else None
      if (facts.get('binding') is None and expected is not None) or (facts.get('binding') is not None and facts['paymentLicenseReference']!=expected):raise ValueError('DONGLE_RESTORE_REFERENCE_CONFLICT')
     elif source_anchor:
      transfer_name='license-state/dongle-transfer.json'
      if transfer_name not in inventory or not facts.get('binding'):raise ValueError('DONGLE_TRANSFER_PROVENANCE_REQUIRED')
      transfer_proof=strict_json(files['data/'+transfer_name].read_bytes())
      from .instance import verify_transfer
      signed=verify_transfer(transfer_proof,source_anchor,current['InstallationId'],meta['backupId'])
      if signed.get('binding')!=facts['binding'] or signed.get('sourceInstallation')!=meta['sourceInstallationId']:raise ValueError('DONGLE_TRANSFER_BACKUP_BINDING')
      if external['binding'] is not None and (external['transfer']!=meta['backupId'] or external['binding']!=signed['binding']):raise ValueError('DONGLE_TARGET_ALREADY_BOUND')
     # Without an independent anchor pin migrate only trading/TEST data;
     # never carry the old paid reference into this installation.
    transfer_license=migrate and (dongle is None or transfer_proof is not None)
    from .update import Updater,identity
    engine=Updater(self.root,self.ops,self.system);changes=[]
    for n in inventory:
     if n=='license-state/dongle-transfer.json':continue
     if migrate and (n=='config.json' or n.startswith(('local-security/','license-state/')) or n.endswith('binance_credentials.enc')):continue
     if n.endswith(('.db','.sqlite')):
      for suffix in ['-wal','-shm']:changes.append((n+suffix,None,0o600))
     changes.append((n,files['data/'+n],0o600))
    if not migrate:
     imported=set(inventory)
     for n in resolve(self.root,replacing_databases=frozenset(meta['databaseSchemaVersions'])):
      if n not in imported:changes.append((n,None,0o600))
     # Historical cache never renews a blockchain verification after restore.
     stale={'license-state/registry-observation.json','license-state/payment-observation.json'}
     changes=[x for x in changes if x[0] not in stale]
     changes.extend((n,None,0o600) for n in sorted(stale))
    if transfer_license:
     destination=verify_state(self.root,self.root)
     reference='0x'+facts['paymentLicenseReference']
     if destination['paymentLicenseReference']!=facts['paymentLicenseReference'] and destination.get('hasLicenseHistory'):raise ValueError('paid destination reference retained; migration refused')
     # Source reference was authenticated using its original identity by verify_state.
     # Only explicit local restore of the encrypted backup can adopt it; no web API.
     binding=facts.get('binding') or {'Version':2,'PaymentLicenseReference':reference,'InitialDevicePublic':'','Salt':meta['sourceInstallationId']}
     raw=json.dumps(binding,separators=(',',':')).encode();master=base64.b64decode(current['MasterKey'],validate=True)
     key=hmac.digest(master,b'BTC_TRADER_PRO|STANDALONE|CUSTOMER_PAYMENT_BINDING|V1','sha256')
     envelope=json.dumps({'Payload':base64.b64encode(raw).decode(),'Mac':hmac.digest(key,raw,'sha256').hex().upper()},separators=(',',':')).encode()
     changes=[x for x in changes if x[0] not in {'state/migration-license.json','state/migration-source-quiesced.json'}]
     changes.extend((n,None,0o600) for n in ['state/migration-license.json','state/migration-source-quiesced.json','license-state/payment-observation.json','license-state/registry-observation.json'])
     if destination['paymentLicenseReference']!=facts['paymentLicenseReference']:
      for n in resolve(self.root):
       if n.startswith('license-state/') and n not in {'license-state/customer-binding.json','license-state/payment-observation.json','license-state/registry-observation.json'}:changes.append((n,None,0o600))
     changes.append(('license-state/customer-binding.json',envelope,0o600))
    if migrate:
     # This source-only stop marker must never be installed on the target,
     # including a data-only rescue without license transfer.
     changes=[x for x in changes if x[0]!='state/migration-source-quiesced.json']
     marker=json.dumps({'version':1,'sourceInstallationId':meta['sourceInstallationId'],'licenseTransferRequired':True,'exchangeReconciliationRequired':True},separators=(',',':')).encode()
     changes.append(('state/migration-reconciliation-required.json',marker,0o600))
    # Auth sessions are in memory and expire when the stopped service restarts.
    def import_quiesced():
     if transfer_proof is not None:
      dongle.import_transfer(transfer_proof,source_anchor,current['InstallationId'],meta['backupId'])
     return None
    engine.transaction_locked(changes,'MIGRATE' if migrate else 'RESTORE',file_digest(safe(source)),quiesced_action=import_quiesced if transfer_proof is not None else None)
    if transfer_proof is not None:dongle.finish_import(current['InstallationId'],meta['backupId'])
