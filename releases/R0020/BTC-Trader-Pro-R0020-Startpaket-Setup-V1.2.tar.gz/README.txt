BTC TRADER PRO SETUP V1.2

Eigenständiges Startmenü für die vorhandenen Kunden-Verwaltungswerkzeuge.
Keine neue Installer-, Update-, Backup- oder Recoveryengine.
Dieses Paket enthält keinen Trader und keine APK. Es enthält nur das Menü,
unveränderte vorhandene Paketprüfer, Schemas und den bestehenden öffentlichen Signaturprüfschlüssel.
Das Setup signiert keine Pakete und erteilt keine LIVE-Freigabe.

VORAUSSETZUNGEN
Für Installation: Ubuntu 24.04 x86_64 und ein privates interaktives Terminal
mit sudo. Python 3 muss vorhanden sein. Für die kryptographische Prüfung
werden python3-cryptography und python3-jsonschema benötigt.
Das Menü kann ohne abgeschlossene Trader-Installation starten.
Fehlende Prüfabhängigkeiten werden nicht automatisch installiert.
Falls sie fehlen, müssen die offiziellen Ubuntu-Pakete zuvor bereitgestellt
werden. Auf einem gemeinsam genutzten VPS dabei zuerst die Auswirkungen
systemweiter Paketänderungen prüfen. Keine Sicherheitsprüfung überspringen.

VERTRAUEN UND VORBEREITUNG
1. Setup-TAR.GZ und dessen SHA-256 aus einer vertrauenswürdigen Quelle beziehen.
   Den äußeren Hash unabhängig vergleichen, BEVOR das Setup ausgeführt wird.
   SHA256SUMS im Archiv allein beweist nicht die Herkunft des Setup-Codes.
   Das Setup ist ein separates Verwaltungsprogramm, kein signiertes Produktupdate.
2. In ein eigenes Verzeichnis entpacken, ohne bestehende Dateien zu überschreiben.
3. Die innere signierte Kundenpaket-TAR.GZ und ihre Datei .tar.gz.sig aus dem
   authentischen Startpaket direkt neben start.sh legen. NICHT das äußere
   STARTPAKET.tar.gz dort als Produktpaket verwenden.
   Der passende öffentliche Signaturprüfschlüssel ist bereits enthalten. Nicht ersetzen.
4. Im entpackten Verzeichnis BTC-Trader-Pro-Setup:

   sha256sum -c SHA256SUMS
   sudo bash start.sh

Nur bei vollständig passenden Prüfsummen ausführen. Keine Terminalaufzeichnung
verwenden: native Pairingdialoge zeigen absichtlich einmalige private Links.
Keine Passwörter als Argumente eingeben. Das Setup schreibt keine Mitschnitte.

PAKETERKENNUNG
Es werden nur TAR.GZ-Dateien direkt neben start.sh untersucht. Jede benötigt
eine gleichnamige .sig. Vor jeglicher Ausführung erfolgen die vorhandenen
Ed25519-, TAR-, JSON-Schema-, SHA256-, Produkt-, APK- und Revisionsprüfungen.
Anschließend prüft das Menü die unterstützten Verwaltungsschnittstellen.
Die Paketnummer wird immer ausdrücklich ausgewählt, auch bei einem Paket.
Version, Revision und Hash werden aus dem geprüften Paket angezeigt.
Mehrere Pakete führen nie zu einer automatischen Auswahl des neuesten Pakets.
Die geprüften Bytes werden für den Aufruf in einen privaten temporären Ordner
übernommen. Dieser wird nach Ende des Aufrufs aufgeräumt. Bei SIGKILL/Stromausfall
kann ein temporärer Ordner zurückbleiben; er enthält keine vom Setup erfassten
Passwörter oder Kundendaten. Keine automatischen globalen Aufräumaktionen.

MENÜ UND BESTEHENDE AUFRUFE
1 Installieren: authentischer install-bootstrap.py mit --package, --signature
  und --public-key. Nur bei fehlender Installation und ohne offenen Vorgang.
2 Fortsetzen: derselbe Bootstrap plus --resume. Installation.json und zugehöriges
  Operationsjournal müssen konsistent sein; Revision UND exakter Paket-Hash
  müssen passen. Keine Änderung oder Löschung von Journalstatuswerten.
3 Reparieren: installierter btctrader-admin repair --package ... --signature ...
  Nur bei abgeschlossener Installation und Paket mit gleicher Zielrevision.
4 Android-App: btctrader-admin apk-download --host 127.0.0.1.
  Bestehender Loopback-Download; administrativer SSH-Tunnel/SFTP erforderlich.
  Keine öffentliche Freigabe. Originaldialog beendet den Download bewusst.
5 Smartphone: btctrader-admin pair --host ... --port ...; bei Ersatz --replacement.
  Originaldialoge bieten QR oder Link auf demselben Handy. TTL/Einmaligkeit bleiben.
  Ersatzkopplung beendet nicht nachweislich sofort alle bestehenden alten Tunnel.
6 Passwort: runuser -u btctrader -- /usr/bin/dotnet
  /opt/btctrader/BTC_TRADER_PRO.dll --set-local-password
  Nur mit vorhandener Identitäts- UND Passwortdatei, passender Verwaltung und
  unveränderten Programmdateien laut geschütztem Produktinventar.
  Der native Dialog erfasst das neue Passwort zweimal verdeckt.
  Benutzername bleibt erhalten. Bestehende Websitzungen werden ungültig.
  Das Setup stoppt oder startet hierfür keinen Dienst. Kein Passwortprotokoll.
7 Backup: btctrader-admin backup ABSOLUTER_DATEIPFAD.
  Normales age-verschlüsseltes Backup; Ziel darf noch nicht vorhanden sein.
  Dienststopp, Wiederanlauf, Verschlüsselung und Fehlerbehandlung bleiben Sache
  der vorhandenen Backupengine. Das age-Passwort getrennt sicher aufbewahren.
8 Wiederherstellen: btctrader-admin restore ABSOLUTER_DATEIPFAD.
  Ersetzt vorhandenen Kundenzustand. Vorher aktuellen Stand sichern.
  Originalbestätigung und Originalprüfung bleiben bestehen.
9 VPS-Umzug: Auswahl zwischen Backup am Alt-VPS mit --migration-source und
   btctrader-admin migrate ABSOLUTER_DATEIPFAD am Ziel.
   Quelle bleibt gestoppt. Ziel muss bereits installiert sein. Zielidentität
   bleibt nach dem vorhandenen Migrationsvertrag erhalten; neu koppeln.
   Keine automatische Übertragung und keine parallele Handelsfreigabe.
10 Nach Updates suchen: btctrader-admin updates. Vorhandene signierte Discovery;
   kann wie bisher den lokalen Updatehinweis aktualisieren. Kein automatisches Update.
11 Update installieren: lokale authentische Paketauswahl, dann vorhandener
   btctrader-update apply --package ... --signature ...
   Ausgangsrevision muss passen. Nur ein regulärer Revisionsschritt; kein Downgrade.
12 Entfernen, Daten behalten: btctrader-admin uninstall mit Originalbestätigung.
13 Vollständig löschen: btctrader-admin purge mit Originalbestätigungen.
   Endgültiger Datenverlust! Nur nach bewusstem Entschluss und externem Backup.
0 Beenden.

ABSOLUTER_DATEIPFAD ist oben eine Beschreibung, kein ausführbarer Beispielbefehl.
Die tatsächlichen Pfade werden im Menü abgefragt und als getrennte Argumente
übergeben. Keine Shellauswertung von Benutzereingaben.

INSTALLATIONSABBRUCH UND OFFENE WARTUNG
Das Menü liest nur die vorhandenen Belege. Bei einer fehlgeschlagenen INSTALL-
Operation wird Resume angeboten, auch wenn /opt/btctrader noch gar nicht besteht.
Bei widersprüchlichen, unlesbaren oder fremden offenen Wartungsjournalen werden
Aktionen abgewiesen. Kein automatisches recover, kein Purge, kein Journalreset.
Die zugrunde liegende Engine prüft den Zustand beim Aufruf innerhalb desselben
Operationslocks erneut; sie verwendet unverändert ihre Journale und Recoveryregeln.
Fortsetzung abgebrochener Uninstall-/Purge-Vorgänge ist nicht als zusätzliche
Setupfunktion implementiert; hierfür ist gezielte Prüfung mit den vorhandenen
CLI-Möglichkeiten erforderlich. Ein CLI-Fehler wird nicht als Erfolg ausgegeben.

VERSIONSVERTRAG
Kein fest codiertes R0007/R0008 und keine feste Produktrevision im Menü.
Unterstützt wird der bestehende Kunden-V2-Vertrag (net10.0/linux-x64,
Paket-Schemaversion 1, minInstallerVersion genau 2, fortlaufende Revision).
Es werden vollständige Kundenpakete einschließlich signiertem APK-Inventar
unterstützt. Teilpakete ohne APK-Nachweis werden bereits vor der Aktion
abgewiesen; nicht erst nach einem Update. Die kanonischen R0008-/R0009-Pakete
enthalten diese Nachweise. Keine neue APK wird durch das Setup erzeugt.
Die vollständigen signierten Dateiinventare werden mit product.json und den
installierten Werkzeugdateien (Bytes, Größe, Modus, Pfade und Root-Eigentum)
verglichen. Der Passwortdialog prüft zusätzlich seine nativen Programmdateien;
der Updateabschluss prüft sämtliche Dateien des Zielpakets. Beschädigte andere
Programmdateien können weiterhin durch die Original-Repair-Funktion ersetzt
werden, sofern die ausführenden Werkzeuge selbst unverändert nachgewiesen sind.
Nicht inventarisierte Verwaltungsdateien werden abgewiesen. Python-Bytecode
wird für die Verwaltungsimporte nicht als Ausführungsquelle verwendet.

Das signierte Paket DER INSTALLIERTEN Revision und seine .sig müssen neben
start.sh verfügbar bleiben. Auch nach einem außerhalb des Setups ausgeführten
Update dessen Paket dort ablegen. Für ein neues Update werden aktuelles Paket
als Bestandsnachweis und Zielpaket für den Updateauftrag benötigt. Sie werden
nicht allein durch ihre Anwesenheit installiert oder repariert.
Ein Paket kann nur mit tatsächlich gültiger .sig akzeptiert werden.
Der Dateiname ersetzt weder die Signatur noch die Paketmetadaten.
Fehlende, mehrdeutige oder widersprüchliche Nachweise führen zur Verweigerung.

Der ursprüngliche INSTALL-Beleg darf seine alte Revision behalten. Die
FINALIZED-UPDATE-Kette muss lückenlos bis zum aktuellen Inventar reichen.
Repair derselben Revision, abgeschlossene Backups/Restores und ein korrektes
Update-Rollback sind berücksichtigt. Offene Wartung/RECOVERY_REQUIRED wird
nicht automatisch repariert. Nur die bisherige ausdrückliche Fortsetzung einer
abgebrochenen Erstinstallation mit exakt demselben Paket bleibt verfügbar.
Keine Journaländerung durch das Setup.

Signatur und Installer-Kompatibilität werden getrennt geprüft. Unterstützt werden
Installervertrag exakt 2 und die bestehenden Paket-/Journalschemas. Maßgeblich
ist minInstallerVersion im signierten Paket. Erforderliche Werkzeuge und die
Aufrufsignaturen von main() und common.lock(directory) werden weiterhin geprüft.
Funktionskörper und Meldungstexte sind keine Kompatibilitätspins. Der Herausgeber
muss bei inkompatiblen CLI-/Lockänderungen die benötigte Installer-Version erhöhen;
ein passender Versionswert ersetzt keine Releaseprüfung. Geänderte Schemas oder
Aufrufsignaturen erfordern weiterhin bewusst geprüfte Setup-Unterstützung.
Keine feste Laufzeitobergrenze für Produktrevisionen. Zukünftige kompatible
Revisionen müssen den erhaltenen Vertrag erfüllen. Das ist kein Versprechen
für beliebige künftige Produktänderungen.
Der bestehende öffentliche Signaturprüfschlüssel bleibt gepinnt. Keine Schlüsselrotation.

Unmittelbar vor der CLI-Ausführung prüft der Runner den Bestand erneut unter
dem vorhandenen Operationslock. Für Wartungsaktionen hält er dessen exklusiven
Lock bis zum Ende und übergibt dieselbe Sperre innerhalb dieses Prozesses an
den bestehenden common.lock-Kontext. Keine doppelte flock-Übernahme und keine
Prüf-/Aufruflücke. Verschachtelte oder threadfremde Übernahme wird verweigert.
Pairing, APK-Download und Passwortdialog halten nur einen Shared-Lock, der
parallele Produktupdates ausschließt, den bestehenden Submit-Shared-Lock aber
nicht blockiert. Der Lock endet mit dem Prozess, auch bei Fehler/Abbruch.
Bei konkurrierender Wartung Vorgang später erneut ausdrücklich starten.
Die flüchtige Operationslockdatei darf wie bei common.lock nach einem Neustart
neu entstehen. Operationsverzeichnis und Journale müssen bereits gültig sein;
keine Journalanlage, kein Journalreset durch diese Prüfung.

Verwaltungsimporte verwenden die authentifizierten installierten Pythonbytes
im Arbeitsspeicher; keine dauerhafte zweite Werkzeuginstallation. Die
bytegleichen, vertragsgeprüften Schemas bleiben im Setup-Vendorbereich auch
während Update/Deinstallation verfügbar. OS-Verwaltung, Backup, Journale,
Recovery und Update bleiben vollständig bei den vorhandenen Produktfunktionen.

SYSTEMWEITE AUSWIRKUNGEN
Das Startmenü verändert beim Anzeigen keinen Produktzustand. Nach ausdrücklicher
Auswahl können die aufgerufenen Originalfunktionen Änderungen vornehmen:
Installation/Repair insbesondere APT-Abhängigkeiten, SSH-Snippet und SSH-Reload,
systemd daemon-reload, eigene Benutzer/Units/Wrapper sowie Produktverzeichnisse.
Das Setup beseitigt keine offenen VPS-Kollisionen. Die bisherige Prüfung lautet
UNCONFIRMED; gemeinsame VPS-Installation erst nach Abschluss der offenen Prüfung.
Keine zusätzlichen Listener, Dienste oder Datenbanken durch das Setup selbst.

TESTGRENZEN
Automatisierte Prüfungen verwenden signierte synthetische Pakete, temporäre
Produktverzeichnisse, die Original-CLI und Originaltransaktionen. Systemd,
Benutzer-/SSH-Verwaltung, native Passwort-/Pairingdialoge, Zustandsvalidator und
age-Terminalinteraktion werden an den Systemgrenzen durch Test-Doubles ersetzt.
Die echten R0008-/R0009-Pakete werden separat kryptografisch geprüft.
Das ersetzt keinen Ubuntu-Praxistest von Installation, Restore, Pairing und
privaten Terminaldialogen. Keine produktive Installation durch diese Entwicklung.

RÜCKMELDUNGEN IN V1.2
Nach jeder gewählten Aktion bleibt die Rückmeldung sichtbar, bis Sie Enter
für die Rückkehr zum Hauptmenü drücken. Abbruch und Fehler melden keinen Erfolg.
Backup meldet Erfolg nur nach erfolgreichem Originalaufruf und vorhandener,
nichtleerer Backupdatei; der tatsächlich verwendete Pfad wird angezeigt.
Updateprüfung verwendet weiterhin btctrader-admin updates. Die Quelle stammt
aus der konfigurierten UpdateRegistry. Nur deren erfolgreich geprüfter,
signierter Manifeststand darf „Kein Update verfügbar“ oder „Neue Version
verfügbar“ auslösen. Fehlende Quelle, Timeout, ungültige Ausgabe oder Fehler
werden als „Updateprüfung nicht möglich“ gemeldet; kein Rückgriff auf alten Cache.
Nach einem lokalen Update werden Produktrevision, Produktversion, Inventar und
Dateihashes des ausgewählten Pakets nachgelesen. Exitcode 0 allein genügt nicht.
Diese Prüfung bestätigt installierte Dateien; keine zusätzliche Handelsfreigabe.

Farben werden nur im geeigneten Terminal verwendet (NO_COLOR wird beachtet).
Auf schmalen Terminals werden Setuptexte umgebrochen. Originaldialoge der
aufgerufenen Programme bleiben unverändert und können weiterhin längere Zeilen
enthalten. Die Gesamthöhe des Menüs kann Scrollen erfordern.
Keine Signierung und keine neue Kundenrevision durch dieses Setup.

R0008-ENTWICKLUNGSINTEGRATION
Die farbige Menüführung bleibt erhalten; die Anzeige lautet Setup V1.2. Verwaltung und Paketprüfung werden
beim Zusammenstellen aus den geprüften kanonischen Produktwerkzeugen übernommen.
source/setup ist allein noch kein ausführbares Auslieferungspaket. Vendor-Prüfer
und Schnittstellenmanifest entstehen aus den kanonischen Setup-Prüfwerkzeugen.
Paketwerkzeuge werden unabhängig anhand des signierten Inventars geprüft.
Kein Produkt wird allein aufgrund dieser README zur Installation freigegeben.

Die R0008-LIVE-Berechtigung benötigt zusätzlich zur bezahlten Lizenz einen
kryptografischen Nachweis des gebundenen Smartphone-Schlüssels, gültig 30 Tage.
Ein neuer Schlüssel übernimmt keine frühere Zahlung. Derselbe Schlüssel erneuert
bei erfolgreicher nativer Verbindung die Bestätigung ohne Änderung der Adresse.
Eine Zahlung allein erneuert diese Frist nicht. TEST bleibt lizenzfrei.
Beim VPS-Umzug: Quellanker unabhängig an der vertrauenswürdigen Quelle prüfen,
Original-Smartphone behalten und Quellinstallation gesperrt lassen. Ohne diese
Nachweise ist nur Datenrettung vorgesehen. Der neue native Migrationsdialog
fragt den Quellanker ab; das Setup erstellt keine eigene Migrationsentscheidung.
Die externe zeitliche Dongle-Freigabe ist kein übertragbarer Backupbestandteil.
Vollständige VPS-Klone und gezielte Root-/Zeitmanipulation sind Schutzgrenzen.

R0008 benötigt Installervertrag 2: Die neue Fassung ist LIVE-fähig, startet aber
mit deaktiviertem LIVE-Handel. Alte R0007-Verwaltungswerkzeuge weisen dieses Paket
vor der Installation ab. Es ist kein automatischer R0007-Lizenzupgrade vorgesehen.
Die Paketsignatur allein ist keine Freigabe für produktiven Echtgeldbetrieb.

KOMPATIBILITÄTSKORREKTUR FÜR SIGNIERTE BESTANDSPAKETE
Setup-interner Vertragsstand 3, weiterhin Installervertrag 2 / Setup V1.2.
Der aktuelle Vendor-Prüfer unterstützt das HTTPS-Kontextprotokoll mit sicherem
close() auch bei Redirects und Fehlern. Bei Setup-Aufrufen authentifizierter
Bestandswerkzeuge ergänzt der Runner ausschließlich diese beiden Methoden an
der vorhandenen PinnedHTTPS-Klasse im Arbeitsspeicher. Keine Datei der
Installation oder des signierten Pakets wird dafür umgeschrieben.
DNS-/Public-IP-, TLS-, Redirect-, Größen- und Signaturprüfungen bleiben erhalten.
Diese Brücke wirkt nur innerhalb dieses Setup-Runners. Direkt gestartete alte
Verwaltungsprogramme und deren Discovery-Timer enthalten weiterhin den alten
Fehler; dauerhaft wird er erst mit einem später genehmigten Kundenpaket mit
der korrigierten artifacts.py behoben. R0012 wird nicht neu gepackt/signiert.
Für eine frische Installation genügt das vollständige aktuelle signierte Paket.
Eine Bestandsinstallation benötigt für Updates weiterhin jeden unterstützten
Revisionsschritt; kein Überspringen der signierten Updatekette.
