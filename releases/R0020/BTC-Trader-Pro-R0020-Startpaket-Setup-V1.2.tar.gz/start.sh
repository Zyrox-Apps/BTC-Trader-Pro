#!/bin/bash
set -eu
if [ "$(id -u)" -ne 0 ]; then
  echo 'Bitte mit sudo bash start.sh starten.' >&2
  exit 1
fi
if ! command -v python3 >/dev/null 2>&1; then
  echo 'Python 3 fehlt. Zuerst das Ubuntu-Paket python3 installieren lassen.' >&2
  exit 1
fi
setup_dir="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
exec /usr/bin/python3 -I -B "$setup_dir/setup.py"
