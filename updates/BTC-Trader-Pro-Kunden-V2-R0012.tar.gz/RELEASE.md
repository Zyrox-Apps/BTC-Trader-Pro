BTC Trader Pro 2.0.0-kunden-v2-r0012 (revision 18). Execution policy: runtime-gated-v1. Installation und LIVE-Betrieb erfordern die jeweiligen Freigaben.
