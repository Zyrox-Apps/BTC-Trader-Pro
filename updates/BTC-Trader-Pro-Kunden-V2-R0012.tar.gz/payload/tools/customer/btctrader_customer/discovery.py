"""The update contract is a locator; exact-byte Ed25519 authenticates releases."""
import json,pathlib,tempfile,urllib.request
from .common import strict_json,safe,write_json,digest,atomic,lock
from .artifacts import manifest,download,public_url
class Rpc:
 def __init__(self,url):self.url=url
 def call(self,method,*params):
  if method not in {'eth_chainId','eth_call','eth_getCode','eth_blockNumber','eth_getBlockByNumber'}:raise ValueError('RPC write forbidden')
  body=json.dumps({'jsonrpc':'2.0','id':1,'method':method,'params':params}).encode()
  with urllib.request.urlopen(urllib.request.Request(self.url,body,{'Content-Type':'application/json','User-Agent':'BTC-Trader-Pro/2.0'}),timeout=15) as r:result=strict_json(r.read(1024*1024))
  if result.get('id')!=1 or result.get('jsonrpc')!='2.0' or 'error' in result:raise ValueError('RPC response')
  return result['result']
def source(rpc,address,codehash):
 if int(rpc.call('eth_chainId'),16)!=8453:raise ValueError('chain')
 code=bytes.fromhex(rpc.call('eth_getCode',address,'latest')[2:])
 if '0x'+digest(code)!=codehash:raise ValueError('update registry code pin')
 raw=bytes.fromhex(rpc.call('eth_call',{'to':address,'data':'0x57de26a4'},'latest')[2:])
 if len(raw)<64 or int.from_bytes(raw[:32],'big')!=32:raise ValueError('ABI string')
 size=int.from_bytes(raw[32:64],'big')
 if size>2048 or len(raw)!=64+((size+31)//32)*32 or any(raw[64+size:]):raise ValueError('ABI size/padding')
 url=raw[64:64+size].decode('ascii')
 if url:public_url(url)
 return url
def discover(root=pathlib.Path('/opt/btctrader'),rpc=None,key_path=pathlib.Path('/usr/share/btctrader/release-public.key'),checkpoint_path=pathlib.Path('/var/lib/btctrader-operations/discovery.json')):
 config=strict_json(safe(root/'customer-v1.json').read_bytes());product=strict_json(safe(root/'product.json').read_bytes())
 def disabled():
  with lock(checkpoint_path.parent):
   if strict_json(safe(root/'customer-v1.json').read_bytes())!=config:raise ValueError('discovery configuration changed')
   result={'enabled':False,'steps':[]};write_json(root/'update-status.json',result);(root/'update-status.json').chmod(0o644);return result
 if not config['UpdateRegistryAddress']:return disabled()
 if rpc is None:rpc=Rpc('https://mainnet.base.org')
 base=source(rpc,config['UpdateRegistryAddress'],config['UpdateRegistryCodeHash'])
 if not base:return disabled()
 key=safe(key_path).read_bytes();data=download(base,'latest.json',1024*1024);signature=download(base,'latest.json.sig',64)
 # Downloads occur outside the maintenance lock. Re-read authoritative state
 # after acquiring it, so timer/menu cannot roll the checkpoint back.
 with lock(checkpoint_path.parent):
  if strict_json(safe(root/'customer-v1.json').read_bytes())!=config or safe(key_path).read_bytes()!=key:raise ValueError('discovery configuration changed')
  product=strict_json(safe(root/'product.json').read_bytes())
  path=checkpoint_path;previous=strict_json(safe(path).read_bytes()) if path.exists() else None
  info,steps,checkpoint=manifest(data,signature,key,product['revision'],previous);write_json(path,checkpoint)
  result={'enabled':True,'baseUrl':base,'latestRevision':info['latestRevision'],'steps':steps,'android':info.get('android')}
  write_json(root/'update-status.json',result);(root/'update-status.json').chmod(0o644);return result

def apply_discovered(root=pathlib.Path('/opt/btctrader')):
 from .update import Updater
 from .artifacts import package
 info=discover(root);key=safe('/usr/share/btctrader/release-public.key').read_bytes()
 if not info['enabled']:return []
 results=[]
 for step in info['steps']:
  data=download(info['baseUrl'],step['package'],step['size']);sig=download(info['baseUrl'],step['signature'],64)
  if len(data)!=step['size'] or digest(data)!=step['sha256']:raise ValueError('manifest package binding')
  meta,_=package(data,sig,key)
  if meta['fromRevision']!=step['fromRevision'] or meta['toRevision']!=step['toRevision']:raise ValueError('manifest revision binding')
  with tempfile.TemporaryDirectory(prefix='update-download-') as tmp:
   archive=pathlib.Path(tmp)/step['package'];signature=pathlib.Path(tmp)/step['signature'];atomic(archive,data);atomic(signature,sig);Updater(root).apply(archive,signature,key)
  results.append(step['toRevision'])
 return results
