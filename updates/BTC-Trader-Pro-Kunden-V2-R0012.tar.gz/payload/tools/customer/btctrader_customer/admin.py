"""Local customer administration; no parallel updater and no LIVE activation."""
import argparse,os,pathlib,subprocess,sys,re,shutil,pwd
from .common import safe,strict_json

def show_pairing_qr(link,png):
 # ANSIUTF8 packs two module rows into one terminal row. Four modules of quiet zone.
 encoded=subprocess.run(['qrencode','-t','ANSIUTF8','-l','M','-m','4'],input=link,capture_output=True,text=False,check=True).stdout.decode('utf-8')
 plain=re.sub(r'\x1b\[[0-9;]*m','',encoded);lines=plain.splitlines()
 columns,rows=shutil.get_terminal_size(fallback=(80,24))
 if sys.stdout.isatty() and max(map(len,lines),default=0)<=columns-1 and len(lines)<=rows-8:
  print(encoded,end='')
  print('Mit der normalen Handykamera scannen und BTC Trader Pro öffnen.')
  return True
 print('Der vollständige QR-Code passt nicht in dieses Terminal; er wird nicht abgeschnitten.')
 print('PNG (nur während dieses Dialogs vorhanden): '+str(png))
 print('PNG über die bestehende SSH/SFTP-Verbindung lokal öffnen und vollständig anzeigen; anschließend mit der Handykamera scannen.')
 print('Alternativ Terminal vergrößern und danach einen neuen Pairing-QR erzeugen. Quiet-Zone nicht beschneiden.')
 return False

def deliver_pairing(link,png):
 print('A. Mit anderem Gerät QR scannen')
 print('B. Auf diesem Handy Pairing-Link übernehmen')
 delivery=input('Auswahl [A/B]: ').strip().upper()
 if delivery=='B':
  if not sys.stdout.isatty():raise ValueError('PAIRING_PRIVATE_TERMINAL_REQUIRED')
  print('Einmaliger privater Pairing-Link: In BTC Trader Pro unter Koppeln einfügen. Nicht weitergeben und nicht als Shellbefehl ausführen.')
  print(link.decode('ascii'))
  print('Dieser Link wird nicht in einer Datei oder Shell-History gespeichert. Terminal nach Übernahme schließen; nicht protokollieren.')
 elif delivery=='A':show_pairing_qr(link,png)
 else:raise ValueError('PAIRING_DELIVERY_INVALID')

def heading(text):
 color=sys.stdout.isatty() and os.environ.get('TERM','')!='dumb' and 'NO_COLOR' not in os.environ
 print(('\033[38;5;208m'+text+'\033[0m') if color else text)

def guided():
 heading('BTC TRADER PRO')
 heading('KUNDEN-VERWALTUNG')
 actions={'1':'pair','2':'apk-download','3':'updates','4':'update','5':'backup','6':'restore','7':'migrate','8':'repair','9':'uninstall','10':'purge'}
 for title,items in [('ANDROID',['1. Handy verbinden / koppeln','2. Android-App herunterladen']),('UPDATES',['3. Nach Updates suchen','4. Update installieren']),('DATENSICHERUNG',['5. Backup erstellen','6. Backup wiederherstellen','7. Auf neuen VPS umziehen']),('WARTUNG',['8. Installation reparieren']),('PROGRAMM ENTFERNEN',['9. Programm entfernen – Daten behalten','10. Programm und Daten vollständig löschen'])]:
  print();heading(title)
  for item in items:print(item)
 print('\n0. Beenden')
 choice=input('Auswahl: ').strip()
 if choice=='0':return False
 action=actions.get(choice)
 if not action:raise ValueError('Bitte eine angezeigte Nummer wählen.')
 args=[action]
 if action in {'backup','restore','migrate'}:args.append(input('Vollständiger Backupdateipfad: ').strip())
 if action=='backup' and input('Für VPS-Umzug: Alttrading nach Backup gestoppt lassen? [ja/NEIN]: ').strip().lower()=='ja':args.append('--migration-source')
 if action=='repair':args+=['--package',input('Authentisches Paket: ').strip(),'--signature',input('Paket-Signatur: ').strip()]
 if action in {'pair','apk-download'}:
  args+=['--host',input('Vom Handy erreichbare Serveradresse: ').strip()]
  if action=='pair':
   print('1. Erstes Handy verbinden')
   print('2. Handy erneut verbinden / ersetzen (auch nach App-Neuinstallation)')
   print('3. Hilfe bei Verbindungsproblemen')
   mode=input('Auswahl: ').strip()
   if mode=='3':
    print('Server muss aus dem Handynetz erreichbar sein. Bei gleichem App-Profil zunächst Verbindung erneut versuchen.')
    print('Nach Deinstallation sind Geräteschlüssel verloren: Ersatzkopplung verwenden. Private Geräteschlüssel werden nicht wiederhergestellt.')
    return False
   if mode not in {'1','2'}:raise ValueError('Bitte Erst- oder Ersatzkopplung wählen.')
   if mode=='2':args.append('--replacement')
   args+=['--port',input('Vorhandener SSH-Port (normal 22): ').strip() or '22']
 sys.argv+=args
 return True

def confirm_action(action):
 explanations={
  'update':'Ein signiertes Update wird geprüft und installiert. Der Trader wird dafür kurz sicher angehalten.',
  'restore':'Dieses Backup ersetzt den Kundenzustand derselben Installation. Aktuellen Stand vorher sichern.',
  'migrate':'Nur bei gestopptem Alt-VPS fortfahren. Zielidentität bleibt erhalten; Backup-Referenz wird geprüft. Handy am Ziel erneut koppeln.',
  'repair':'Reparatur aus einem authentischen Paket. Kundendaten bleiben erhalten; der Dienst wird kurz angehalten.',
  'uninstall':'Programm und eigene Dienste werden entfernt. Kundendaten bleiben für spätere Wiederherstellung erhalten.',
  'purge':'Programm, Kundendaten und lokale Schlüssel werden endgültig gelöscht. Ein externes Backup ist danach die einzige Rückkehrmöglichkeit.'}
 if action in explanations:
  print(explanations[action])
  if input('Fortfahren? [ja/NEIN]: ').strip().lower()!='ja':raise ValueError('Vorgang abgebrochen; keine Änderung.')

def main():
 if len(sys.argv)==1 and not guided():return
 p=argparse.ArgumentParser(description='BTC Trader Pro lokale Verwaltung');sub=p.add_subparsers(dest='action',required=True)
 i=sub.add_parser('install');i.add_argument('--package',required=True);i.add_argument('--signature',required=True);i.add_argument('--public-key',required=True);i.add_argument('--resume',action='store_true')
 r=sub.add_parser('repair');r.add_argument('--package',required=True);r.add_argument('--signature',required=True)
 sub.add_parser('uninstall').add_argument('--resume',action='store_true');sub.add_parser('purge').add_argument('--resume',action='store_true');sub.add_parser('instance');sub.add_parser('updates');sub.add_parser('update')
 b=sub.add_parser('backup');b.add_argument('file');b.add_argument('--migration-source',action='store_true',help='Backup erstellen und Alttrading für VPS-Migration gestoppt lassen')
 for mode in ['restore','migrate']:
  s=sub.add_parser(mode);s.add_argument('file')
  if mode=='migrate':s.add_argument('--source-anchor',help='Unabhängig am ursprünglichen VPS geprüfter Quellanker SHA256; ohne Angabe keine LIVE-Lizenzübernahme')
 d=sub.add_parser('apk-download');d.add_argument('--bind',default='127.0.0.1');d.add_argument('--host',required=True);d.add_argument('--port',type=int,default=38084)
 q=sub.add_parser('pair');q.add_argument('--host',required=True);q.add_argument('--port',required=True,type=int);q.add_argument('--replacement',action='store_true')
 a=p.parse_args()
 if os.geteuid()!=0:raise PermissionError('Bitte mit sudo starten.')
 confirm_action(a.action)
 if a.action=='pair' and a.replacement:
  print('Ersatzkopplung ersetzt das bisher autorisierte Handy nach erfolgreichem Schlüsselproof. Alte App-Keys werden nicht rekonstruiert.')
  print('Bewusste neue Kopplung: neue unbezahlte Lizenzreferenz, auch mit demselben Gerät. Alte Zahlungen und Restlaufzeiten werden nicht übertragen.')
  if input('Ersatzkopplung ausdrücklich erlauben? [ja/NEIN]: ').strip().lower()!='ja':return
 from .install import Installer,ROOT
 if a.action=='install':Installer().install(pathlib.Path(a.package),pathlib.Path(a.signature),safe(a.public_key).read_bytes(),resume=a.resume)
 elif a.action=='repair':
  from .update import Updater
  receipt=pathlib.Path('/var/lib/btctrader-operations/installation.json')
  key=safe('/usr/share/btctrader/release-public.key').read_bytes()
  if receipt.exists() and strict_json(receipt.read_bytes())['state']!='FINALIZED':Installer().install(pathlib.Path(a.package),pathlib.Path(a.signature),key,resume=True)
  else:Updater().apply(pathlib.Path(a.package),pathlib.Path(a.signature),key,repair=True,before_health=lambda:Installer().repair_structure(key))
 elif a.action in {'uninstall','purge'}:Installer().uninstall(a.action=='purge',resume=a.resume)
 elif a.action=='instance':
  from .instance import main as serve
  sys.argv=[sys.argv[0]];serve()
 elif a.action=='update':
  from .discovery import apply_discovered
  print(apply_discovered())
 elif a.action=='updates':
  from .discovery import discover
  import json;print(json.dumps(discover(),indent=2))
 elif a.action in {'backup','restore','migrate'}:
  from .backup import Backup
  if a.action=='backup':Backup().create(pathlib.Path(a.file),migration_source=a.migration_source)
  else:
   pin=None
   if a.action=='migrate':
    pin=a.source_anchor
    if pin is None:
     print('LIVE-Lizenzübernahme nur mit ursprünglichem Geräteschlüssel und unabhängig verifiziertem Quellanker.')
     pin=input('Separat am Quell-VPS geprüfter Anker SHA256 (leer: nur Datenrettung ohne Lizenzübernahme): ').strip() or None
   Backup().restore(pathlib.Path(a.file),a.action=='migrate',source_anchor=pin)
 elif a.action=='apk-download':
  from .download import serve
  product=strict_json((ROOT/'product.json').read_bytes());serve(ROOT/'android'/product['android']['file'],a.bind,a.port,advertised_host=a.host,expected_sha256=product['android']['sha256'],expected_size=product['android']['size'])
 elif a.action=='pair':
  # Ephemeral QR remains owner-only; no reset or replacement of existing binding.
  import tempfile
  with tempfile.TemporaryDirectory(prefix='btctrader-pair-') as tmp:
   subprocess.run(['python3',str(ROOT/'tools/transport/pairing_service.py'),'--database','/var/lib/btctrader-pairing/pairing.db','mint','--host',a.host,'--port',str(a.port),'--host-public','/etc/ssh/ssh_host_ecdsa_key.pub','--qr-file',tmp+'/pair.url','--qr-image',tmp+'/pair.png']+(['--replacement'] if a.replacement else []),check=True)
   link=pathlib.Path(tmp+'/pair.url').read_bytes();png=pathlib.Path(tmp+'/pair.png')
   # Permit the invoking sudo operator to retrieve only the temporary QR PNG via
   # their own existing SFTP login; no root SSH login or world-readable file.
   operator=os.environ.get('SUDO_UID','')
   if operator.isdecimal() and int(operator)>0:
    user=pwd.getpwuid(int(operator));os.chown(png,user.pw_uid,user.pw_gid);os.chown(tmp,user.pw_uid,user.pw_gid)
   print('Mit der normalen Handykamera scannen, BTC Trader Pro öffnen und Kopplung bestätigen.')
   print('Dieser QR gilt fünf Minuten und ist einmalig. Ein abgelaufener QR muss neu erzeugt werden.')
   deliver_pairing(link,png)
   input('Pairing-QR jetzt in Kunden-App übernehmen; danach Enter zum Entfernen: ')
