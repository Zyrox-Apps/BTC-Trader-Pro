// BTC Trader Pro customer App-ID boundary. Unknown explicit IDs remain rejected.
// Browser calls without appId use btc-trader-pro.

const DEFAULT_APP_ID =
    "btc-trader-pro";

const ALLOWED_APP_IDS =
    new Set([
        "btc-trader-pro"
    ]);

const APP_ID =
    (() => {

        const params =
            new URLSearchParams(
                window.location.search);

        const supplied =
            params.get(
                "appId");


        // Bestehender Browser-/Beta-Aufruf ohne Parameter.
        if (
            supplied === null
            ||
            supplied.trim() === ""
        ) {
            return DEFAULT_APP_ID;
        }


        const normalized =
            supplied
                .trim()
                .toLowerCase();


        if (
            ALLOWED_APP_IDS.has(
                normalized)
        ) {
            return normalized;
        }


        throw new Error(
            "Ungültige BTC-Trader AppId: "
            +
            normalized);
    })();


const TOKEN_KEY =
    "appmgmt_m3_token:" + APP_ID;

const DEVICE_KEY =
    "appmgmt_device_id:" + APP_ID;


// ==========================================================
// M5.1L · UI THEME SYSTEM
// ==========================================================

const UI_THEME_KEY =
    "btcTraderUiTheme:" + APP_ID;

const UI_THEMES =
    new Set([
        "dark",
        "light"
    ]);


// UI state only; authentication authority is the HttpOnly local session cookie.
let token = "local-session";
let localCsrfToken = "";

let deviceId =
    localStorage.getItem(DEVICE_KEY) || "";

let traderTimer = null;
let traderRefreshBusy = false;
let traderRefreshPending = false;
let pageVisibilityGeneration = 0;

if (!deviceId) {
    deviceId =
        crypto.randomUUID
            ? crypto.randomUUID()
            : Date.now() + "-" + Math.random();

    localStorage.setItem(
        DEVICE_KEY,
        deviceId);
}



// ==========================================================
// M5.1L · UI THEME SYSTEM
//
// UI Dark bleibt Standard.
// UI Hell wird lokal auf diesem Gerät gespeichert.
// Keine Server-/Trader-/Config-Abhängigkeit.
// ==========================================================

function readStoredUiTheme() {

    try {

        const stored =
            localStorage.getItem(
                UI_THEME_KEY
            );


        if (UI_THEMES.has(stored))
            return stored;
    }
    catch {
    }


    return "dark";
}


function updateUiThemeControl(
    theme) {

    const light =
        theme === "light";


    const toggle =
        document.getElementById(
            "uiThemeToggle"
        );

    const state =
        document.getElementById(
            "uiThemeState"
        );


    if (toggle)
        toggle.checked = light;


    if (state) {
        state.textContent =
            light
                ? "HELL"
                : "DUNKEL";
    }
}


function applyUiTheme(
    theme,
    persist = false,
    redrawChart = false) {

    const normalized =
        theme === "light"
            ? "light"
            : "dark";


    document
        .documentElement
        .setAttribute(
            "data-theme",
            normalized
        );


    document
        .documentElement
        .style
        .colorScheme =
            normalized;


    const meta =
        document.querySelector(
            'meta[name="theme-color"]'
        );


    if (meta) {

        meta.setAttribute(
            "content",
            normalized === "light"
                ? "#f3f5f8"
                : "#10151d"
        );
    }


    if (persist) {

        try {

            localStorage.setItem(
                UI_THEME_KEY,
                normalized
            );
        }
        catch {
        }
    }


    updateUiThemeControl(
        normalized
    );


    if (redrawChart) {

        window.requestAnimationFrame(
            () => {

                try {

                    if (
                        typeof renderMarketChart ===
                        "function"
                    ) {
                        renderMarketChart();
                    }
                }
                catch {
                }
            }
        );
    }


    try {

        window.dispatchEvent(
            new CustomEvent(
                "btctrader-themechange",
                {
                    detail: {
                        theme:
                            normalized
                    }
                }
            )
        );
    }
    catch {
    }
}


function initUiThemeMenuControl() {

    const hub =
        document.getElementById(
            "settingsHub"
        );


    if (!hub)
        return;


    let block =
        document.getElementById(
            "uiThemeMenuBlock"
        );


    if (!block) {

        block =
            document.createElement(
                "div"
            );

        block.id =
            "uiThemeMenuBlock";

        block.className =
            "settings-theme-block";


        block.innerHTML = `
            <div class="settings-theme-row">

                <div class="settings-theme-icon"
                     aria-hidden="true">
                    ◐
                </div>

                <div class="settings-theme-copy">

                    <strong>
                        Design
                    </strong>

                    <small>
                        UI Dark / UI Hell
                    </small>

                </div>

                <label class="settings-theme-switch"
                       title="Zwischen UI Dark und UI Hell wechseln">

                    <input id="uiThemeToggle"
                           type="checkbox"
                           aria-label="UI Hell aktivieren">

                    <span class="settings-theme-switch-track">
                    </span>

                    <span id="uiThemeState"
                          class="settings-theme-switch-text">
                        DUNKEL
                    </span>

                </label>

            </div>
        `;


        hub.insertBefore(
            block,
            hub.firstChild
        );


        const toggle =
            document.getElementById(
                "uiThemeToggle"
            );


        if (toggle) {

            toggle.addEventListener(
                "change",
                () => {

                    applyUiTheme(
                        toggle.checked
                            ? "light"
                            : "dark",
                        true,
                        true
                    );
                }
            );
        }
    }


    updateUiThemeControl(
        readStoredUiTheme()
    );
}


/*
 * Haupt-JS übernimmt den Zustand erneut.
 * Das kleine Script im HEAD verhindert nur
 * den sichtbaren Theme-Wechsel beim Start.
 */
applyUiTheme(
    readStoredUiTheme(),
    false,
    false
);


function byId(id) {
    return document.getElementById(id);
}


function setMessage(text, type = "") {
    const box = byId("globalMessage");

    if (!text) {
        box.textContent = "";
        box.className = "message hidden";
        return;
    }

    box.textContent = text;
    box.className =
        "message" +
        (type ? " " + type : "");
}


function nativeVersionName() {
    try {
        if (
            window.AndroidApp &&
            typeof window.AndroidApp.getVersionName ===
                "function"
        ) {
            const value =
                window.AndroidApp.getVersionName();

            if (value)
                return String(value);
        }
    }
    catch {
    }

    return "web";
}


function nativeVersionCode() {
    try {
        if (
            window.AndroidApp &&
            typeof window.AndroidApp.getVersionCode ===
                "function"
        ) {
            return Number(
                window.AndroidApp.getVersionCode() || 0);
        }
    }
    catch {
    }

    return 0;
}


async function localFetch(path, options = {}) {
    const url = new URL(path, window.location.origin);
    if (url.origin !== window.location.origin) throw new Error("Nur lokale API-Aufrufe sind erlaubt.");
    const headers = new Headers(options.headers || {});
    headers.delete("Authorization");
    headers.delete("X-App-Id");
    if (!["GET", "HEAD"].includes((options.method || "GET").toUpperCase())) {
        if (!localCsrfToken) throw new Error("Lokale Sitzung fehlt.");
        headers.set("X-CSRF-Token", localCsrfToken);
    }
    const response = await window.fetch(url, { ...options, headers, credentials: "same-origin" });
    if (response.status === 401) {
        redirectToLogin();
        throw new Error("Die Anmeldung ist nicht mehr gültig.");
    }
    return response;
}

async function api(path, options = {}) {
    const diagStartedAt =
        performance.now();

    const diagVisibilityGeneration =
        pageVisibilityGeneration;

    const headers = {
        "X-App-Id": APP_ID,
        "Content-Type": "application/json",
        ...(options.headers || {})
    };

    if (token) {
        headers.Authorization =
            "Bearer " + token;
    }

    const response =
        await localFetch(
            path,
            {
                ...options,
                headers
            });

    const data =
        await response
            .json()
            .catch(() => ({}));



    if (!response.ok) {

        window.BtcTraderDiag?.web?.(
            path,
            response.status,
            performance.now() - diagStartedAt,
            false,
            diagVisibilityGeneration !== pageVisibilityGeneration);

        throw new Error(
            data.message ||
            data.Message ||
            data.error ||
            data.Error ||
            `HTTP ${response.status}`);
    }

    window.BtcTraderDiag?.web?.(
        path,
        response.status,
        performance.now() - diagStartedAt,
        true,
        diagVisibilityGeneration !== pageVisibilityGeneration);

    return data;
}



// ==========================================================
// M4.3D · SETTINGS DRAWER
// ==========================================================


// ==========================================================
// M4.7A · SETTINGS HUB
// ==========================================================

let settingsHubInitialized =
    false;


// ==========================================================
// M4.7A1 · CLEAN LEFT SETTINGS
// ==========================================================

function cleanLegacySettingsMenu() {

    const drawer =
        byId(
            "settingsDrawer");

    const hub =
        byId(
            "settingsHub");


    if (!drawer)
        return;


    /*
     * Der alte Drawer besitzt noch eigene
     * Konto- und Info-Menüpunkte.
     *
     * Die neuen Varianten stehen bereits oben
     * im Settings Hub.
     */
    const candidates =
        drawer.querySelectorAll(
            "button, "
            +
            "[role='button'], "
            +
            ".settings-menu-item, "
            +
            ".settings-menu-card");


    for (const candidate of candidates) {

        if (
            hub
            &&
            hub.contains(
                candidate)
        ) {
            continue;
        }


        const strong =
            candidate.querySelector(
                "strong");


        const title =
            String(
                strong
                    ? strong.textContent
                    : ""
            )
            .trim()
            .toLowerCase();


        if (
            title === "konto"
            ||
            title === "info"
        ) {

            /*
             * Falls ein kleiner Wrapper existiert,
             * verstecken wir die komplette Kachel.
             */
            const card =
                candidate.closest(
                    ".settings-menu-card, "
                    +
                    ".settings-menu-item")
                ||
                candidate;


            card.classList.add(
                "settings-legacy-duplicate-hidden");
        }
    }


    /*
     * Der alte Abschnitt "APP" enthält danach
     * nur noch die Product-Beta-Hinweiskarte.
     * Deshalb nennen wir ihn optisch "INFO".
     */
    const labels =
        drawer.querySelectorAll(
            "h2, h3, "
            +
            ".settings-section-label, "
            +
            ".settings-menu-label, "
            +
            ".eyebrow");


    for (const label of labels) {

        if (
            hub
            &&
            hub.contains(
                label)
        ) {
            continue;
        }


        if (
            String(
                label.textContent
            )
            .trim()
            .toUpperCase()
            === "APP"
        ) {

            label.textContent =
                "INFO";
        }
    }
}


// ==========================================================
// PRE-LIVE ERROR VISIBILITY V1
//
// - nutzt ausschließlich den vorhandenen /api/errors Endpoint
// - kleines Warnsymbol nur bei aktuellen technischen Fehlern
// - Detailanzeige im bestehenden Settings Hub
// - keine Trading-/Config-/Wallet-Aktion
// ==========================================================

let errorDiagnosticsTimer =
    null;


function readErrorProperty(
    object,
    camelName,
    pascalName,
    fallback = null)
{
    if (!object)
        return fallback;

    if (
        object[camelName] !==
        undefined
    ) {
        return object[camelName];
    }

    if (
        object[pascalName] !==
        undefined
    ) {
        return object[pascalName];
    }

    return fallback;
}


function formatErrorTime(
    value)
{
    if (!value)
        return "Zeit unbekannt";

    const parsed =
        new Date(value);

    if (
        Number.isNaN(
            parsed.getTime())
    ) {
        return String(value);
    }

    try {
        return parsed.toLocaleString(
            "de-DE",
            {
                dateStyle:
                    "short",

                timeStyle:
                    "medium"
            });
    }
    catch {
        return parsed.toLocaleString();
    }
}


function ensureErrorDiagnosticsUi()
{
    const settingsButton =
        byId(
            "settingsMenuButton");

    const topbarActions =
        settingsButton
            ?.parentElement;


    let warningButton =
        byId(
            "errorWarningButton");


    if (
        !warningButton &&
        topbarActions &&
        settingsButton
    ) {
        warningButton =
            document.createElement(
                "button");

        warningButton.id =
            "errorWarningButton";

        warningButton.type =
            "button";

        warningButton.className =
            "error-warning-button hidden";

        warningButton.setAttribute(
            "aria-label",
            "Technische Fehler anzeigen");

        warningButton.title =
            "Technische Fehler";

        warningButton.innerHTML = `
            <span aria-hidden="true">
                ⚠
            </span>

            <span id="errorWarningCount"
                  class="error-warning-count">
                0
            </span>
        `;

        topbarActions.insertBefore(
            warningButton,
            settingsButton);

        warningButton.addEventListener(
            "click",
            () => {

                const menuButton =
                    byId(
                        "settingsMenuButton");

                if (
                    menuButton &&
                    !menuButton.classList.contains(
                        "hidden")
                ) {
                    menuButton.click();
                }

                window.setTimeout(
                    () => {
                        const block =
                            byId(
                                "errorDiagnosticsBlock");

                        if (block)
                            block.open = true;
                    },
                    40);
            });
    }


    const hub =
        byId(
            "settingsHub");


    let block =
        byId(
            "errorDiagnosticsBlock");


    if (
        !block &&
        hub
    ) {
        block =
            document.createElement(
                "details");

        block.id =
            "errorDiagnosticsBlock";

        block.className =
            "error-diagnostics-block";

        block.innerHTML = `
            <summary class="error-diagnostics-summary">

                <span class="error-diagnostics-icon"
                      aria-hidden="true">
                    ⚠
                </span>

                <span class="error-diagnostics-copy">
                    <strong>
                        Fehler / Diagnose
                    </strong>

                    <small id="errorDiagnosticsSummary">
                        Technischer Status
                    </small>
                </span>

                <span id="errorDiagnosticsBadge"
                      class="error-diagnostics-badge">
                    0
                </span>

            </summary>

            <div class="error-diagnostics-body">

                <div id="errorDiagnosticsState"
                     class="error-diagnostics-state ok">
                    Keine aktuellen technischen Fehler.
                </div>

                <div id="errorDiagnosticsList"
                     class="error-diagnostics-list hidden">
                </div>

                <button id="errorDiagnosticsClearButton"
                        class="error-diagnostics-clear hidden"
                        type="button">
                    Aktuelle Fehler löschen
                </button>

                <button id="liveDiagnosticConsoleOpenButton"
                        class="live-diagnostic-console-open"
                        type="button">
                    Live-Konsole öffnen
                </button>

                <div id="errorDiagnosticsActionStatus"
                     class="error-diagnostics-action-status hidden">
                </div>

                <div class="error-diagnostics-note">
                    Angezeigt werden aktuelle technische
                    Laufzeitfehler. Das permanente Fehlerprotokoll
                    bleibt davon unberührt.
                </div>

            </div>
        `;


        /*
         * Fehler / Diagnose gehört zum App-Bereich.
         * Deshalb steht der Block bewusst ganz unten
         * im Bereich APP & KONTO.
         */
        hub.appendChild(
            block);
    }


    return {
        warningButton:
            byId(
                "errorWarningButton"),

        warningCount:
            byId(
                "errorWarningCount"),

        block:
            byId(
                "errorDiagnosticsBlock"),

        summary:
            byId(
                "errorDiagnosticsSummary"),

        badge:
            byId(
                "errorDiagnosticsBadge"),

        state:
            byId(
                "errorDiagnosticsState"),

        list:
            byId(
                "errorDiagnosticsList"),

        clearButton:
            byId(
                "errorDiagnosticsClearButton"),

        actionStatus:
            byId(
                "errorDiagnosticsActionStatus")
    };
}


function renderErrorDiagnostics(
    payload)
{
    const ui =
        ensureErrorDiagnosticsUi();


    if (
        !ui.warningButton ||
        !ui.badge ||
        !ui.state ||
        !ui.list
    ) {
        return;
    }


    const rawErrors =
        readErrorProperty(
            payload,
            "errors",
            "Errors",
            []);


    const errors =
        Array.isArray(rawErrors)
            ? [...rawErrors]
            : [];


    errors.sort(
        (a, b) => {

            const aTime =
                Date.parse(
                    readErrorProperty(
                        a,
                        "time",
                        "Time",
                        ""));

            const bTime =
                Date.parse(
                    readErrorProperty(
                        b,
                        "time",
                        "Time",
                        ""));


            return (
                Number.isFinite(bTime)
                    ? bTime
                    : 0
            )
            -
            (
                Number.isFinite(aTime)
                    ? aTime
                    : 0
            );
        });


    const countValue =
        Number(
            readErrorProperty(
                payload,
                "count",
                "Count",
                errors.length));


    const total =
        Number.isFinite(countValue)
            ? Math.max(
                0,
                countValue)
            : errors.length;


    if (ui.warningCount) {

        ui.warningCount.textContent =
            total > 99
                ? "99+"
                : String(total);
    }


    ui.badge.textContent =
        total > 99
            ? "99+"
            : String(total);


    ui.badge.classList.toggle(
        "has-errors",
        total > 0);


    ui.warningButton.classList.toggle(
        "hidden",
        total <= 0);


    if (ui.clearButton) {

        ui.clearButton.classList.toggle(
            "hidden",
            total <= 0);

        if (total <= 0) {

            ui.clearButton.textContent =
                "Aktuelle Fehler löschen";

            ui.clearButton.classList.remove(
                "confirm");

            errorDiagnosticsClearConfirmUntil =
                0;
        }
    }


    if (ui.summary) {

        ui.summary.textContent =
            total > 0
                ? (
                    total === 1
                        ? "1 aktueller technischer Fehler"
                        : `${total} aktuelle technische Fehler`
                )
                : "Keine aktuellen technischen Fehler";
    }


    ui.list.replaceChildren();


    if (
        total <= 0 ||
        errors.length === 0
    ) {
        ui.state.textContent =
            "Keine aktuellen technischen Fehler.";

        ui.state.className =
            "error-diagnostics-state ok";

        ui.state.classList.remove(
            "hidden");

        ui.list.classList.add(
            "hidden");

        return;
    }


    ui.state.classList.add(
        "hidden");

    ui.list.classList.remove(
        "hidden");


    for (
        const error of
        errors
    ) {
        const entry =
            document.createElement(
                "div");

        entry.className =
            "error-diagnostics-entry";


        const head =
            document.createElement(
                "div");

        head.className =
            "error-diagnostics-entry-head";


        const source =
            document.createElement(
                "div");

        source.className =
            "error-diagnostics-entry-source";

        source.textContent =
            String(
                readErrorProperty(
                    error,
                    "source",
                    "Source",
                    "PROGRAM"));


        const repeat =
            document.createElement(
                "div");

        repeat.className =
            "error-diagnostics-entry-count";


        const repeatValue =
            Number(
                readErrorProperty(
                    error,
                    "count",
                    "Count",
                    1));


        repeat.textContent =
            (
                Number.isFinite(
                    repeatValue)
                &&
                repeatValue > 1
            )
                ? `${repeatValue}×`
                : "1×";


        head.append(
            source,
            repeat);


        const message =
            document.createElement(
                "div");

        message.className =
            "error-diagnostics-entry-message";

        message.textContent =
            String(
                readErrorProperty(
                    error,
                    "message",
                    "Message",
                    "Keine Fehlermeldung vorhanden."));


        const time =
            document.createElement(
                "div");

        time.className =
            "error-diagnostics-entry-time";

        time.textContent =
            formatErrorTime(
                readErrorProperty(
                    error,
                    "time",
                    "Time",
                    null));


        entry.append(
            head,
            message,
            time);

        ui.list.append(
            entry);
    }
}




let errorDiagnosticsClearConfirmUntil =
    0;

let errorDiagnosticsClearConfirmTimer =
    null;


function setErrorDiagnosticsActionStatus(
    text,
    isError = false)
{
    const status =
        byId(
            "errorDiagnosticsActionStatus");


    if (!status)
        return;


    status.textContent =
        text || "";


    status.className =
        text
            ? (
                "error-diagnostics-action-status"
                +
                (
                    isError
                        ? " error"
                        : ""
                )
            )
            : "error-diagnostics-action-status hidden";
}


function resetErrorDiagnosticsClearConfirmation()
{
    errorDiagnosticsClearConfirmUntil =
        0;


    if (errorDiagnosticsClearConfirmTimer) {

        window.clearTimeout(
            errorDiagnosticsClearConfirmTimer);

        errorDiagnosticsClearConfirmTimer =
            null;
    }


    const button =
        byId(
            "errorDiagnosticsClearButton");


    if (button) {

        button.textContent =
            "Aktuelle Fehler löschen";

        button.classList.remove(
            "confirm");
    }
}


async function clearCurrentErrors()
{
    const button =
        byId(
            "errorDiagnosticsClearButton");


    if (
        !button ||
        button.disabled
    ) {
        return;
    }


    const now =
        Date.now();


    /*
     * Android-WebView-freundliche Bestätigung:
     *
     * Erster Klick macht die Aktion für 5 Sekunden scharf.
     * Erst der zweite Klick führt sie wirklich aus.
     */
    if (
        now >
        errorDiagnosticsClearConfirmUntil
    ) {
        errorDiagnosticsClearConfirmUntil =
            now + 5000;


        button.textContent =
            "Nochmal tippen zum Löschen";

        button.classList.add(
            "confirm");


        setErrorDiagnosticsActionStatus(
            "Die permanente Logdatei bleibt erhalten.");


        if (errorDiagnosticsClearConfirmTimer) {

            window.clearTimeout(
                errorDiagnosticsClearConfirmTimer);
        }


        errorDiagnosticsClearConfirmTimer =
            window.setTimeout(
                () => {

                    resetErrorDiagnosticsClearConfirmation();

                    setErrorDiagnosticsActionStatus(
                        "");
                },
                5000);


        return;
    }


    button.disabled =
        true;


    try {

        const response =
            await localFetch(
                "/trader-api/errors/clear",
                {
                    method:
                        "POST",

                    cache:
                        "no-store",

                    credentials:
                        "same-origin",

                    headers:
                    {
                        "X-App-Id":
                            APP_ID,

                        "Content-Type":
                            "application/json",

                        "Authorization":
                            "Bearer " + token,

                        "X-BTC-Error-Action":
                            "CLEAR-CURRENT-ERRORS"
                    },

                    /*
                     * Expliziter Body verhindert bei HttpListener
                     * einen Length-Required-Transportfall.
                     */
                    body:
                        "{}"
                });


        const result =
            await response
                .json()
                .catch(
                    () => ({}));


        if (!response.ok) {

            throw new Error(
                result.Error
                ||
                result.error
                ||
                `HTTP ${response.status}`);
        }


        resetErrorDiagnosticsClearConfirmation();


        setErrorDiagnosticsActionStatus(
            "Aktuelle Fehler wurden gelöscht.");


        await refreshErrorDiagnostics();


        window.setTimeout(
            () => {

                setErrorDiagnosticsActionStatus(
                    "");
            },
            2500);
    }
    catch (error) {

        resetErrorDiagnosticsClearConfirmation();


        setErrorDiagnosticsActionStatus(
            error?.message
            ||
            "Fehlerliste konnte nicht gelöscht werden.",
            true);
    }
    finally {

        button.disabled =
            false;
    }
}


function initErrorDiagnosticsClearButton()
{
    const button =
        byId(
            "errorDiagnosticsClearButton");


    if (!button)
        return;


    if (
        button.dataset.bound ===
        "true"
    ) {
        return;
    }


    button.dataset.bound =
        "true";


    button.addEventListener(
        "click",
        clearCurrentErrors);
}



async function refreshErrorDiagnostics()
{
    /*
     * Ohne angemeldeten Benutzer wird kein
     * Legacy-/Diagnose-Endpunkt abgefragt.
     */
    if (!token) {

        renderErrorDiagnostics(
            {
                Count: 0,
                Errors: []
            });

        return;
    }


    try {
        const response =
            await localFetch(
                "/trader-api/errors",
                {
                    method:
                        "GET",

                    cache:
                        "no-store",

                    credentials:
                        "same-origin",

                    headers:
                    {
                        "X-App-Id":
                            APP_ID,

                        "Authorization":
                            "Bearer " + token
                    }
                });


        if (!response.ok)
            return;


        const payload =
            await response.json();


        renderErrorDiagnostics(
            payload);
    }
    catch {
        /*
         * Die Diagnoseanzeige selbst darf niemals
         * einen neuen Benutzerfehler erzeugen oder
         * das Dashboard beeinflussen.
         *
         * Der zuletzt bekannte Zustand bleibt daher
         * bei einem Transportfehler erhalten.
         */
    }
}


function initErrorDiagnostics()
{
    ensureErrorDiagnosticsUi();

    initErrorDiagnosticsClearButton();

    refreshErrorDiagnostics();


    if (errorDiagnosticsTimer)
        return;


    errorDiagnosticsTimer =
        window.setInterval(
            refreshErrorDiagnostics,
            10000);
}



function initSettingsHub() {

    cleanLegacySettingsMenu();


    initUiThemeMenuControl();

    initErrorDiagnostics();


    if (settingsHubInitialized)
        return;


    settingsHubInitialized =
        true;


    const hub =
        byId(
            "settingsHub");


    const drawer =
        byId(
            "settingsDrawer");


    /*
     * Falls der bestehende Drawer einen eigenen
     * Menü-View besitzt, wird der neue Hub dort
     * ganz oben einsortiert.
     */
    const menu =
        byId("settingsMenuView")
        ||
        byId("drawerMenuView")
        ||
        byId("settingsHomeView");


    if (
        hub
        &&
        menu
        &&
        hub.parentElement !== menu
    ) {

        menu.insertBefore(
            hub,
            menu.firstChild);
    }
    else if (
        hub
        &&
        drawer
        &&
        hub.parentElement === drawer
        &&
        drawer.firstElementChild
    ) {

        /*
         * Fallback:
         * direkt hinter den bestehenden Drawer-Header.
         */
        const first =
            drawer.firstElementChild;


        drawer.insertBefore(
            hub,
            first.nextSibling);
    }


    cleanLegacySettingsMenu();
}


// ==========================================================
// M4.7G · SETTINGS SWIPE TO CLOSE
// ==========================================================
//
// Der Drawer öffnet von links.
//
// Eine deutliche horizontale Wischbewegung nach links
// schließt ihn wieder.
//
// Vertikales Scrollen innerhalb der Einstellungen
// bleibt vollständig erhalten.
// ==========================================================

let settingsSwipeStartX =
    null;

let settingsSwipeStartY =
    null;

let settingsSwipeCurrentX =
    null;

let settingsSwipeCurrentY =
    null;


function resetSettingsSwipe() {

    settingsSwipeStartX =
        null;

    settingsSwipeStartY =
        null;

    settingsSwipeCurrentX =
        null;

    settingsSwipeCurrentY =
        null;
}


function initSettingsSwipeToClose() {

    const drawer =
        byId(
            "settingsDrawer");


    if (
        !drawer
        ||
        drawer.dataset.swipeCloseReady ===
            "true"
    ) {
        return;
    }


    drawer.dataset.swipeCloseReady =
        "true";


    drawer.addEventListener(
        "touchstart",
        event => {

            if (
                event.touches.length !==
                    1
            ) {

                resetSettingsSwipe();

                return;
            }


            const touch =
                event.touches[0];


            settingsSwipeStartX =
                touch.clientX;

            settingsSwipeStartY =
                touch.clientY;

            settingsSwipeCurrentX =
                touch.clientX;

            settingsSwipeCurrentY =
                touch.clientY;
        },
        {
            passive:
                true
        });


    drawer.addEventListener(
        "touchmove",
        event => {

            if (
                settingsSwipeStartX ===
                    null
                ||
                event.touches.length !==
                    1
            ) {
                return;
            }


            const touch =
                event.touches[0];


            settingsSwipeCurrentX =
                touch.clientX;

            settingsSwipeCurrentY =
                touch.clientY;
        },
        {
            passive:
                true
        });


    drawer.addEventListener(
        "touchend",
        () => {

            if (
                settingsSwipeStartX ===
                    null
                ||
                settingsSwipeCurrentX ===
                    null
            ) {

                resetSettingsSwipe();

                return;
            }


            const deltaX =
                settingsSwipeCurrentX
                -
                settingsSwipeStartX;


            const deltaY =
                settingsSwipeCurrentY
                -
                settingsSwipeStartY;


            /*
             * Mindestens 65 px nach links.
             *
             * Zusätzlich muss die Bewegung klar
             * horizontaler als vertikal sein.
             */
            const closeGesture =
                deltaX <= -65
                &&
                Math.abs(deltaX)
                    >
                Math.abs(deltaY) * 1.25;


            resetSettingsSwipe();


            if (closeGesture) {

                closeSettingsDrawer();
            }
        },
        {
            passive:
                true
        });


    drawer.addEventListener(
        "touchcancel",
        resetSettingsSwipe,
        {
            passive:
                true
        });


    console.log(
        "BTC Trader Settings Swipe-to-Close aktiv");
}


function openSettingsDrawer() {
    showDrawerMenu();

    initSettingsHub();

    initSettingsSwipeToClose();

    const drawer =
        byId("settingsDrawer");

    const overlay =
        byId("drawerOverlay");

    if (!drawer || !overlay)
        return;

    overlay.classList.remove(
        "hidden");

    drawer.classList.add(
        "open");

    drawer.setAttribute(
        "aria-hidden",
        "false");

    document.body.classList.add(
        "drawer-open");
}


function closeSettingsDrawer() {

    closeTestWalletResetPanel();
    const drawer =
        byId("settingsDrawer");

    const overlay =
        byId("drawerOverlay");

    if (!drawer || !overlay)
        return;

    drawer.classList.remove(
        "open");

    drawer.setAttribute(
        "aria-hidden",
        "true");

    document.body.classList.remove(
        "drawer-open");

    window.setTimeout(
        () => {
            if (!drawer.classList.contains("open")) {
                overlay.classList.add(
                    "hidden");
            }
        },
        220);
}


function openAccountFromDrawer() {
    closeSettingsDrawer();

    window.setTimeout(
        () => {
            const card =
                document.querySelector(
                    ".account-card");

            if (card) {
                card.scrollIntoView({
                    behavior: "smooth",
                    block: "start"
                });
            }
        },
        230);
}


function showDrawerMenu() {
    document
        .querySelectorAll(
            "#settingsDrawer > .drawer-section, " +
            "#settingsDrawer > .drawer-note")
        .forEach(
            element =>
                element.classList.remove(
                    "hidden"));

    byId("drawerConfigView")
        .classList.add("hidden");

    const binanceView =
        byId("drawerBinanceView");

    if (binanceView)
        binanceView.classList.add("hidden");
}


function showConfigView() {
    document
        .querySelectorAll(
            "#settingsDrawer > .drawer-section, " +
            "#settingsDrawer > .drawer-note")
        .forEach(
            element =>
                element.classList.add(
                    "hidden"));

    const binanceView =
        byId("drawerBinanceView");

    if (binanceView)
        binanceView.classList.add("hidden");

    byId("drawerConfigView")
        .classList.remove("hidden");
}


function showBinanceView() {
    document
        .querySelectorAll(
            "#settingsDrawer > .drawer-section, " +
            "#settingsDrawer > .drawer-note")
        .forEach(
            element =>
                element.classList.add("hidden"));

    byId("drawerConfigView")
        .classList.add("hidden");

    const view =
        byId("drawerBinanceView");

    if (view)
        view.classList.remove("hidden");
}


function toggleBinanceSecretVisibility() {
    const input =
        byId("binanceSecretKeyInput");

    const button =
        byId("binanceSecretToggleButton");

    if (!input || !button)
        return;

    const show =
        input.type === "password";

    input.type =
        show ? "text" : "password";

    button.textContent =
        show ? "Verbergen" : "Anzeigen";

    button.setAttribute(
        "aria-label",
        show ? "Secret verbergen" : "Secret anzeigen");
}


// M14B · BINANCE CREDENTIAL STORAGE V1
// Nur verschlüsseltes Speichern/Ändern/Löschen.
// Keine Binance-Verbindungsabfrage und keine Order.

let binanceCredentialConfigured = false;
let binanceCredentialBusy = false;

// M14B DELETE BUTTON FIX V1
// Android WebView nutzt hier keine nativen JavaScript-Confirm-Dialoge.
// Darum erfolgt die Sicherheitsbestätigung direkt im bestehenden UI:
// erster Klick = scharf schalten, zweiter Klick = wirklich löschen.
let binanceDeleteConfirmUntil = 0;
let binanceDeleteConfirmTimer = null;


function updateBinanceCredentialControls() {
    const apiKey =
        byId("binanceApiKeyInput");

    const secretKey =
        byId("binanceSecretKeyInput");

    const testButton =
        byId("binanceTestButton");

    const saveButton =
        byId("binanceSaveButton");

    const deleteButton =
        byId("binanceDeleteButton");

    if (
        !apiKey ||
        !secretKey ||
        !testButton ||
        !saveButton ||
        !deleteButton
    ) {
        return;
    }

    testButton.disabled =
        binanceCredentialBusy ||
        !binanceCredentialConfigured;

    saveButton.disabled =
        binanceCredentialBusy ||
        !apiKey.value.trim() ||
        !secretKey.value.trim();

    saveButton.textContent =
        binanceCredentialConfigured
            ? "Zugang ändern"
            : "Zugang speichern";

    deleteButton.disabled =
        binanceCredentialBusy ||
        !binanceCredentialConfigured;
}


function setBinanceCredentialStatus(
    configured,
    text,
    isError = false) {

    binanceCredentialConfigured =
        Boolean(configured);

    const statusText =
        byId("binanceConnectionStatusText");

    const dot =
        document.querySelector(
            ".binance-connection-status .binance-status-dot");

    if (statusText)
        statusText.textContent = text;

    if (dot) {
        dot.classList.toggle(
            "is-configured",
            binanceCredentialConfigured && !isError);

        dot.classList.toggle(
            "is-error",
            Boolean(isError));
    }

    updateBinanceCredentialControls();
}


async function loadBinanceCredentialStatus() {
    const statusText =
        byId("binanceConnectionStatusText");

    if (statusText)
        statusText.textContent = "Status wird geladen …";

    try {
        const data =
            await api(
                "/trader-api/binance/credentials");

        const configured =
            Boolean(
                data.configured ??
                data.Configured);

        setBinanceCredentialStatus(
            configured,
            configured
                ? "Zugang gespeichert · Verbindung noch nicht geprüft"
                : "Noch nicht eingerichtet");

        setBinanceAccountDisplay(
            configured
                ? "not-tested"
                : "disconnected");
    }
    catch (error) {
        setBinanceCredentialStatus(
            false,
            "Status konnte nicht geladen werden",
            true);

        setMessage(
            error.message ||
            "Binance-Zugangsstatus konnte nicht geladen werden.",
            "error");
    }
}


async function saveBinanceCredentials() {
    if (binanceCredentialBusy)
        return;

    const apiKeyInput =
        byId("binanceApiKeyInput");

    const secretInput =
        byId("binanceSecretKeyInput");

    if (!apiKeyInput || !secretInput)
        return;

    const apiKey =
        apiKeyInput.value.trim();

    const secretKey =
        secretInput.value.trim();

    if (!apiKey || !secretKey) {
        setMessage(
            "Bitte API-Key und Secret-Key eingeben.",
            "error");
        return;
    }

    binanceCredentialBusy = true;
    updateBinanceCredentialControls();

    try {
        await api(
            "/trader-api/binance/credentials",
            {
                method: "POST",
                body: JSON.stringify({
                    apiKey,
                    secretKey
                })
            });

        apiKeyInput.value = "";
        secretInput.value = "";
        secretInput.type = "password";

        const toggle =
            byId("binanceSecretToggleButton");

        if (toggle) {
            toggle.textContent = "Anzeigen";
            toggle.setAttribute(
                "aria-label",
                "Secret anzeigen");
        }

        setBinanceCredentialStatus(
            true,
            "Zugang gespeichert · Verbindung noch nicht geprüft");

        setBinanceAccountDisplay(
            "not-tested");

        setMessage(
            "Binance-Zugang wurde verschlüsselt auf diesem VPS gespeichert.",
            "success");
    }
    catch (error) {
        setBinanceCredentialStatus(
            binanceCredentialConfigured,
            binanceCredentialConfigured
                ? "Gespeicherter Zugang unverändert"
                : "Speichern fehlgeschlagen",
            true);

        setMessage(
            error.message ||
            "Binance-Zugang konnte nicht gespeichert werden.",
            "error");
    }
    finally {
        binanceCredentialBusy = false;
        updateBinanceCredentialControls();
    }
}


async function deleteBinanceCredentials() {
    if (
        binanceCredentialBusy ||
        !binanceCredentialConfigured
    ) {
        return;
    }

    const deleteButton =
        byId("binanceDeleteButton");

    if (!deleteButton)
        return;

    const now =
        Date.now();

    if (
        !binanceDeleteConfirmUntil ||
        now > binanceDeleteConfirmUntil
    ) {
        binanceDeleteConfirmUntil =
            now + 7000;

        deleteButton.textContent =
            "Wirklich löschen?";

        setMessage(
            "Zum Löschen des Binance-Zugangs bitte innerhalb von 7 Sekunden erneut tippen.");

        if (binanceDeleteConfirmTimer)
            clearTimeout(binanceDeleteConfirmTimer);

        binanceDeleteConfirmTimer =
            setTimeout(
                () => {
                    binanceDeleteConfirmUntil = 0;

                    const button =
                        byId("binanceDeleteButton");

                    if (button)
                        button.textContent =
                            "Binance-Zugang löschen";
                },
                7000);

        return;
    }

    binanceDeleteConfirmUntil = 0;

    if (binanceDeleteConfirmTimer) {
        clearTimeout(
            binanceDeleteConfirmTimer);

        binanceDeleteConfirmTimer =
            null;
    }

    deleteButton.textContent =
        "Binance-Zugang löschen";

    binanceCredentialBusy = true;
    updateBinanceCredentialControls();

    try {
        await api(
            "/trader-api/binance/credentials",
            {
                method: "DELETE"
            });

        const apiKeyInput =
            byId("binanceApiKeyInput");

        const secretInput =
            byId("binanceSecretKeyInput");

        if (apiKeyInput)
            apiKeyInput.value = "";

        if (secretInput) {
            secretInput.value = "";
            secretInput.type = "password";
        }

        setBinanceCredentialStatus(
            false,
            "Noch nicht eingerichtet");

        setBinanceAccountDisplay(
            "disconnected");

        const deleteButton =
            byId("binanceDeleteButton");

        if (deleteButton)
            deleteButton.textContent =
                "Binance-Zugang löschen";

        setMessage(
            "Binance-Zugang wurde von diesem VPS gelöscht.",
            "success");
    }
    catch (error) {
        setBinanceCredentialStatus(
            true,
            "Löschen fehlgeschlagen",
            true);

        setMessage(
            error.message ||
            "Binance-Zugang konnte nicht gelöscht werden.",
            "error");
    }
    finally {
        binanceCredentialBusy = false;
        updateBinanceCredentialControls();
    }
}



// ==========================================================
// MANUELLER ERST-BUY · BTC TRADER PRO
// ==========================================================
//
// Kein direkter Binance-Aufruf.
//
// Der Browser fordert ausschließlich den ProgramManager auf,
// einen manuellen Erst-BUY im normalen Trading-Loop
// einzuspeisen.
//
// Die eigentliche Ausführung bleibt vollständig in:
//
// ExecuteTrade
// -> TradeSecurity
// -> ExecuteBuy
// -> Hardened LIVE
// -> finaler RealOrder-Hardlock
//
// ==========================================================

let manualFirstBuyConfirmMode = null;

let manualFirstBuyBusy =
    false;

let manualFirstBuyConfirmUntil =
    0;

let manualFirstBuyConfirmTimer =
    null;


// ==========================================================
// MANUELLER ERST-BUY · PRODUCT UI V1
// ==========================================================
// Sichtbare UI-Freigabe:
//
// - Betriebsmodus LIVE
// - keine offene Position
// - Trading ACTIVE
// - LIVE Trading Master AN
// - LIVE BUY/ReBUY AN
// - LIVE-Budget konsistent
//
// Lizenz, Recovery, Exchange-Safety und weitere harte Gates
// bleiben zusätzlich authoritative im Backend.
// ==========================================================

function currentManualFirstBuyConfigBool(
    name) {

    const value =
        currentManualFirstBuyPersistedConfigValue(
            name);


    if (value === true)
        return true;


    return (
        String(value ?? "")
            .trim()
            .toLowerCase()
        ===
        "true"
    );
}


function currentManualFirstBuyPersistedConfigValue(
    name) {

    const field =
        productConfigFields.get(
            name);

    if (!field)
        return null;

    return configProperty(
        field,
        "Value",
        "value");
}


function manualFirstBuyAvailabilityState() {

    /*
     * First-BUY-Freigabe bewertet die vom Backend geladene,
     * gespeicherte Product-Config und nicht einen eventuell
     * noch veralteten/unpersistierten Config-Editorwert.
     *
     * Die harte LIVE-Sicherheitskette bleibt im Backend.
     */
    const tradingMode =
        String(
            currentManualFirstBuyPersistedConfigValue(
                "TradingMode")
            ?? "")
            .trim()
            .toUpperCase();


    if (tradingMode !== "LIVE") {

        return {
            allowed: false,
            reason:
                "Der manuelle Erst-BUY ist nur in LIVE verfügbar."
        };
    }


    if (configPositionOpen) {

        return {
            allowed: false,
            reason:
                "Es ist bereits eine Position offen. Ein manueller Erst-BUY ist nur bei vollständig FLATem Positionszustand möglich."
        };
    }


    if (tradingControlMode !== "ACTIVE") {

        return {
            allowed: false,
            reason:
                "Trading muss ACTIVE sein, bevor ein manueller Erst-BUY angefordert werden kann."
        };
    }


    if (
        tradingMode === "LIVE" && !currentManualFirstBuyConfigBool(
            "LiveTradingEnabled")
    ) {

        return {
            allowed: false,
            reason:
                "LIVE Trading · Master ist AUS."
        };
    }


    if (
        tradingMode === "LIVE" && !currentManualFirstBuyConfigBool(
            "AllowLiveBuyReBuy")
    ) {

        return {
            allowed: false,
            reason:
                "LIVE BUY / ReBUY ist nicht freigegeben."
        };
    }


    const liveBudgetError =
        validateLiveBudgetConfiguration();


    if (tradingMode === "LIVE" && liveBudgetError) {

        return {
            allowed: false,
            reason:
                liveBudgetError.message
        };
    }


    return {
        allowed: true,
        reason:
            "Manueller Erst-BUY kann über den bestehenden Handelspfad angefordert werden."
    };
}


function clearManualFirstBuyConfirmation() {
    manualFirstBuyConfirmMode = null;

    manualFirstBuyConfirmUntil =
        0;


    if (manualFirstBuyConfirmTimer) {

        clearTimeout(
            manualFirstBuyConfirmTimer);

        manualFirstBuyConfirmTimer =
            null;
    }


    const button =
        byId("binanceManualBuyButton");


    if (button) {

        button.classList.remove(
            "is-confirming");
    }
}


function armManualFirstBuyConfirmation() {

    clearManualFirstBuyConfirmation();


    const button =
        byId("binanceManualBuyButton");


    if (!button)
        return;


    manualFirstBuyConfirmMode = String(currentManualFirstBuyPersistedConfigValue("TradingMode") ?? "");
    manualFirstBuyConfirmUntil =
        Date.now() + 8000;


    button.textContent =
        "Wirklich Erst-BUY?";


    button.classList.add(
        "is-confirming");


    setMessage(
        "Sicherheitsbestätigung: Der manuelle Erst-BUY kauft bei FLAT zum aktuellen Marktpreis mit dem eingestellten TradeAmount, unabhängig vom Strategiesignal. "
        + "Alle LIVE-, Lizenz-, Positions-, Recovery-, Budget- und Sicherheitsprüfungen bleiben aktiv. "
        + "Zum Bestätigen innerhalb von 8 Sekunden erneut tippen.",
        "warning");


    manualFirstBuyConfirmTimer =
        setTimeout(
            () => {

                clearManualFirstBuyConfirmation();

                updateManualFirstBuyAvailability();
    updateManualSellAvailability();
            },
            8000);
}


async function executeManualFirstBuy() {

    if (manualFirstBuyBusy)
        return;


    const button =
        byId("binanceManualBuyButton");


    if (!button)
        return;


    const availability =
        manualFirstBuyAvailabilityState();


    if (!availability.allowed) {

        clearManualFirstBuyConfirmation();

        updateManualFirstBuyAvailability();
    updateManualSellAvailability();


        setMessage(
            "Erst-BUY nicht verfügbar: "
            + availability.reason,
            "warning");

        return;
    }


    const now =
        Date.now();


    /*
     * Erster Tipp:
     * In-App-Sicherheitsbestätigung scharf schalten.
     *
     * Kein window.confirm(), damit Android WebView und Browser
     * dasselbe Verhalten besitzen.
     */
    if (
        !manualFirstBuyConfirmUntil
        ||
        now > manualFirstBuyConfirmUntil
    ) {

        armManualFirstBuyConfirmation();

        return;
    }


    /*
     * Vor dem zweiten Tipp nochmals alle sichtbaren
     * Voraussetzungen prüfen.
     */
    const finalAvailability =
        manualFirstBuyAvailabilityState();


    if (!finalAvailability.allowed) {

        clearManualFirstBuyConfirmation();

        updateManualFirstBuyAvailability();
    updateManualSellAvailability();


        setMessage(
            "Erst-BUY nicht verfügbar: "
            + finalAvailability.reason,
            "warning");

        return;
    }


    if (manualFirstBuyConfirmMode !== String(currentManualFirstBuyPersistedConfigValue("TradingMode") ?? "")) {
        armManualFirstBuyConfirmation();
        return;
    }
    clearManualFirstBuyConfirmation();


    manualFirstBuyBusy =
        true;


    button.disabled =
        true;


    button.textContent =
        "Erst-BUY wird geprüft …";


    try {

        const data =
            await api(
                "/api/v1/btctrader/manual/first-buy",
                {
                    method: "POST",
                    headers: { "X-Manual-Trading-Mode": String(currentManualFirstBuyPersistedConfigValue("TradingMode") ?? "") },
                    body: "{}"
                });


        const code =
            String(
                data.code ??
                data.Code ??
                ""
            );


        if (
            code ===
            "FIRST_BUY_ALREADY_QUEUED"
        ) {

            setMessage(
                "Ein manueller Erst-BUY wartet bereits auf Verarbeitung.",
                "warning");
        }
        else {

            setMessage(
                "Manueller Erst-BUY wurde angefordert. "
                + "Der Trader prüft das BUY-Signal und die Sicherheitskette des gewählten Modus.",
                "success");

            /*
             * Nach dem zweiten Bestätigen bleibt der Button gesperrt,
             * während der Trading-Loop die Anforderung verarbeitet.
             */
            setTimeout(
                async () => {

                    try {
                        await loadPersonalTrading();
                    }
                    catch (_) {
                    }

                    manualFirstBuyBusy =
                        false;

                    updateManualFirstBuyAvailability();
                    updateManualSellAvailability();

                    setMessage("");
                },
                12000);

            return;
        }
    }
    catch (error) {

        setMessage(
            error.message ||
            "Manueller Erst-BUY konnte nicht angefordert werden.",
            "error");
    }
    finally {

        /*
         * Bei erfolgreichem Queueing übernimmt der oben gestartete
         * Verarbeitungs-Timer die Freigabe.
         */
        if (manualFirstBuyBusy) {

            const message =
                byId("message");

            const isSuccess =
                message &&
                message.classList.contains(
                    "success");

            if (!isSuccess) {

                manualFirstBuyBusy =
                    false;
            }
        }


        updateManualFirstBuyAvailability();
        updateManualSellAvailability();
    }
}


function updateManualFirstBuyAvailability() {

    const button =
        byId("binanceManualBuyButton");


    if (!button)
        return;


    const availability =
        manualFirstBuyAvailabilityState();


    if (!availability.allowed) {

        clearManualFirstBuyConfirmation();
    }


    button.disabled =
        manualFirstBuyBusy ||
        !availability.allowed;


    if (!manualFirstBuyBusy) {

        const confirmationActive =
            manualFirstBuyConfirmUntil > Date.now();


        button.textContent =
            confirmationActive
                ? "Wirklich Erst-BUY?"
                : "Erst-BUY jetzt ausführen";
    }


    button.title =
        availability.reason;

}


function wireManualFirstBuyButton() {

    const button =
        byId("binanceManualBuyButton");


    if (
        !button
        ||
        button.dataset.firstBuyWired === "true"
    ) {
        return;
    }


    button.dataset.firstBuyWired =
        "true";

    button.addEventListener(
        "click",
        executeManualFirstBuy);

    updateManualFirstBuyAvailability();
    updateManualSellAvailability();
}


if (document.readyState === "loading") {

    document.addEventListener(
        "DOMContentLoaded",
        wireManualFirstBuyButton,
        {
            once: true
        });
}
else {

    wireManualFirstBuyButton();
}



// M14C · BINANCE ACCOUNT READ-ONLY V1
// Binance wird ausschließlich nach manuellem Klick kontaktiert.
// Keine Order und keine automatische Kontoabfrage.

function setBinanceAccountDisplay(
    state,
    btcTotal = null,
    usdcTotal = null) {

    const badge =
        document.querySelector(
            ".binance-account-badge");

    const btcValue =
        byId("binanceBtcBalanceValue");

    const usdcValue =
        byId("binanceUsdcBalanceValue");

    if (badge) {
        badge.classList.remove(
            "is-connected",
            "is-error");

        if (state === "connected") {
            badge.textContent = "VERBUNDEN";
            badge.classList.add("is-connected");
        }
        else if (state === "checking") {
            badge.textContent = "PRÜFUNG …";
        }
        else if (state === "error") {
            badge.textContent = "FEHLER";
            badge.classList.add("is-error");
        }
        else if (state === "not-tested") {
            badge.textContent = "NICHT GEPRÜFT";
        }
        else {
            badge.textContent = "NICHT VERBUNDEN";
        }
    }

    if (
        state === "connected" &&
        btcTotal !== null &&
        usdcTotal !== null
    ) {
        if (btcValue) {
            btcValue.textContent =
                Number(btcTotal)
                    .toLocaleString(
                        "de-DE",
                        {
                            maximumFractionDigits: 8
                        }) +
                " BTC";
        }

        if (usdcValue) {
            usdcValue.textContent =
                Number(usdcTotal)
                    .toLocaleString(
                        "de-DE",
                        {
                            maximumFractionDigits: 8
                        }) +
                " USDC";
        }
    }
    else {
        if (btcValue)
            btcValue.textContent = "–";

        if (usdcValue)
            usdcValue.textContent = "–";
    }
}


async function testBinanceConnection() {
    if (
        binanceCredentialBusy ||
        !binanceCredentialConfigured
    ) {
        return;
    }

    binanceCredentialBusy = true;
    updateBinanceCredentialControls();

    setBinanceCredentialStatus(
        true,
        "Verbindung wird geprüft …");

    setBinanceAccountDisplay(
        "checking");

    try {
        const data =
            await api(
                "/trader-api/binance/account");

        const balances =
            data.balances ??
            data.Balances ??
            {};

        const btc =
            balances.btc ??
            balances.Btc ??
            {};

        const usdc =
            balances.usdc ??
            balances.Usdc ??
            {};

        const btcTotal =
            Number(
                btc.total ??
                btc.Total ??
                0);

        const usdcTotal =
            Number(
                usdc.total ??
                usdc.Total ??
                0);

        if (
            !Number.isFinite(btcTotal) ||
            !Number.isFinite(usdcTotal)
        ) {
            throw new Error(
                "Binance-Kontostand enthält ungültige Werte.");
        }

        setBinanceAccountDisplay(
            "connected",
            btcTotal,
            usdcTotal);

        setBinanceCredentialStatus(
            true,
            "Verbunden · Kontostand geladen");

        const binanceSuccessMessage =
            "Binance-Verbindung erfolgreich. BTC- und USDC-Kontostand wurden geladen.";

        setMessage(
            binanceSuccessMessage,
            "success");

        window.setTimeout(
            () => {
                const box =
                    byId("globalMessage");

                if (
                    box &&
                    box.textContent ===
                        binanceSuccessMessage
                ) {
                    setMessage("");
                }
            },
            5000);
    }
    catch (error) {
        setBinanceAccountDisplay(
            "error");

        setBinanceCredentialStatus(
            true,
            "Verbindung fehlgeschlagen",
            true);

        setMessage(
            error.message ||
            "Binance-Verbindung konnte nicht geprüft werden.",
            "error");
    }
    finally {
        binanceCredentialBusy = false;
        updateBinanceCredentialControls();
    }
}


function initializeBinanceCredentialStorageV1() {
    const drawerButton =
        byId("drawerBinanceButton");

    const apiKeyInput =
        byId("binanceApiKeyInput");

    const secretInput =
        byId("binanceSecretKeyInput");

    const testButton =
        byId("binanceTestButton");

    const saveButton =
        byId("binanceSaveButton");

    const deleteButton =
        byId("binanceDeleteButton");

    if (
        !drawerButton ||
        !apiKeyInput ||
        !secretInput ||
        !testButton ||
        !saveButton ||
        !deleteButton
    ) {
        return;
    }

    drawerButton.addEventListener(
        "click",
        () => {
            loadBinanceCredentialStatus();
        });

    apiKeyInput.addEventListener(
        "input",
        updateBinanceCredentialControls);

    secretInput.addEventListener(
        "input",
        updateBinanceCredentialControls);

    testButton.addEventListener(
        "click",
        testBinanceConnection);

    saveButton.addEventListener(
        "click",
        saveBinanceCredentials);

    deleteButton.addEventListener(
        "click",
        deleteBinanceCredentials);

    updateBinanceCredentialControls();
}


initializeBinanceCredentialStorageV1();


function configProperty(
    field,
    pascalName,
    camelName) {

    if (
        field &&
        Object.prototype.hasOwnProperty.call(
            field,
            pascalName)
    ) {
        return field[pascalName];
    }

    if (
        field &&
        Object.prototype.hasOwnProperty.call(
            field,
            camelName)
    ) {
        return field[camelName];
    }

    return undefined;
}


function formatConfigValue(
    value,
    dataType) {

    if (value === null ||
        value === undefined)
        return "–";

    if (Array.isArray(value)) {
        if (value.length === 0)
            return "–";

        return value.join(" · ");
    }

    if (
        dataType === "bool" ||
        typeof value === "boolean"
    ) {
        return value
            ? "AN"
            : "AUS";
    }

    if (typeof value === "number") {
        return new Intl.NumberFormat(
            "de-DE",
            {
                maximumFractionDigits: 8
            }
        ).format(value);
    }

    if (typeof value === "object") {
        try {
            return JSON.stringify(value);
        }
        catch {
            return String(value);
        }
    }

    return String(value);
}


function appendConfigMeta(
    container,
    text,
    extraClass = "") {

    const pill =
        document.createElement("span");

    pill.className =
        "config-meta-pill" +
        (
            extraClass
                ? " " + extraClass
                : ""
        );

    pill.textContent =
        text;

    container.appendChild(
        pill);
}


// ==========================================================
// M4.4D-C1 · EDITABLE PRODUCT CONFIG
// ==========================================================

let productConfigFields =
    new Map();

let productConfigDirty =
    new Set();

let configPositionOpen =
    false;

// M4.4D-C1.1 · CONFIG POSITION LOCK


const PRODUCT_CONFIG_FIELDS = {

    ConfigLastOptimized: {
        group: "Allgemein",
        label: "Letzte Optimierung",
        access: "info",
        status: "active",
    },

    Symbol: {
        group: "Allgemein",
        label: "Handelssymbol",
        access: "info",
        status: "active",
    },

    LoopIntervalSeconds: {
        group: "Allgemein",
        label: "Loop-Intervall",
        access: "info",
        status: "active",
        unit: "Sek."
    },


    Rule: {
        group: "Trading",
        label: "Trading-Regel",
        access: "edit",
        status: "active",
    },

    TradeAmount: {
        group: "Trading",
        label: "Handelsbetrag",
        access: "edit",
        status: "active",
        unit: "USDC"
    },

    MaxBuyCount: {
        group: "Trading",
        label: "Maximale Käufe",
        access: "edit",
        status: "active",
        integer: true
    },

    MinProfitPercent: {
        group: "Trading",
        label: "Mindestgewinn",
        access: "edit",
        status: "active",
        unit: "%"
    },

    SmartExitActivationPercent: {
        group: "Trading",
        label: "SmartExit Aktivierung",
        access: "edit",
        status: "active",
        unit: "%"
    },

    SmartExitPeakGivebackPercent: {
        group: "Trading",
        label: "SmartExit Giveback",
        access: "edit",
        status: "active",
        unit: "%"
    },

    ReBuyDistances: {
        group: "Trading",
        label: "ReBUY-Abstände",
        access: "edit",
        status: "active",
        array: true,
        unit: "USDC"
    },


    Window: {
        group: "ValleyPeak",
        label: "Window",
        access: "edit",
        status: "active",
        integer: true
    },

    BuyBelowAveragePercent: {
        group: "ValleyPeak",
        label: "Kauf unter Durchschnitt",
        access: "edit",
        status: "active",
        unit: "%"
    },

    ValleyPeakSmartExitEnabled: {
        group: "ValleyPeak",
        label: "SmartExit",
        access: "edit",
        status: "active"
    },


    TrendPullbackTrendWindow: {
        group: "TrendPullback",
        label: "Trend Window",
        access: "edit",
        status: "active",
        integer: true
    },

    TrendPullbackMinTrendPercent: {
        group: "TrendPullback",
        label: "Mindesttrend",
        access: "edit",
        status: "active",
        unit: "%"
    },

    TrendPullbackPullbackPercent: {
        group: "TrendPullback",
        label: "Pullback-Abstand",
        access: "edit",
        status: "active",
        unit: "%"
    },

    TrendPullbackRecoveryPercent: {
        group: "TrendPullback",
        label: "Recovery",
        access: "edit",
        status: "active",
        unit: "%"
    },

    TrendPullbackSmartExitEnabled: {
        group: "TrendPullback",
        label: "SmartExit",
        access: "edit",
        status: "active"
    },


    BuyFee: {
        group: "Gebühren",
        label: "BUY-Gebühr",
        access: "edit",
        status: "active",
        unit: "%"
    },

    SellFee: {
        group: "Gebühren",
        label: "SELL-Gebühr",
        access: "edit",
        status: "active",
        unit: "%"
    },


    TradingMode: {
        group: "Trading",
        label: "Betriebsmodus",
        access: "edit",
        status: "active",
    },

    OptimizerMode: {
        group: "Betriebsart",
        label: "Optimizer-Modus",
        access: "later",
        status: "unavailable",
    },

    TestWalletUSDC: {
        group: "Trading",
        label: "TestWallet-Budget",
        access: "edit",
        status: "active",
        unit: "USDC"
    },


    MaxLivePositionUSDC: {
        group: "Trading",
        label: "Max. LIVE-Position",
        access: "edit",
        status: "active",
        unit: "USDC"
    },


    LiveTradingEnabled: {
        group: "Trade-Sicherheit",
        label: "LIVE Trading · Master",
        access: "edit",
        status: "active",
    },

    AllowLiveBuyReBuy: {
        group: "Trade-Sicherheit",
        label: "LIVE BUY / ReBUY",
        access: "edit",
        status: "active",
    },

    AllowLiveSell: {
        group: "Trade-Sicherheit",
        label: "LIVE SELL",
        access: "edit",
        status: "active",
    },

    UseTradeSecurity: {
        group: "Trade-Sicherheit",
        label: "Trade Security",
        access: "info",
        status: "active",
    },

    UseWalletProtection: {
        group: "Trade-Sicherheit",
        label: "Wallet Protection",
        access: "info",
        status: "active",
    },

    UsePositionProtection: {
        group: "Trade-Sicherheit",
        label: "Position Protection",
        access: "info",
        status: "active",
    },

    UsePriceProtection: {
        group: "Trade-Sicherheit",
        label: "Price Protection",
        access: "info",
        status: "active",
    },

    MinUSDC: {
        group: "Trade-Sicherheit",
        label: "Mindestbestand USDC",
        access: "edit",
        status: "active",
        unit: "USDC"
    },

    MinBTC: {
        group: "Trade-Sicherheit",
        label: "Mindestbestand BTC",
        access: "edit",
        status: "active",
        unit: "BTC"
    },

    MaxBuyPriceDeviationPercent: {
        group: "Trade-Sicherheit",
        label: "Max. BUY-Preisabweichung",
        access: "edit",
        status: "active",
        unit: "%"
    },

    MaxSellPriceDeviationPercent: {
        group: "Trade-Sicherheit",
        label: "Max. SELL-Preisabweichung",
        access: "edit",
        status: "active",
        unit: "%"
    },


    BuyEntryGuardEnabled: {
        group: "Trade-Sicherheit",
        label: "Buy Entry Guard",
        access: "edit",
        status: "active"
    },

    ShockGuardUpEnabled: {
        group: "Trade-Sicherheit",
        label: "Shock Guard ↑",
        access: "edit",
        status: "active"
    },

    ShockGuardUpBlockHours: {
        group: "Trade-Sicherheit",
        label: "Sperrzeit",
        access: "edit",
        status: "active",
        unit: "Stunden",
        integer: true
    },

    MaxLiveSellBTC: {
        group: "Trade-Sicherheit",
        label: "Max. LIVE SELL (BTC)",
        access: "edit",
        status: "active",
        unit: "BTC"
    },


    ScoreProfitWeight: {
        group: "Optimizer Score",
        label: "Profit-Gewichtung",
        access: "edit",
        status: "active",
        unit: "%"
    },

    ScoreTradeWeight: {
        group: "Optimizer Score",
        label: "Trade-Gewichtung",
        access: "edit",
        status: "active",
        unit: "%"
    },

    ScoreHoldWeight: {
        group: "Optimizer Score",
        label: "Haltedauer-Gewichtung",
        access: "edit",
        status: "active",
        unit: "%"
    },

    ScoreReBuyWeight: {
        group: "Optimizer Score",
        label: "ReBUY-Gewichtung",
        access: "edit",
        status: "active",
        unit: "%"
    },

    ScoreStabilityWeight: {
        group: "Optimizer Score",
        label: "Stabilitäts-Gewichtung",
        access: "edit",
        status: "active",
        unit: "%"
    },

    ScoreMaxHoldWeight: {
        group: "Optimizer Score",
        label: "Max.-Hold-Gewichtung",
        access: "edit",
        status: "active",
        unit: "%"
    },


    OptimizerWinnerSelection: {
        group: "Optimizer",
        label: "Optimizer-Gewinner",
        access: "edit",
        status: "active",
        winner: true
    },

    AutoOptimizerEnabled: {
        group: "Optimizer",
        label: "Auto-Optimizer",
        access: "edit",
        status: "active",
    },

    AutoOptimizerIntervalDays: {
        group: "Optimizer",
        label: "Optimizer-Intervall",
        access: "edit",
        status: "active",
        unit: "Tage",
        integer: true
    },

    OptimizerLookbackDays: {
        group: "Optimizer",
        label: "Optimizer Lookback",
        access: "edit",
        status: "active",
        unit: "Tage",
        integer: true
    },

    AutoOptimizerLastRun: {
        group: "Optimizer",
        label: "Letzter Auto-Optimizer",
        access: "info",
        status: "active",
    },


    // ======================================================
    // M5.2D · PERSONAL MARKET ANALYSIS
    // ======================================================

    UseMarketAnalysis: {
        group: "Marktanalyse",
        label: "Marktphasenanalyse",
        access: "edit",
        status: "active",
    },

    MarketAnalysisDynamicLookback: {
        group: "Marktanalyse",
        label: "Dynamischer Lookback",
        access: "edit",
        status: "active",
    },

    MarketAnalysisDynamicWindow: {
        group: "Marktanalyse",
        label: "Dynamisches Window",
        access: "edit",
        status: "active",
    }
};


const PRODUCT_CONFIG_GROUP_ORDER = [
    "Trading",
    "Trade-Sicherheit",
    "Optimizer",
    "Optimizer Score",
    "ValleyPeak",
    "TrendPullback",
    "Marktanalyse",
    "Gebühren",
    "Allgemein"
];


const PRODUCT_CONFIG_CATEGORY_ORDER = [
    "Trading",
    "Trade-Sicherheit",
    "__BINANCE__",
    "Optimizer",
    "Optimizer Score",
    "ValleyPeak",
    "TrendPullback",
    "Marktanalyse",
    "Gebühren",
    "Allgemein"
];


const PRODUCT_CONFIG_CATEGORY_META = {

    Trading: {
        icon: "↕",
        label: "Trading",
        description:
            "Betriebsmodus, Wallet, Handelsbetrag, Käufe und ReBUY"
    },

    "Trade-Sicherheit": {
        icon: "✓",
        label: "Trade-Sicherheit",
        description:
            "LIVE-Freigaben, Schutzfunktionen und Limits"
    },

    "__BINANCE__": {
        icon: "◆",
        label: "Binance",
        description:
            "Verbindung, Konto und manuelle Aktionen"
    },

    Optimizer: {
        icon: "◎",
        label: "Optimizer",
        description:
            "Auto-Optimizer, Gewinner und Zeitraum"
    },

    "Optimizer Score": {
        icon: "%",
        label: "Optimizer Score",
        description:
            "Gewichtung der Optimizer-Bewertung"
    },

    ValleyPeak: {
        icon: "V",
        label: "ValleyPeak",
        description:
            "Window und Einstieg unter Durchschnitt"
    },

    TrendPullback: {
        icon: "T",
        label: "TrendPullback",
        description:
            "Trend, Pullback und Recovery"
    },

    Marktanalyse: {
        icon: "◌",
        label: "Marktanalyse",
        description:
            "Marktphasenanalyse und dynamische Anpassung"
    },

    Gebühren: {
        icon: "€",
        label: "Gebühren",
        description:
            "BUY- und SELL-Gebühren"
    },

    Allgemein: {
        icon: "i",
        label: "Allgemein / Info",
        description:
            "Handelssymbol, Loop und Optimierungsinfo"
    }
};


const PRODUCT_CONFIG_FIELD_ORDER = {

    Trading: [
        "TradingMode",
        "TestWalletUSDC",
        "MaxLivePositionUSDC",
        "TradeAmount",
        "MaxBuyCount",
        "MinProfitPercent",
        "SmartExitActivationPercent",
        "SmartExitPeakGivebackPercent",
        "Rule",
        "ReBuyDistances"
    ],

    "Trade-Sicherheit": [
        "LiveTradingEnabled",
        "AllowLiveBuyReBuy",
        "AllowLiveSell",
        "MaxLiveSellBTC",
        "UseTradeSecurity",
        "UseWalletProtection",
        "UsePositionProtection",
        "UsePriceProtection",
        "MinUSDC",
        "MinBTC",
        "MaxBuyPriceDeviationPercent",
        "MaxSellPriceDeviationPercent",
        "BuyEntryGuardEnabled",
        "ShockGuardUpEnabled",
        "ShockGuardUpBlockHours"
    ],

    Optimizer: [
        "AutoOptimizerEnabled",
        "OptimizerWinnerSelection",
        "AutoOptimizerIntervalDays",
        "OptimizerLookbackDays",
        "AutoOptimizerLastRun",
        "OptimizerMode"
    ],

    "Optimizer Score": [
        "ScoreProfitWeight",
        "ScoreTradeWeight",
        "ScoreHoldWeight",
        "ScoreReBuyWeight",
        "ScoreStabilityWeight",
        "ScoreMaxHoldWeight"
    ],

    ValleyPeak: [
        "Window",
        "BuyBelowAveragePercent",
        "ValleyPeakSmartExitEnabled"
    ],

    TrendPullback: [
        "TrendPullbackTrendWindow",
        "TrendPullbackMinTrendPercent",
        "TrendPullbackPullbackPercent",
        "TrendPullbackRecoveryPercent",
        "TrendPullbackSmartExitEnabled"
    ],

    Marktanalyse: [
        "UseMarketAnalysis",
        "MarketAnalysisDynamicLookback",
        "MarketAnalysisDynamicWindow"
    ],

    Gebühren: [
        "BuyFee",
        "SellFee"
    ],

    Allgemein: [
        "Symbol",
        "LoopIntervalSeconds",
        "ConfigLastOptimized"
    ]
};


let activeProductConfigGroup =
    null;

let binanceOpenedFromConfig =
    false;


function productConfigDisplayGroup(
    name,
    definition) {

    if (name === "TestWallet")
        return "Trading";

    if (name === "OptimizerMode")
        return "Optimizer";

    return definition.group;
}


function productConfigFieldOrderIndex(
    groupName,
    fieldName) {

    const order =
        PRODUCT_CONFIG_FIELD_ORDER[
            groupName
        ] || [];

    const index =
        order.indexOf(
            fieldName);

    return index >= 0
        ? index
        : 10000;
}


function productConfigCategoryLabel(
    groupName) {

    const meta =
        PRODUCT_CONFIG_CATEGORY_META[
            groupName
        ];

    return meta?.label ||
        groupName;
}


function setProductConfigOverviewChrome(
    overviewMode) {

    const view =
        byId("drawerConfigView");

    if (!view)
        return;

    const title =
        byId("configViewTitle");

    const header =
        byId("configHeader");

    const notice =
        view.querySelector(
            ".config-readonly-notice");

    const actions =
        view.querySelector(
            ".config-actions");

    const positionLock =
        byId("configPositionLock");


    if (title) {
        title.textContent =
            overviewMode
                ? "Einstellungen"
                : productConfigCategoryLabel(
                    activeProductConfigGroup);
    }


    for (const element of [
        header,
        notice,
        actions
    ]) {

        if (!element)
            continue;

        element.classList.toggle(
            "hidden",
            overviewMode);
    }


    if (
        overviewMode &&
        positionLock
    ) {
        positionLock.classList.add(
            "hidden");
    }
}


function showProductConfigOverview() {

    activeProductConfigGroup =
        null;

    const root =
        byId("configGroups");

    if (!root)
        return;


    const overview =
        root.querySelector(
            ".config-category-list");

    if (overview)
        overview.classList.remove(
            "hidden");


    root
        .querySelectorAll(
            ".config-group")
        .forEach(
            section => {
                section.classList.add(
                    "hidden");
            });


    setProductConfigOverviewChrome(
        true);
}


function showProductConfigGroup(
    groupName) {

    const root =
        byId("configGroups");

    if (!root)
        return;


    activeProductConfigGroup =
        groupName;


    const overview =
        root.querySelector(
            ".config-category-list");

    if (overview)
        overview.classList.add(
            "hidden");


    let found =
        false;


    root
        .querySelectorAll(
            ".config-group")
        .forEach(
            section => {

                const matches =
                    section.dataset.configGroup ===
                    groupName;

                section.classList.toggle(
                    "hidden",
                    !matches);

                if (matches)
                    found = true;
            });


    if (!found) {
        showProductConfigOverview();
        return;
    }


    setProductConfigOverviewChrome(
        false);

    updateConfigDirtyState();
}


function handleProductConfigBack() {

    if (activeProductConfigGroup) {
        showProductConfigOverview();
        return;
    }

    showDrawerMenu();
}


function showBinanceFromConfig() {

    if (
        productConfigDirty &&
        productConfigDirty.size > 0
    ) {
        setMessage(
            "Bitte ungespeicherte Config-Änderungen zuerst speichern.",
            "error");

        return;
    }


    binanceOpenedFromConfig =
        true;

    showBinanceView();

    loadBinanceCredentialStatus();
}


function handleBinanceBack() {

    if (binanceOpenedFromConfig) {

        binanceOpenedFromConfig =
            false;

        openPersonalConfig();

        return;
    }

    showDrawerMenu();
}


function buildProductConfigCategoryOverview(
    root,
    grouped) {

    const list =
        document.createElement(
            "div");

    list.className =
        "config-category-list";


    for (
        const categoryName
        of PRODUCT_CONFIG_CATEGORY_ORDER
    ) {

        if (
            categoryName !== "__BINANCE__" &&
            !grouped.has(
                categoryName)
        ) {
            continue;
        }


        const meta =
            PRODUCT_CONFIG_CATEGORY_META[
                categoryName
            ];

        if (!meta)
            continue;


        const button =
            document.createElement(
                "button");

        button.type =
            "button";

        button.className =
            "drawer-item config-category-button";


        const icon =
            document.createElement(
                "span");

        icon.className =
            "drawer-item-icon";

        icon.textContent =
            meta.icon;


        const copy =
            document.createElement(
                "span");

        copy.className =
            "drawer-item-text";


        const strong =
            document.createElement(
                "strong");

        strong.textContent =
            meta.label;


        const small =
            document.createElement(
                "small");

        small.textContent =
            meta.description;


        const chevron =
            document.createElement(
                "span");

        chevron.className =
            "drawer-chevron";

        chevron.textContent =
            "›";


        copy.appendChild(
            strong);

        copy.appendChild(
            small);

        button.appendChild(
            icon);

        button.appendChild(
            copy);

        button.appendChild(
            chevron);


        button.addEventListener(
            "click",
            () => {

                if (
                    categoryName ===
                    "__BINANCE__"
                ) {
                    showBinanceFromConfig();
                    return;
                }

                showProductConfigGroup(
                    categoryName);
            });


        list.appendChild(
            button);
    }


    root.appendChild(
        list);
}


const OPTIMIZER_WINNERS = [
    [0, "Keine automatische Übernahme"],
    [1, "Gesamtsieger"],
    [2, "Profit-Sieger"],
    [3, "Hold-Sieger"],
    [4, "Schnellster Trader"],
    [5, "Wenigste ReBUYs"],
    [6, "Höchste Effizienz"]
];


function productConfigDescription(
    field,
    definition) {

    const description =
        configProperty(
            field,
            "Description",
            "description");

    if (description)
        return String(description);

    if (definition.access === "info")
        return "Systeminformation.";

    return "";
}



// ==========================================================
// M4.7K2 · PRODUCT CONFIG AVAILABILITY
// ==========================================================

const PRODUCT_CONFIG_INFO_PILLS = {

    /*
     * Kapitalrelevante Trading-Werte.
     */
    TradeAmount: {
        key: "status-capital",
        label: "Kapital"
    },

    MaxBuyCount: {
        key: "status-capital",
        label: "Kapital"
    },

    /*
     * Reines simuliertes Testbudget.
     */
    TestWalletUSDC: {
        key: "status-test-budget",
        label: "TEST-Budget"
    },

    /*
     * Harte Grenzen / Freigaben für reales LIVE-Trading.
     */
    MaxLivePositionUSDC: {
        key: "status-live-protection",
        label: "LIVE-Schutz"
    },

    LiveTradingEnabled: {
        key: "status-live-protection",
        label: "LIVE-Schutz"
    },

    AllowLiveBuyReBuy: {
        key: "status-live-protection",
        label: "LIVE-Schutz"
    },

    AllowLiveSell: {
        key: "status-live-protection",
        label: "LIVE-Schutz"
    },

    MaxLiveSellBTC: {
        key: "status-live-protection",
        label: "SELL-Schutz"
    },

    /*
     * Allgemeine Order-/Wallet-/Positionssicherheit.
     */
    UseTradeSecurity: {
        key: "status-security",
        label: "Sicherheit"
    },

    UseWalletProtection: {
        key: "status-security",
        label: "Sicherheit"
    },

    UsePositionProtection: {
        key: "status-security",
        label: "Sicherheit"
    },

    UsePriceProtection: {
        key: "status-security",
        label: "Sicherheit"
    },

    MinUSDC: {
        key: "status-security",
        label: "Sicherheit"
    },

    MinBTC: {
        key: "status-security",
        label: "Sicherheit"
    },

    MaxBuyPriceDeviationPercent: {
        key: "status-security",
        label: "Sicherheit"
    },

    MaxSellPriceDeviationPercent: {
        key: "status-security",
        label: "Sicherheit"
    },

    /*
     * Buy Entry Guard arbeitet derzeit bewusst nur
     * beobachtend im Shadow-Modus.
     */
    BuyEntryGuardEnabled: {
        key: "status-shadow",
        label: "SHADOW"
    },

    ShockGuardUpEnabled: {
        key: "status-live-protection",
        label: "LIVE-Schutz"
    },

    /*
     * Automatische Funktionen.
     */
    ValleyPeakSmartExitEnabled: {
        key: "status-automation",
        label: "Automatik"
    },

    TrendPullbackSmartExitEnabled: {
        key: "status-automation",
        label: "Automatik"
    },

    AutoOptimizerEnabled: {
        key: "status-automation",
        label: "Automatik"
    },

    /*
     * Marktanalyse / adaptive Analysefunktionen.
     */
    UseMarketAnalysis: {
        key: "status-analysis",
        label: "Analyse"
    },

    MarketAnalysisDynamicLookback: {
        key: "status-analysis",
        label: "Analyse"
    },

    MarketAnalysisDynamicWindow: {
        key: "status-analysis",
        label: "Analyse"
    }
};


function productConfigStatus(
    name,
    definition,
    value
) {
    const status =
        definition.status
        || (
            definition.access === "later"
                ? "locked"
                : "active"
        );

    if (status === "unavailable") {
        return {
            key: "status-unavailable",
            label: "Noch nicht verfügbar"
        };
    }

    if (status === "locked") {
        return {
            key: "status-locked",
            label: "Freigabe erforderlich"
        };
    }

    /*
     * Normale Config-Werte bekommen bewusst
     * keine pauschale grüne "Aktiv"-Pill mehr.
     *
     * Die Pill wird ausschließlich genutzt,
     * wenn sie echte Zusatzinformation liefert.
     */
    const info =
        PRODUCT_CONFIG_INFO_PILLS[name];

    if (!info)
        return null;

    const enabled =
        value === true;

    const disabled =
        value === false;

    if (!enabled && !disabled)
        return info;

    const dynamicLabels = {
        ShockGuardUpEnabled: "LIVE-Schutz",

        UseTradeSecurity: "Sicherheit",
        UseWalletProtection: "Sicherheit",
        UsePositionProtection: "Sicherheit",
        UsePriceProtection: "Sicherheit",

        UseMarketAnalysis: "Analyse",
        MarketAnalysisDynamicLookback: "Analyse",
        MarketAnalysisDynamicWindow: "Analyse"
    };

    if (
        name === "LiveTradingEnabled" ||
        name === "AllowLiveBuyReBuy" ||
        name === "AllowLiveSell"
    ) {
        return {
            key: enabled ? "status-locked" : "status-active",
            label: enabled ? "LIVE freigegeben" : "LIVE gesperrt"
        };
    }

    if (dynamicLabels[name]) {
        return {
            key: info.key,
            label:
                dynamicLabels[name] +
                (enabled ? " aktiv" : " inaktiv")
        };
    }

    if (
        name === "ValleyPeakSmartExitEnabled" ||
        name === "TrendPullbackSmartExitEnabled" ||
        name === "AutoOptimizerEnabled"
    ) {
        return {
            key: info.key,
            label: enabled ? "Aktiv" : "Inaktiv"
        };
    }

    return info;
}


// ==========================================================
// M4.7K3 · CONFIG HELP
// Hochwertige Benutzerhilfe für jede Product-Config.
// Die Hilfe beschreibt die Funktion im fertigen Produkt.
// Verfügbarkeitsstatus wird davon bewusst getrennt dargestellt.
// ==========================================================

const PRODUCT_CONFIG_HELP = {

    ConfigLastOptimized: {
        intro:
            "Zeigt, wann zuletzt ein Optimizer-Ergebnis tatsächlich in die persönliche Trading-Konfiguration übernommen wurde.",
        sections: [
            [
                "Bedeutung",
                "Der Zeitpunkt ändert sich erst, wenn eine Optimierung nicht nur berechnet, sondern als neue Konfiguration übernommen wurde."
            ],
            [
                "Beispiel",
                "Steht hier 15.08.2026, stammen die aktuell übernommenen Optimizer-Werte zuletzt von diesem Zeitpunkt."
            ]
        ]
    },

    Symbol: {
        intro:
            "Bestimmt das Handelspaar, dessen Kurs der Trader verarbeitet.",
        sections: [
            [
                "Wirkung",
                "Bei BTCUSDC wird Bitcoin gegen USDC ausgewertet und gehandelt. Kursdaten, BUYs, ReBUYs und SELLs beziehen sich auf dieses Paar."
            ],
            [
                "Beispiel",
                "BTCUSDC bedeutet: Der BTC-Kurs wird in USDC angegeben."
            ]
        ]
    },

    LoopIntervalSeconds: {
        intro:
            "Bestimmt den zeitlichen Abstand zwischen zwei normalen Durchläufen des Traders.",
        sections: [
            [
                "Kleinerer Wert",
                "Der Trader verarbeitet neue Daten häufiger und reagiert zeitlich schneller."
            ],
            [
                "Größerer Wert",
                "Die Verarbeitung erfolgt seltener. Dadurch entsprechen gleich große Kursfenster einem längeren Zeitraum."
            ],
            [
                "Beispiel",
                "Bei 10 Sekunden Loop-Intervall entsprechen 30 fortlaufende Kurswerte ungefähr 5 Minuten."
            ]
        ]
    },

    Rule: {
        intro:
            "Legt fest, welche Trading-Strategie die persönlichen Kursdaten auswertet.",
        sections: [
            [
                "ValleyPeak",
                "Sucht einen Kurs unterhalb seines gleitenden Durchschnitts und wartet zusätzlich auf eine beginnende Erholung, bevor ein Erst-BUY entsteht."
            ],
            [
                "TrendPullback",
                "Sucht zunächst einen bestätigten Aufwärtstrend, danach einen Rücksetzer und schließlich eine Erholung vom Pullback-Tief."
            ],
            [
                "Wichtig",
                "Die zugehörigen Strategieparameter wirken nur auf die jeweils verwendete Regel."
            ]
        ],
        warning:
            "Ein Wechsel der Trading-Regel verändert die Bedingungen für zukünftige Einstiege."
    },

    TestWalletUSDC: {
        intro:
            "Bestimmt das Kapital des persönlichen simulierten TestWallets.",
        sections: [
            [
                "Wirkung",
                "Dieses USDC-Guthaben steht für simulierte BUYs und ReBUYs zur Verfügung. Es werden dabei keine echten Binance-Orders ausgeführt."
            ],
            [
                "Kleinerer Wert",
                "Weniger Kapital steht für weitere BUY- oder ReBUY-Stufen zur Verfügung."
            ],
            [
                "Größerer Wert",
                "Mehr simuliertes Kapital erlaubt entsprechend mehr oder größere Käufe."
            ],
            [
                "Beispiel",
                "Bei 1.000 USDC TestWallet und 100 USDC Handelsbetrag können rechnerisch bis zu zehn Käufe zu je 100 USDC finanziert werden."
            ]
        ],
        warning:
            "Eine Änderung des TestWallet-Budgets wird nur im sicheren Zustand ohne offene Position und bei pausiertem Trading gespeichert."
    },

    MaxLivePositionUSDC: {
        intro:
            "Begrenzt das insgesamt in eine offene LIVE-Position investierte Kapital.",
        sections: [
            [
                "Einheit",
                "Der Wert wird in USDC angegeben."
            ],
            [
                "Harte LIVE-Grenze",
                "BUY und ReBUY dürfen zusammen niemals mehr Kapital in die offene LIVE-Position investieren als hier eingestellt."
            ],
            [
                "Unabhängig vom Optimizer",
                "Dieses Sicherheitslimit wird nicht vom Auto-Optimizer verändert. Auch ein höheres Max Buy Count darf die eingestellte LIVE-Grenze nicht überschreiten."
            ],
            [
                "Beispiel",
                "Bei 10 USDC Handelsbetrag und 100 USDC Max. LIVE-Position können höchstens 100 USDC insgesamt in die Position investiert werden."
            ],
            [
                "0 bedeutet gesperrt",
                "Steht der Wert auf 0 USDC, bleiben echte LIVE-BUYs und LIVE-ReBUYs gesperrt."
            ]
        ],
        warning:
            "Dies ist die harte Kapitalgrenze für eine LIVE-Position. Das TestWallet-Budget hat im LIVE-Modus darauf keinen Einfluss."
    },


    TradeAmount: {
        intro:
            "Legt den festen USDC-Betrag für einen BUY oder ReBUY fest.",
        sections: [
            [
                "Wirkung",
                "Jeder ausgeführte Erst-BUY und jeder ReBUY verwendet diesen Betrag."
            ],
            [
                "Kleinerer Wert",
                "Jede Kaufstufe bindet weniger Kapital."
            ],
            [
                "Größerer Wert",
                "Jede Kaufstufe bindet mehr Kapital und das Wallet kann entsprechend früher ausgeschöpft sein."
            ],
            [
                "Beispiel",
                "100 USDC Handelsbetrag und Max Buy Count 3 bedeuten maximal einen Erst-BUY plus zwei ReBUYs zu jeweils 100 USDC."
            ]
        ],
        warning:
            "Handelsbetrag, Max Buy Count und verfügbares Wallet-Kapital sollten immer zusammen betrachtet werden."
    },

    MaxBuyCount: {
        intro:
            "Begrenzt die maximale Anzahl aller Käufe innerhalb einer Position.",
        sections: [
            [
                "Wichtig",
                "Der erste BUY zählt bereits mit. Der Wert beschreibt also nicht nur die Anzahl der ReBUYs."
            ],
            [
                "Beispiel",
                "Max Buy Count 3 bedeutet: 1 Erst-BUY + maximal 2 ReBUYs."
            ],
            [
                "ReBUY-Stufen",
                "Die Zahl der tatsächlich nutzbaren ReBUY-Stufen ist immer Max Buy Count minus 1. Zusätzliche gespeicherte ReBUY-Abstände bleiben erhalten, sind aber inaktiv."
            ],
            [
                "Kapital",
                "Ein höherer Wert kann mehr Kapital binden, weil zusätzliche Nachkäufe möglich werden."
            ]
        ],
        warning:
            "Max Buy Count sollte zusammen mit Handelsbetrag, TestWallet und der ReBUY-Kurve eingestellt werden."
    },

    MinProfitPercent: {
        intro:
            "Bestimmt den gewünschten Mindestgewinn über dem durchschnittlichen Kaufpreis, bevor der SELL-Bereich erreicht wird.",
        sections: [
            [
                "Berechnung",
                "Zur SELL-Schwelle addiert die Strategie außerdem BUY- und SELL-Gebühr. Erst oberhalb dieser Gesamtschwelle beginnt die Smart-Sell-Überwachung."
            ],
            [
                "Kleinerer Wert",
                "Der SELL-Bereich kann früher erreicht werden."
            ],
            [
                "Größerer Wert",
                "Die Position benötigt einen stärkeren Kursanstieg, bevor der SELL-Bereich erreicht wird."
            ],
            [
                "Beispiel",
                "Bei 0,30 % Min Profit, 0,10 % BUY Fee und 0,10 % SELL Fee liegt die berechnete Mindestschwelle bei insgesamt 0,50 % über dem durchschnittlichen Kaufpreis."
            ],
            [
                "Smart Sell",
                "Nach Erreichen der Schwelle beobachtet die Strategie den weiteren Verlauf. Sie verkauft unter anderem beim Rückfall auf das Mindestziel oder bei drei aufeinanderfolgenden fallenden Beobachtungen."
            ]
        ],
        warning:
            "Ein sehr hoher Mindestgewinn kann Positionen deutlich länger offen halten."
    },

    ReBuyDistances: {
        intro:
            "Definiert die Kursabstände der einzelnen ReBUY-Stufen in USDC.",
        sections: [
            [
                "Bezugspunkt",
                "Der Abstand wird jeweils vom Preis des letzten ausgeführten Kaufs gemessen – nicht vom durchschnittlichen Kaufpreis und nicht in Prozent."
            ],
            [
                "Beispiel",
                "Liegt der letzte Kauf bei 100.000 USDC und ReBUY 1 bei 100 USDC, wird diese Stufe ab etwa 99.900 USDC erreicht."
            ],
            [
                "Nächste Stufe",
                "Nach einem ausgeführten ReBUY wird für die nächste Stufe wieder vom neuen letzten Kaufpreis aus gerechnet."
            ],
            [
                "Max Buy Count",
                "Nur Max Buy Count minus 1 ReBUY-Stufen können innerhalb einer Position verwendet werden. Weitere gespeicherte Werte bleiben als Reserve erhalten."
            ]
        ],
        warning:
            "Kleine Abstände führen zu schnelleren Nachkäufen. Große Abstände verteilen weitere Käufe stärker über fallende Kurse."
    },

    Window: {
        intro:
            "Bestimmt, aus wie vielen jüngsten Kurswerten ValleyPeak seinen Durchschnitt berechnet.",
        sections: [
            [
                "Wirkung",
                "Der Trader wartet zunächst, bis genügend Werte vorhanden sind. Danach wird der Durchschnitt der letzten Window-Werte mit dem aktuellen Kurs verglichen."
            ],
            [
                "Kleinerer Wert",
                "Der Durchschnitt reagiert schneller auf kurzfristige Kursbewegungen."
            ],
            [
                "Größerer Wert",
                "Der Durchschnitt wird ruhiger und bildet einen längeren Zeitraum ab."
            ],
            [
                "Beispiel",
                "Bei 10 Sekunden Loop-Intervall entspricht Window 30 ungefähr 5 Minuten. Window 100 entspricht ungefähr 16 Minuten und 40 Sekunden."
            ]
        ],
        warning:
            "Window und BUY unter Durchschnitt % bestimmen gemeinsam, wann ValleyPeak einen möglichen Einstieg erkennt."
    },

    BuyBelowAveragePercent: {
        intro:
            "Bestimmt, wie weit der aktuelle Kurs für einen ValleyPeak-Erst-BUY mindestens unter dem berechneten Durchschnitt liegen muss.",
        sections: [
            [
                "Berechnung",
                "Der Abstand wird prozentual aus Durchschnitt und aktuellem Kurs berechnet."
            ],
            [
                "Zusatzbedingung",
                "Der Abstand allein erzeugt noch keinen BUY. ValleyPeak verlangt zusätzlich, dass der jüngste Kurs gegenüber dem vorherigen Kurs bereits wieder steigt."
            ],
            [
                "Kleinerer Wert",
                "Schon kleinere Rückgänge unter den Durchschnitt können als Einstieg ausreichen."
            ],
            [
                "Größerer Wert",
                "Der Kurs muss deutlich weiter unter dem Durchschnitt liegen."
            ],
            [
                "Beispiel",
                "Bei 100.000 USDC Durchschnitt bedeuten 0,15 % ungefähr 150 USDC Abstand unter dem Durchschnitt."
            ]
        ]
    },

    TrendPullbackTrendWindow: {
        intro:
            "Bestimmt die Anzahl der Kurswerte, mit denen TrendPullback den übergeordneten Trend beurteilt.",
        sections: [
            [
                "Berechnung",
                "Die Strategie vergleicht den Durchschnitt des ersten Fünftels mit dem Durchschnitt des letzten Fünftels dieses Fensters."
            ],
            [
                "Kleinerer Wert",
                "Kurzfristige Trendänderungen wirken schneller auf die Erkennung."
            ],
            [
                "Größerer Wert",
                "Der Trend wird über einen längeren und ruhigeren Zeitraum beurteilt."
            ],
            [
                "Beispiel",
                "Bei 10 Sekunden pro Kurswert entsprechen 180 Werte ungefähr 30 Minuten."
            ]
        ]
    },

    TrendPullbackMinTrendPercent: {
        intro:
            "Bestimmt den Mindestanstieg, den TrendPullback für einen bestätigten Aufwärtstrend verlangt.",
        sections: [
            [
                "Wirkung",
                "Liegt der berechnete Trend unter diesem Wert, wartet die Strategie und verwirft den laufenden Pullback-Zustand."
            ],
            [
                "Kleinerer Wert",
                "Auch schwächere Aufwärtstrends können akzeptiert werden."
            ],
            [
                "Größerer Wert",
                "Nur deutlich stärkere Aufwärtstrends werden weiter verfolgt."
            ]
        ]
    },

    TrendPullbackPullbackPercent: {
        intro:
            "Bestimmt, wie weit der Kurs vom beobachteten Trend-Hoch zurückfallen muss, bevor TrendPullback einen echten Pullback erkennt.",
        sections: [
            [
                "Wirkung",
                "Nach bestätigtem Aufwärtstrend verfolgt die Strategie das Hoch. Erst der eingestellte prozentuale Rückgang aktiviert den Pullback."
            ],
            [
                "Kleinerer Wert",
                "Kleinere Rücksetzer werden bereits berücksichtigt."
            ],
            [
                "Größerer Wert",
                "Die Strategie wartet auf einen stärkeren Rücksetzer."
            ]
        ]
    },

    TrendPullbackRecoveryPercent: {
        intro:
            "Bestimmt die notwendige Erholung vom tiefsten Punkt des Pullbacks, bevor TrendPullback den Erst-BUY auslöst.",
        sections: [
            [
                "Wirkung",
                "Während des Rücksetzers wird das tiefste Kursniveau verfolgt. Erst wenn sich der Kurs von diesem Tief ausreichend erholt, entsteht der BUY."
            ],
            [
                "Kleinerer Wert",
                "Schon eine kleine Erholung kann den Einstieg bestätigen."
            ],
            [
                "Größerer Wert",
                "Es wird auf eine deutlichere Gegenbewegung nach oben gewartet."
            ],
            [
                "Beispiel",
                "Bei einem Pullback-Tief von 100.000 USDC entsprechen 0,20 % Erholung ungefähr 200 USDC."
            ]
        ]
    },

    BuyFee: {
        intro:
            "Beschreibt die für einen BUY berücksichtigte Handelsgebühr in Prozent.",
        sections: [
            [
                "Wirkung",
                "Die Gebühr wird bei der Simulation berücksichtigt und fließt außerdem zusammen mit der SELL-Gebühr in die notwendige Mindestgewinn-Schwelle ein."
            ],
            [
                "Beispiel",
                "0,10 % entspricht 0,10 USDC Gebühr je 100 USDC zugrunde gelegtem Handelsvolumen."
            ]
        ]
    },

    SellFee: {
        intro:
            "Beschreibt die für einen SELL berücksichtigte Handelsgebühr in Prozent.",
        sections: [
            [
                "Wirkung",
                "Die Gebühr wird bei der Simulation berücksichtigt und wird zusammen mit BUY Fee und Min Profit in die SELL-Schwelle eingerechnet."
            ],
            [
                "Beispiel",
                "0,10 % SELL Fee und 0,10 % BUY Fee erhöhen bei 0,30 % Min Profit die Mindestschwelle auf insgesamt 0,50 %."
            ]
        ]
    },

    TestWallet: {
        intro:
            "Legt fest, dass der Trader mit dem internen simulierten Wallet statt mit einem echten Binance-Wallet arbeitet.",
        sections: [
            [
                "Wirkung",
                "BUY, ReBUY und SELL verändern nur das TestWallet und die zugehörigen persönlichen Testdaten."
            ],
            [
                "Zweck",
                "Strategie, Bedienung und Verhalten können damit ohne echte Orders getestet werden."
            ]
        ]
    },

    OptimizerMode: {
        intro:
            "Bestimmt, ob der Trader im speziellen Optimizer-Betrieb gestartet wird.",
        sections: [
            [
                "Wirkung",
                "Im Optimizer-Modus steht die Auswertung historischer Kursdaten und verschiedener Parameterkombinationen im Mittelpunkt statt des normalen Tradingbetriebs."
            ],
            [
                "Zusammenspiel",
                "Die Optimizer-Konfiguration bestimmt Zeitraum, Bewertung und gegebenenfalls die Auswahl eines Ergebnisses. Das verwendete Kapital ergibt sich automatisch aus Handelsbetrag, maximalen Käufen und der Kapitalgrenze des gewählten Betriebsmodus."
            ]
        ]
    },

    LiveTradingEnabled: {
        intro:
            "Ist die übergeordnete Freigabe für echte Binance-Orders.",
        sections: [
            [
                "Wirkung",
                "Ohne diese Master-Freigabe dürfen keine echten BUY- oder SELL-Orders ausgeführt werden."
            ],
            [
                "Zusammenspiel",
                "Zusätzliche Berechtigungen für LIVE BUY/ReBUY und LIVE SELL können die erlaubten Orderarten weiter einschränken."
            ]
        ],
        warning:
            "LIVE Trading betrifft echtes Kapital und ist deshalb eine besonders sicherheitskritische Einstellung."
    },

    AllowLiveBuyReBuy: {
        intro:
            "Steuert innerhalb des LIVE-Betriebs die Freigabe für neue echte BUY- und ReBUY-Orders.",
        sections: [
            [
                "Wirkung",
                "Ist diese Berechtigung gesperrt, darf der Trader keine neue echte Position eröffnen und keine echten Nachkäufe ausführen."
            ],
            [
                "Sicherheitsprinzip",
                "Die BUY-/ReBUY-Freigabe ist bewusst getrennt von der SELL-Freigabe."
            ]
        ],
        warning:
            "Die Aktivierung kann neues reales Kapital in den Markt bringen."
    },

    AllowLiveSell: {
        intro:
            "Steuert innerhalb des LIVE-Betriebs die Freigabe für echte SELL-Orders.",
        sections: [
            [
                "Wirkung",
                "Diese Berechtigung entscheidet, ob vorhandene echte Positionen über den Trader verkauft werden dürfen."
            ],
            [
                "Sicherheitsprinzip",
                "SELL ist bewusst getrennt von BUY/ReBUY, damit das Schließen einer bestehenden Position unabhängig abgesichert werden kann."
            ]
        ],
        warning:
            "Bei einer LIVE-Position ist die Möglichkeit zum sicheren Schließen besonders wichtig."
    },

    UseTradeSecurity: {
        intro:
            "Ist der übergeordnete Schalter für die zusätzlichen Trade-Sicherheitsprüfungen.",
        sections: [
            [
                "Wirkung",
                "Ist Trade Security aktiv, werden vor einer Order nacheinander Wallet-, Positions- und Preisprüfungen ausgeführt."
            ],
            [
                "Zusammenspiel",
                "Wallet Protection, Position Protection und Price Protection sind Teil dieses Sicherheitsdienstes."
            ]
        ],
        warning:
            "Das Abschalten der übergeordneten Sicherheitsprüfung würde auch die darunterliegenden Prüfungen umgehen."
    },

    UseWalletProtection: {
        intro:
            "Prüft vor Orders, ob die erforderlichen Wallet-Bestände vorhanden sind.",
        sections: [
            [
                "BUY",
                "Ein BUY wird abgelehnt, wenn der vorhandene USDC-Bestand unter Min USDC liegt."
            ],
            [
                "SELL",
                "Ein SELL wird abgelehnt, wenn der vorhandene BTC-Bestand unter Min BTC liegt."
            ]
        ]
    },

    UsePositionProtection: {
        intro:
            "Schützt den Trader vor unzulässigen BUY- und SELL-Zuständen einer Position.",
        sections: [
            [
                "BUY und ReBUY",
                "Der Erst-BUY ist ohne offene Position erlaubt. Weitere Käufe sind nur möglich, solange Max Buy Count noch nicht erreicht ist."
            ],
            [
                "SELL",
                "Ein SELL wird abgelehnt, wenn keine Position geöffnet ist."
            ]
        ]
    },

    UsePriceProtection: {
        intro:
            "Vergleicht unmittelbar vor einer Order den erwarteten Signalpreis mit dem aktuellen Marktpreis.",
        sections: [
            [
                "BUY / ReBUY",
                "Ein günstigerer Marktpreis ist automatisch zulässig. Ist der Marktpreis höher als der Signalpreis, darf die Verschlechterung die konfigurierte BUY-Abweichung nicht überschreiten."
            ],
            [
                "SELL",
                "Ein höherer Marktpreis ist automatisch zulässig. Ist der Marktpreis niedriger als der Signalpreis, darf die Verschlechterung die konfigurierte SELL-Abweichung nicht überschreiten."
            ]
        ]
    },

    MinUSDC: {
        intro:
            "Definiert den Mindest-USDC-Bestand für die Wallet-Sicherheitsprüfung vor einem BUY.",
        sections: [
            [
                "Wirkung",
                "Liegt der vorhandene USDC-Bestand unter diesem Wert, verwirft Wallet Protection den BUY."
            ],
            [
                "Beispiel",
                "Min USDC 10 verlangt vor einem BUY mindestens 10 USDC vorhandenen Bestand."
            ]
        ]
    },

    MinBTC: {
        intro:
            "Definiert den Mindest-BTC-Bestand für die Wallet-Sicherheitsprüfung vor einem SELL.",
        sections: [
            [
                "Wirkung",
                "Liegt der vorhandene BTC-Bestand unter diesem Wert, verwirft Wallet Protection den SELL."
            ]
        ]
    },

    MaxBuyPriceDeviationPercent: {
        intro:
            "Begrenzt eine ungünstige Preisverschlechterung zwischen BUY-Signal und aktuellem Marktpreis.",
        sections: [
            [
                "Wirkung",
                "Ein Marktpreis unterhalb des Signalpreises ist günstiger und wird akzeptiert. Nur ein höherer Marktpreis wird auf die maximale Abweichung geprüft."
            ],
            [
                "Beispiel",
                "Bei 100.000 USDC Signalpreis und 0,20 % Grenze dürfte der Marktpreis höchstens ungefähr 200 USDC ungünstiger sein."
            ]
        ]
    },

    MaxSellPriceDeviationPercent: {
        intro:
            "Begrenzt eine ungünstige Preisverschlechterung zwischen SELL-Signal und aktuellem Marktpreis.",
        sections: [
            [
                "Wirkung",
                "Ein Marktpreis oberhalb des Signalpreises ist günstiger und wird akzeptiert. Nur ein niedrigerer Marktpreis wird auf die maximale Abweichung geprüft."
            ],
            [
                "Beispiel",
                "Bei 100.000 USDC Signalpreis und 0,20 % Grenze entspricht die zulässige ungünstige Abweichung ungefähr 200 USDC."
            ]
        ]
    },

    MaxLiveSellBTC: {
        intro:
            "Setzt eine zusätzliche absolute Obergrenze für einen echten LIVE-SELL.",
        sections: [
            [
                "Einheit",
                "Dieser Wert ist eine BTC-Menge. Er ist ausdrücklich KEIN USDC- oder Dollar-Betrag."
            ],
            [
                "Sicherheitsgrenze",
                "Der LIVE-SELL darf höchstens den kleinsten Wert aus bot-eigener offener Positionsmenge, tatsächlich verfügbarem Binance-BTC-Bestand und Max. LIVE SELL (BTC) verkaufen."
            ],
            [
                "Beispiel",
                "Der Wert 0,001 bedeutet maximal 0,001 BTC. Der Wert 100 bedeutet 100 BTC und nicht 100 USDC."
            ],
            [
                "0 bedeutet gesperrt",
                "Steht Max. LIVE SELL (BTC) auf 0, ist ein echter LIVE-SELL gesperrt."
            ],
            [
                "Wichtig",
                "Dieses Feld allein aktiviert kein LIVE-Trading und ersetzt nicht die Begrenzung auf die bot-eigene Position."
            ]
        ],
        warning:
            "ACHTUNG: BTC-Menge, kein USDC-Betrag. Dieses Feld ist nur eine zusätzliche SELL-Sicherheitsgrenze."
    },


    ScoreProfitWeight: {
        intro:
            "Bestimmt, welchen Anteil der Profit-Bewertung am gewichteten Optimizer-Gesamtscore hat.",
        sections: [
            [
                "Wirkung",
                "Ein höheres Gewicht bevorzugt Kandidaten stärker aufgrund ihres erzielten Ergebnisses."
            ],
            [
                "Zusammenspiel",
                "Alle Optimizer-Gewichtungen werden zu einem Gesamtscore kombiniert und müssen zusammen 100 % ergeben."
            ]
        ]
    },

    ScoreTradeWeight: {
        intro:
            "Bestimmt, wie stark die Anzahl erfolgreich abgeschlossener Positionen in den Optimizer-Gesamtscore einfließt.",
        sections: [
            [
                "Wirkung",
                "Ein höheres Gewicht bevorzugt stärker Kandidaten, die im betrachteten Zeitraum mehr Positionen vollständig abschließen."
            ],
            [
                "Zusammenspiel",
                "Die Summe aller Score-Gewichtungen muss 100 % ergeben."
            ]
        ]
    },

    ScoreHoldWeight: {
        intro:
            "Bestimmt, wie stark eine kurze durchschnittliche Haltedauer im Optimizer bewertet wird.",
        sections: [
            [
                "Wirkung",
                "Ein höheres Gewicht gibt Kandidaten mit kürzerer durchschnittlicher Positionsdauer mehr Bedeutung im Gesamtscore."
            ],
            [
                "Zusammenspiel",
                "Die Summe aller Score-Gewichtungen muss 100 % ergeben."
            ]
        ]
    },

    ScoreReBuyWeight: {
        intro:
            "Bestimmt, wie stark eine geringe durchschnittliche Anzahl von ReBUYs im Optimizer bewertet wird.",
        sections: [
            [
                "Wirkung",
                "Ein höheres Gewicht bevorzugt im Gesamtscore stärker Kandidaten, die im Mittel mit weniger Nachkäufen auskommen."
            ],
            [
                "Zusammenspiel",
                "Die Summe aller Score-Gewichtungen muss 100 % ergeben."
            ]
        ]
    },

    ScoreStabilityWeight: {
        intro:
            "Bestimmt, wie stark Stabilität und Konstanz eines Optimizer-Ergebnisses in den Gesamtscore eingehen.",
        sections: [
            [
                "Wirkung",
                "Ein höheres Gewicht gibt der Stabilitätsbewertung gegenüber den anderen Bewertungskriterien mehr Einfluss."
            ],
            [
                "Zusammenspiel",
                "Die Summe aller Score-Gewichtungen muss 100 % ergeben."
            ]
        ]
    },

    ScoreMaxHoldWeight: {
        intro:
            "Bestimmt, wie stark eine möglichst kurze maximale Haltedauer im Optimizer bewertet wird.",
        sections: [
            [
                "Wirkung",
                "Damit kann nicht nur der Durchschnitt, sondern besonders eine sehr lange einzelne Position stärker gewichtet werden."
            ],
            [
                "Zusammenspiel",
                "Die Summe aller Score-Gewichtungen muss 100 % ergeben."
            ]
        ]
    },

    OptimizerWinnerSelection: {
        intro:
            "Legt fest, welche Optimizer-Auswertung bei automatischer Übernahme als Gewinner verwendet wird.",
        sections: [
            [
                "Auswahl 0",
                "Keine automatische Übernahme. Der Optimizer erstellt nur seine Auswertung."
            ],
            [
                "Weitere Kategorien",
                "Zur Auswahl gehören Gesamtsieger, Profit-Sieger, Hold-Sieger, schnellster Trader, wenigste ReBUYs und höchste Effizienz."
            ],
            [
                "Gesamtsieger",
                "Der Gesamtsieger wird aus dem gewichteten Score der einzelnen Bewertungskriterien bestimmt."
            ]
        ],
        warning:
            "Eine automatische Gewinnerübernahme kann zukünftige Strategieparameter verändern."
    },

    AutoOptimizerEnabled: {
        intro:
            "Aktiviert den automatischen Optimizer für regelmäßige persönliche Strategieauswertungen.",
        sections: [
            [
                "Startbedingung",
                "Ein automatischer Lauf wird erst nach einem erfolgreichen SELL und bei vollständig geschlossener Position ausgeführt."
            ],
            [
                "Intervall",
                "Zusätzlich wird geprüft, ob seit dem letzten Lauf mindestens das eingestellte Optimizer-Intervall vergangen ist."
            ],
            [
                "Kapital",
                "Das verwendete Startkapital wird durch verfügbares Wallet-Kapital und das Optimizer-Startkapital-Limit begrenzt."
            ]
        ]
    },

    AutoOptimizerIntervalDays: {
        intro:
            "Bestimmt die Mindestanzahl von Tagen zwischen zwei automatischen Optimizer-Läufen.",
        sections: [
            [
                "Wirkung",
                "Nach Ablauf des Intervalls wartet der automatische Ablauf weiterhin auf einen geeigneten neutralen Zeitpunkt nach einem SELL."
            ],
            [
                "Kleinerer Wert",
                "Die Strategie kann häufiger neu ausgewertet werden."
            ],
            [
                "Größerer Wert",
                "Zwischen zwei Optimierungen liegt mehr reale Marktzeit."
            ]
        ]
    },

    OptimizerLookbackDays: {
        intro:
            "Bestimmt, wie viele Tage der vorhandenen Preishistorie der Optimizer für einen Lauf verwendet.",
        sections: [
            [
                "Wert 0",
                "Verwendet die komplette verfügbare Historie."
            ],
            [
                "Beispiel",
                "Wert 7 beschränkt die Optimierung auf ungefähr die letzten sieben Tage der verfügbaren Kursdaten."
            ],
            [
                "Zusammenspiel",
                "Bei dynamischer Marktanalyse kann der tatsächlich verwendete Zeitraum zusätzlich an die erkannte Marktphase angepasst werden."
            ]
        ]
    },

    AutoOptimizerLastRun: {
        intro:
            "Zeigt den Zeitpunkt des letzten vollständig ausgeführten automatischen Optimizer-Laufs.",
        sections: [
            [
                "Wirkung",
                "Dieser Zeitstempel wird zusammen mit dem Optimizer-Intervall verwendet, um den nächsten möglichen automatischen Lauf zu bestimmen."
            ]
        ]
    },

    UseMarketAnalysis: {
        intro:
            "Aktiviert die automatische Analyse der aktuellen Marktphase.",
        sections: [
            [
                "Analyse",
                "Dabei werden unter anderem Trendrichtung, Kursspanne, Bewegungseffizienz, Volatilität und schnelle außergewöhnliche Bewegungen aus mehreren Zeitfenstern ausgewertet."
            ],
            [
                "Zweck",
                "Das Ergebnis kann für Optimizer-Empfehlungen und weitere adaptive Entscheidungen des Traders verwendet werden."
            ]
        ]
    },

    MarketAnalysisDynamicLookback: {
        intro:
            "Erlaubt der Marktphasenanalyse, den tatsächlich verwendeten Optimizer-Zeitraum dynamisch anzupassen.",
        sections: [
            [
                "Wirkung",
                "Statt immer nur einen festen Lookback zu verwenden, kann die Analyse abhängig von der Marktphase einen Zeitraum zwischen 1 und 7 Tagen empfehlen."
            ],
            [
                "Zweck",
                "Damit kann der Optimizer stärker auf jüngere oder etwas länger anhaltende Marktbedingungen reagieren."
            ]
        ]
    },

    MarketAnalysisDynamicWindow: {
        intro:
            "Erlaubt die automatische Übernahme eines von der Marktphasenanalyse empfohlenen ValleyPeak-Windows.",
        sections: [
            [
                "Wirkung",
                "Bei ausreichend sicherer Empfehlung kann beim Übernehmen eines Optimizer-Ergebnisses auch das ValleyPeak-Window angepasst werden."
            ],
            [
                "Abgrenzung",
                "Diese Funktion bezieht sich auf das ValleyPeak-Window. TrendPullback bleibt davon unabhängig."
            ]
        ],
        warning:
            "Eine dynamische Window-Übernahme verändert die zeitliche Empfindlichkeit von ValleyPeak."
    },

    BuyEntryGuardEnabled: {
        intro:
            "Aktiviert eine zusätzliche Hintergrundanalyse für erfolgreich ausgeführte BUY-Einstiege.",
        sections: [
            [
                "Wirkung",
                "Der Einstieg wird nachträglich analysiert und das Ergebnis für spätere Auswertungen gespeichert."
            ],
            [
                "Trading",
                "Die Shadow-Analyse läuft getrennt vom eigentlichen Trading und verändert oder blockiert BUY, ReBUY oder SELL nicht."
            ]
        ]
    },

    ShockGuardUpEnabled: {
        intro:
            "Schützt BUY und ReBUY nach einem neu erkannten starken UP-Shock.",
        sections: [
            [
                "Wirkung",
                "Bei einem neuen UP-Shock werden BUY und ReBUY für die eingestellte Sperrzeit blockiert."
            ],
            [
                "Freigabe",
                "Nach Ablauf der Sperrzeit wird wieder freigegeben. Derselbe weiterhin sichtbare UP-Shock startet die Sperrzeit nicht erneut."
            ],
            [
                "Neues Ereignis",
                "Erst nachdem der UP-Shock zwischenzeitlich verschwunden ist, kann ein späterer neuer UP-Shock wieder eine Schutzzeit starten."
            ],
            [
                "SELL / Recovery",
                "SELL und Recovery werden durch Shock Guard ↑ nicht blockiert."
            ],
            [
                "Abgrenzung",
                "DOWN- und RANGE-Shocks werden in dieser ersten Version weiterhin nur beobachtet und lösen keine aktive Sperre aus."
            ]
        ]
    }
};


function productConfigHelpDefinition(
    name,
    field,
    definition) {

    const configured =
        PRODUCT_CONFIG_HELP[name];

    if (configured)
        return configured;


    const description =
        String(
            configProperty(
                field,
                "Description",
                "description")
            || ""
        ).trim();


    return {
        intro:
            description ||
            "Diese Einstellung gehört zur persönlichen BTC-Trader-Konfiguration.",
        sections: [
            [
                "Bedeutung",
                description ||
                "Der Wert wird von der zugehörigen Funktion des Traders verwendet."
            ]
        ]
    };
}


function ensureProductConfigHelpDialog() {

    let overlay =
        byId(
            "productConfigHelpOverlay");

    if (overlay)
        return overlay;


    overlay =
        document.createElement(
            "div");

    overlay.id =
        "productConfigHelpOverlay";

    overlay.className =
        "config-help-overlay";

    overlay.hidden =
        true;


    overlay.innerHTML = `
        <div class="config-help-backdrop"
             data-config-help-close="true"></div>

        <section class="config-help-sheet"
                 role="dialog"
                 aria-modal="true"
                 aria-labelledby="productConfigHelpTitle">

            <div class="config-help-handle"
                 aria-hidden="true"></div>

            <div class="config-help-head">
                <div>
                    <div class="config-help-eyebrow">
                        BTC TRADER PRO · INFORMATION
                    </div>

                    <h3 id="productConfigHelpTitle">
                        Information
                    </h3>
                </div>

                <button type="button"
                        class="config-help-close"
                        data-config-help-close="true"
                        aria-label="Information schließen">
                    ×
                </button>
            </div>

            <div id="productConfigHelpCurrent"
                 class="config-help-current"></div>

            <div id="productConfigHelpBody"
                 class="config-help-body"></div>
        </section>
    `;


    overlay.addEventListener(
        "click",
        event => {

            if (
                event.target?.dataset
                    ?.configHelpClose ===
                "true"
            ) {
                closeProductConfigHelp();
            }
        });


    document.body.appendChild(
        overlay);


    return overlay;
}


function closeProductConfigHelp() {

    const overlay =
        byId(
            "productConfigHelpOverlay");

    if (!overlay)
        return;


    overlay.classList.remove(
        "is-open");

    document.body.classList.remove(
        "config-help-open");


    window.setTimeout(
        () => {
            if (
                !overlay.classList
                    .contains(
                        "is-open")
            ) {
                overlay.hidden =
                    true;
            }
        },
        180);
}


function openProductConfigHelp(
    name,
    field,
    definition) {

    const overlay =
        ensureProductConfigHelpDialog();

    const help =
        productConfigHelpDefinition(
            name,
            field,
            definition);


    const value =
        configProperty(
            field,
            "Value",
            "value");


    byId(
        "productConfigHelpTitle")
        .textContent =
            definition.label ||
            name;


    const current =
        byId(
            "productConfigHelpCurrent");

    current.replaceChildren();


    const currentLabel =
        document.createElement(
            "span");

    currentLabel.textContent =
        "Aktueller Wert";


    const currentValue =
        document.createElement(
            "strong");

    currentValue.textContent =
        formatProductConfigValue(
            name,
            value,
            definition);


    current.appendChild(
        currentLabel);

    current.appendChild(
        currentValue);


    const body =
        byId(
            "productConfigHelpBody");

    body.replaceChildren();


    if (help.intro) {

        const intro =
            document.createElement(
                "p");

        intro.className =
            "config-help-intro";

        intro.textContent =
            help.intro;

        body.appendChild(
            intro);
    }


    for (
        const section
        of (
            Array.isArray(
                help.sections)
                ? help.sections
                : []
        )
    ) {

        const block =
            document.createElement(
                "section");

        block.className =
            "config-help-section";


        const heading =
            document.createElement(
                "div");

        heading.className =
            "config-help-section-title";

        heading.textContent =
            section[0] || "Information";


        const copy =
            document.createElement(
                "p");

        copy.textContent =
            section[1] || "";


        block.appendChild(
            heading);

        block.appendChild(
            copy);

        body.appendChild(
            block);
    }


    if (help.warning) {

        const warning =
            document.createElement(
                "div");

        warning.className =
            "config-help-warning";

        warning.textContent =
            help.warning;

        body.appendChild(
            warning);
    }


    overlay.hidden =
        false;


    window.requestAnimationFrame(
        () => {
            overlay.classList.add(
                "is-open");

            document.body.classList.add(
                "config-help-open");
        });


    const sheet =
        overlay.querySelector(
            ".config-help-sheet");

    if (sheet)
        sheet.scrollTop = 0;
}


document.addEventListener(
    "keydown",
    event => {

        if (
            event.key === "Escape" &&
            byId(
                "productConfigHelpOverlay")
                ?.classList
                .contains(
                    "is-open")
        ) {
            closeProductConfigHelp();
        }
    });


function formatProductDate(value) {

    if (!value)
        return "Noch nicht";

    const date =
        new Date(value);

    if (Number.isNaN(
            date.getTime()))
    {
        return String(value);
    }

    return new Intl.DateTimeFormat(
        "de-DE",
        {
            dateStyle: "short",
            timeStyle: "short"
        }
    ).format(date);
}


function formatProductConfigValue(
    name,
    value,
    definition) {

    if (
        value === null ||
        value === undefined ||
        value === ""
    ) {
        return "–";
    }


    if (
        name === "ConfigLastOptimized" ||
        name === "AutoOptimizerLastRun"
    ) {
        return formatProductDate(
            value);
    }


    if (definition.winner) {

        const entry =
            OPTIMIZER_WINNERS.find(
                item =>
                    Number(item[0]) ===
                    Number(value));

        return entry
            ? entry[1]
            : String(value);
    }


    if (Array.isArray(value)) {

        const formatted =
            value.map(
                item =>
                    new Intl.NumberFormat(
                        "de-DE",
                        {
                            maximumFractionDigits: 8
                        }
                    ).format(item)
            );

        return (
            formatted.join(" / ") +
            (
                definition.unit
                    ? " " + definition.unit
                    : ""
            )
        );
    }


    if (typeof value === "boolean") {
        return value
            ? "AN"
            : "AUS";
    }


    if (typeof value === "number") {

        const formatted =
            new Intl.NumberFormat(
                "de-DE",
                {
                    maximumFractionDigits: 8
                }
            ).format(value);

        return (
            formatted +
            (
                definition.unit
                    ? " " + definition.unit
                    : ""
            )
        );
    }


    return String(value);
}


function normalizeConfigNumber(value) {

    const text =
        String(value ?? "")
            .trim()
            .replace(",", ".");

    if (!text)
        throw new Error(
            "Ein Zahlenwert ist leer.");

    const number =
        Number(text);

    if (!Number.isFinite(number))
        throw new Error(
            `Ungültiger Zahlenwert: ${value}`);

    return number;
}


function parseConfigArray(value) {

    const parts =
        String(value ?? "")
            .trim()
            .split(/[\/;,\s]+/)
            .filter(Boolean);

    if (parts.length === 0)
        throw new Error(
            "Mindestens ein ReBUY-Abstand ist erforderlich.");

    return parts.map(
        normalizeConfigNumber);
}


function sameConfigValue(
    left,
    right) {

    return (
        JSON.stringify(left) ===
        JSON.stringify(right)
    );
}


function configInputValue(
    input) {

    const kind =
        input.dataset.configKind;

    if (kind === "bool")
        return Boolean(
            input.checked);

    if (kind === "array")
        return parseConfigArray(
            input.value);


    if (kind === "array-fields") {

        const fields =
            Array.from(
                input.querySelectorAll(
                    "[data-rebuy-distance='true']"
                )
            );


        if (fields.length === 0) {

            throw new Error(
                "Mindestens ein ReBUY-Abstand ist erforderlich.");
        }


        return fields.map(
            (field, index) => {

                const value =
                    normalizeConfigNumber(
                        field.value);


                if (value < 0) {

                    throw new Error(
                        `ReBUY ${index + 1}: Der Abstand darf nicht negativ sein.`);
                }


                return value;
            });
    }

    if (kind === "winner")
        return Number(
            input.value);

    if (kind === "number") {

        const value =
            normalizeConfigNumber(
                input.value);

        if (
            input.dataset.integer === "true" &&
            !Number.isInteger(value)
        ) {
            throw new Error(
                "Dieser Wert muss eine ganze Zahl sein.");
        }

        return value;
    }

    return input.value;
}



// ==========================================================
// M5.1G · CENTER CONFIG LOCK WARNING
// ==========================================================

let configCenterWarningTimer =
    null;

let configCenterWarningCleanupTimer =
    null;


function ensureConfigCenterWarning() {

    let box =
        byId(
            "configCenterWarning");


    if (box)
        return box;


    box =
        document.createElement(
            "div");


    box.id =
        "configCenterWarning";

    box.className =
        "config-center-warning";

    box.setAttribute(
        "role",
        "alert");

    box.setAttribute(
        "aria-live",
        "assertive");

    box.setAttribute(
        "aria-atomic",
        "true");


    const icon =
        document.createElement(
            "div");

    icon.className =
        "config-center-warning-icon";

    icon.textContent =
        "!";


    const copy =
        document.createElement(
            "div");

    copy.className =
        "config-center-warning-copy";


    const title =
        document.createElement(
            "strong");


    const text =
        document.createElement(
            "span");


    copy.appendChild(
        title);

    copy.appendChild(
        text);

    box.appendChild(
        icon);

    box.appendChild(
        copy);

    document.body.appendChild(
        box);


    return box;
}


function showConfigCenterWarning(
    title,
    text,
    duration = 3200) {

    const box =
        ensureConfigCenterWarning();


    if (configCenterWarningTimer) {

        clearTimeout(
            configCenterWarningTimer);

        configCenterWarningTimer =
            null;
    }


    if (configCenterWarningCleanupTimer) {

        clearTimeout(
            configCenterWarningCleanupTimer);

        configCenterWarningCleanupTimer =
            null;
    }


    const titleBox =
        box.querySelector(
            "strong");

    const textBox =
        box.querySelector(
            "span");


    if (titleBox)
        titleBox.textContent =
            title;


    if (textBox)
        textBox.textContent =
            text;


    box.classList.remove(
        "success");

    box.classList.remove(
        "error");

    box.classList.add(
        "warning");


    const icon =
        box.querySelector(
            ".config-center-warning-icon");

    if (icon)
        icon.textContent =
            "!";


    box.classList.remove(
        "is-visible");


    /*
     * Einen Frame warten, damit auch bei mehrfacher
     * Anzeige die Einblendanimation neu startet.
     */
    window.requestAnimationFrame(
        () => {

            window.requestAnimationFrame(
                () => {

                    box.classList.add(
                        "is-visible");
                });
        });


    configCenterWarningTimer =
        window.setTimeout(
            () => {

                box.classList.remove(
                    "is-visible");


                configCenterWarningCleanupTimer =
                    window.setTimeout(
                        () => {

                            configCenterWarningCleanupTimer =
                                null;
                        },
                        250);


                configCenterWarningTimer =
                    null;
            },
            duration);
}



function showConfigCenterSuccess(
    title,
    text,
    duration = 3200) {

    /*
     * Bestehende Center-Blase wiederverwenden.
     * Timer und Animation bleiben identisch.
     */
    showConfigCenterWarning(
        title,
        text,
        duration);


    const box =
        ensureConfigCenterWarning();


    box.classList.remove(
        "warning");

    box.classList.add(
        "success");


    const icon =
        box.querySelector(
            ".config-center-warning-icon");


    if (icon)
        icon.textContent =
            "✓";
}



// ==========================================================
// M5.1H2 · OPTIMIZER SAVE FEEDBACK
// ==========================================================

let configDangerousSaveSignature =
    "";

let configDangerousSaveUntil =
    0;


const PRODUCT_OPTIMIZER_SCORE_FIELDS = [
    "ScoreProfitWeight",
    "ScoreTradeWeight",
    "ScoreHoldWeight",
    "ScoreReBuyWeight",
    "ScoreStabilityWeight",
    "ScoreMaxHoldWeight"
];


function showConfigCenterError(
    title,
    text,
    duration = 5000) {

    showConfigCenterWarning(
        title,
        text,
        duration);


    const box =
        ensureConfigCenterWarning();


    box.classList.remove(
        "warning");

    box.classList.remove(
        "success");

    box.classList.add(
        "error");


    const icon =
        box.querySelector(
            ".config-center-warning-icon");


    if (icon)
        icon.textContent =
            "×";
}


function resetConfigDangerousSaveConfirmation() {

    configDangerousSaveSignature =
        "";

    configDangerousSaveUntil =
        0;
}


function createConfigDangerousSignature(
    changes) {

    return JSON.stringify(
        Object.keys(
            changes || {})
            .sort()
            .map(
                name => [
                    name,
                    changes[name]
                ])
    );
}


function confirmDangerousConfigSave(
    changes) {

    const signature =
        createConfigDangerousSignature(
            changes);

    const now =
        Date.now();


    if (
        signature
        &&
        signature ===
            configDangerousSaveSignature
        &&
        now <=
            configDangerousSaveUntil
    ) {

        resetConfigDangerousSaveConfirmation();

        return true;
    }


    configDangerousSaveSignature =
        signature;

    configDangerousSaveUntil =
        now + 8000;


    showConfigCenterWarning(
        "Sicherheitsbestätigung",
        "Diese Einstellung ist sicherheitsrelevant. Bitte innerhalb von 8 Sekunden noch einmal auf Speichern tippen.",
        5000);


    setConfigActionMessage(
        "Sicherheitsrelevante Änderung: Zum Bestätigen noch einmal auf Speichern tippen.",
        "warning");


    return false;
}


function currentOptimizerScoreValue(
    name) {

    const input =
        document.querySelector(
            `[data-config-name="${name}"]`);


    if (input) {

        try {

            return Number(
                configInputValue(
                    input));
        }
        catch {

            return NaN;
        }
    }


    const field =
        productConfigFields.get(
            name);


    if (!field)
        return NaN;


    return Number(
        configProperty(
            field,
            "Value",
            "value"));
}


function validateOptimizerScoresBeforeSave() {

    const scoreChanged =
        PRODUCT_OPTIMIZER_SCORE_FIELDS
            .some(
                name =>
                    productConfigDirty.has(
                        name));


    if (!scoreChanged)
        return "";


    let sum =
        0;


    for (
        const name
        of PRODUCT_OPTIMIZER_SCORE_FIELDS
    ) {

        const value =
            currentOptimizerScoreValue(
                name);


        if (!Number.isFinite(value)) {

            return (
                "Alle sechs Optimizer-Gewichtungen müssen gültige Zahlen enthalten."
            );
        }


        sum += value;
    }


    const rounded =
        Math.round(
            sum * 1000000)
        /
        1000000;


    if (
        Math.abs(
            rounded - 100)
        >
        0.000001
    ) {

        return (
            "Die sechs Optimizer-Gewichtungen müssen zusammen genau 100 % ergeben. "
            +
            `Aktuell: ${rounded.toLocaleString("de-DE")} %.`
        );
    }


    return "";
}


function showConfigLockedCenterWarning() {

    if (configPositionOpen) {

        showConfigCenterWarning(
            "Position offen",
            "Einstellungen können erst gespeichert werden, wenn die aktuelle Position vollständig geschlossen ist.");

        return;
    }


    showConfigCenterWarning(
        "Trading aktiv",
        "Einstellungen können erst gespeichert werden, wenn das Trading pausiert ist.");
}


function setConfigActionMessage(
    text,
    type = "") {

    const box =
        byId("configActionMessage");

    if (!text) {
        box.textContent = "";
        box.className =
            "config-action-message hidden";
        return;
    }

    box.textContent =
        text;

    box.className =
        "config-action-message" +
        (
            type
                ? " " + type
                : ""
        );
}



// ==========================================================
// PRODUCT · LIVE-BUDGET-KONSISTENZ
// ==========================================================
// Diese Prüfung ist ausschließlich eine UI-Vorprüfung.
//
// Die harte LIVE-Grenze bleibt weiterhin authoritative im
// LiveBuyPreSubmitCoordinator.
//
// TEST und AUS werden hier bewusst NICHT geprüft.
// ==========================================================

function currentConfigEditorValue(name) {

    const input =
        document.querySelector(
            `[data-config-name="${name}"]`);

    if (input) {

        try {

            return configInputValue(
                input);
        }
        catch {
            // Fallback auf den geladenen Config-Wert.
        }
    }


    const field =
        productConfigFields.get(
            name);


    if (!field)
        return null;


    return configProperty(
        field,
        "Value",
        "value");
}


function formatLiveBudgetUsdc(value) {

    const number =
        Number(value);


    if (!Number.isFinite(number))
        return String(value);


    return number.toLocaleString(
        "de-DE",
        {
            minimumFractionDigits: 0,
            maximumFractionDigits: 8
        });
}


function validateLiveBudgetConfiguration() {

    const mode =
        String(
            currentConfigEditorValue(
                "TradingMode")
            ?? "")
            .trim()
            .toUpperCase();


    /*
     * Keine LIVE-Warnung in TEST oder AUS.
     */
    if (mode !== "LIVE")
        return null;


    const tradeAmount =
        Number(
            currentConfigEditorValue(
                "TradeAmount"));


    const maxBuyCount =
        Number(
            currentConfigEditorValue(
                "MaxBuyCount"));


    const maxLiveBudget =
        Number(
            currentConfigEditorValue(
                "MaxLivePositionUSDC"));


    if (
        !Number.isFinite(tradeAmount)
        ||
        tradeAmount <= 0
    ) {

        return {
            message:
                "LIVE-Budget kann nicht geprüft werden: "
                + "Der Handelsbetrag muss größer als 0 USDC sein."
        };
    }


    if (
        !Number.isFinite(maxBuyCount)
        ||
        maxBuyCount < 1
    ) {

        return {
            message:
                "LIVE-Budget kann nicht geprüft werden: "
                + "Maximale Käufe muss mindestens 1 sein."
        };
    }


    if (
        !Number.isFinite(maxLiveBudget)
        ||
        maxLiveBudget <= 0
    ) {

        return {
            message:
                "LIVE-Budget nicht bereit: "
                + "Das maximale LIVE-Budget des Traders "
                + "muss größer als 0 USDC sein. "
                + "Das LIVE-Budget wird niemals automatisch erhöht."
        };
    }


    const plannedMaximum =
        tradeAmount *
        maxBuyCount;


    /*
     * Minimale Float-Toleranz nur für die UI-Berechnung.
     */
    if (
        plannedMaximum <=
        maxLiveBudget + 0.00000001
    ) {

        return null;
    }


    return {
        tradeAmount,
        maxBuyCount,
        maxLiveBudget,
        plannedMaximum,

        message:
            "LIVE-Budget passt nicht: "
            + formatLiveBudgetUsdc(tradeAmount)
            + " USDC × "
            + formatLiveBudgetUsdc(maxBuyCount)
            + " Käufe = bis zu "
            + formatLiveBudgetUsdc(plannedMaximum)
            + " USDC. "
            + "Maximales LIVE-Budget des Traders: "
            + formatLiveBudgetUsdc(maxLiveBudget)
            + " USDC. "
            + "Bitte Handelsbetrag, maximale Käufe "
            + "oder LIVE-Budget bewusst anpassen. "
            + "Das LIVE-Budget wird nicht automatisch erhöht."
    };
}


function updateConfigDirtyState() {

    productConfigDirty.clear();


    document
        .querySelectorAll(
            "[data-config-editable='true']")
        .forEach(
            input => {

                try {

                    const name =
                        input.dataset.configName;

                    const field =
                        productConfigFields.get(
                            name);

                    if (!field)
                        return;


                    const original =
                        configProperty(
                            field,
                            "Value",
                            "value");


                    const current =
                        configInputValue(
                            input);


                    if (
                        !sameConfigValue(
                            original,
                            current)
                    ) {
                        productConfigDirty.add(
                            name);
                    }
                }
                catch {

                    productConfigDirty.add(
                        input.dataset.configName);
                }
            });


    const saveButton =
        byId("configSaveButton");

    const factoryButton =
        byId("configFactoryButton");

    const positionLock =
        byId("configPositionLock");


    if (
        !saveButton ||
        !factoryButton ||
        !positionLock
    ) {
        return;
    }


    if (!configTradingCanEdit) {

        positionLock.classList.remove(
            "hidden");


        const title =
            positionLock.querySelector(
                "strong");

        const text =
            positionLock.querySelector(
                "span");


        if (configPositionOpen) {

            positionLock.dataset.lock =
                "position";

            if (title)
                title.textContent =
                    "Position offen";

            if (text)
                text.textContent =
                    "Die Config kann erst geändert werden, wenn die aktuelle Position vollständig geschlossen und Trading pausiert ist.";
        }

        else {

            positionLock.dataset.lock =
                "trading";

            if (title)
                title.textContent =
                    "Trading aktiv";

            if (text)
                text.textContent =
                    "Trading zuerst ausschalten. Danach kann die persönliche Config geändert oder auf Werkseinstellungen gesetzt werden.";
        }


        /*
         * M5.1G2:
         * Der Speichern-Button bleibt anklickbar,
         * damit die zentrale Sperrwarnung sichtbar
         * ausgelöst werden kann.
         *
         * savePersonalConfig() bricht weiterhin
         * VOR jedem API-Aufruf ab.
         */
        saveButton.disabled =
            false;

        saveButton.classList.add(
            "config-save-locked");

        /*
         * Kein natives/ARIA disabled:
         * der Button bleibt als Warn-Auslöser interaktiv.
         */
        saveButton.removeAttribute(
            "aria-disabled");

        saveButton.dataset.configLocked =
            "true";


        factoryButton.disabled =
            true;


        saveButton.textContent =
            productConfigDirty.size === 0
                ? "Speichern"
                : `Speichern (${productConfigDirty.size})`;

        return;
    }


    positionLock.classList.add(
        "hidden");

    delete positionLock.dataset.lock;


    factoryButton.disabled =
        false;


    saveButton.classList.remove(
        "config-save-locked");

    saveButton.removeAttribute(
        "aria-disabled");

    delete saveButton.dataset.configLocked;


    saveButton.disabled =
        productConfigDirty.size === 0;


    const liveBudgetError =
        validateLiveBudgetConfiguration();


    if (liveBudgetError) {

        saveButton.disabled =
            true;

        saveButton.dataset.liveBudgetBlocked =
            "true";

        setConfigActionMessage(
            liveBudgetError.message,
            "error");
    }
    else {

        if (
            saveButton.dataset.liveBudgetBlocked ===
            "true"
        ) {

            setConfigActionMessage(
                "");
        }

        delete saveButton.dataset.liveBudgetBlocked;
    }


    saveButton.textContent =
        productConfigDirty.size === 0
            ? "Speichern"
            : `Speichern (${productConfigDirty.size})`;
}



function createConfigSelect(
    name,
    value,
    options) {

    const select =
        document.createElement(
            "select");

    select.className =
        "config-edit-control";

    select.dataset.configEditable =
        "true";

    select.dataset.configName =
        name;

    select.dataset.configKind =
        "string";


    for (const optionValue of options) {

        const option =
            document.createElement(
                "option");

        option.value =
            String(optionValue);

        option.textContent =
            String(optionValue);

        if (
            String(value) ===
            String(optionValue)
        ) {
            option.selected =
                true;
        }

        select.appendChild(
            option);
    }


    select.addEventListener(
        "change",
        updateConfigDirtyState);

    return select;
}


function createWinnerSelect(
    name,
    value) {

    const select =
        document.createElement(
            "select");

    select.className =
        "config-edit-control";

    select.dataset.configEditable =
        "true";

    select.dataset.configName =
        name;

    select.dataset.configKind =
        "winner";


    for (
        const [winnerValue, label]
        of OPTIMIZER_WINNERS
    ) {
        const option =
            document.createElement(
                "option");

        option.value =
            String(winnerValue);

        option.textContent =
            label;

        if (
            Number(value) ===
            Number(winnerValue)
        ) {
            option.selected =
                true;
        }

        select.appendChild(
            option);
    }


    select.addEventListener(
        "change",
        updateConfigDirtyState);

    return select;
}


function createBooleanSwitch(
    name,
    value) {

    const wrapper =
        document.createElement(
            "label");

    wrapper.className =
        "config-switch";


    const input =
        document.createElement(
            "input");

    input.type =
        "checkbox";

    input.checked =
        Boolean(value);

    input.dataset.configEditable =
        "true";

    input.dataset.configName =
        name;

    input.dataset.configKind =
        "bool";


    const track =
        document.createElement(
            "span");

    track.className =
        "config-switch-track";


    const text =
        document.createElement(
            "span");

    text.className =
        "config-switch-text";

    const updateText =
        () => {
            text.textContent =
                input.checked
                    ? "AN"
                    : "AUS";
        };

    updateText();


    input.addEventListener(
        "change",
        () => {
            updateText();
            updateConfigDirtyState();
        });


    wrapper.appendChild(
        input);

    wrapper.appendChild(
        track);

    wrapper.appendChild(
        text);

    return wrapper;
}



// ==========================================================
// M4.7J · REBUY DISTANCE GRID
// ==========================================================
//
// ReBuyDistances bleibt technisch EIN decimal[].
//
// Die einzelnen Array-Werte werden ausschließlich für eine
// sicherere Bedienung als getrennte Zahlenfelder dargestellt.
// ==========================================================


// ==========================================================
// M4.7K1 · MAXBUYCOUNT REBUY LEVELS
// ==========================================================
//
// MaxBuyCount enthält den ersten BUY bereits.
//
// MaxBuyCount = 3 bedeutet:
//
// BUY
// ReBUY 1
// ReBUY 2
//
// Weitere vorhandene ReBUY-Werte bleiben vollständig
// gespeichert, werden aber optisch deaktiviert.
// ==========================================================

function currentMaxBuyCount() {

    const input =
        document.querySelector(
            '[data-config-name="MaxBuyCount"]'
        );


    if (input) {

        try {

            const value =
                configInputValue(
                    input);

            if (
                Number.isFinite(value)
                &&
                value >= 1
            ) {
                return Math.trunc(
                    value);
            }
        }
        catch {
        }
    }


    const field =
        productConfigFields.get(
            "MaxBuyCount");


    if (field) {

        const value =
            Number(
                configProperty(
                    field,
                    "Value",
                    "value")
            );


        if (
            Number.isFinite(value)
            &&
            value >= 1
        ) {
            return Math.trunc(
                value);
        }
    }


    return 1;
}


function applyReBuyLevelState(
    grid) {

    if (!grid)
        return;


    const activeCount =
        Math.max(
            0,
            currentMaxBuyCount() - 1
        );


    const items =
        Array.from(
            grid.querySelectorAll(
                ".config-rebuy-item"
            )
        );


    items.forEach(
        (item, index) => {

            const active =
                index < activeCount;


            /*
             * Alle kanonischen ReBUY-Stufen bleiben im Editor
             * vorhanden. MaxBuyCount steuert ausschließlich,
             * welche Stufen sichtbar sind.
             */
            item.hidden =
                !active;


            const input =
                item.querySelector(
                    "[data-rebuy-distance='true']"
                );


            if (input) {
                input.disabled =
                    false;
            }
        });


    const summary =
        grid.querySelector(
            ".config-rebuy-summary"
        );


    if (summary) {

        if (
            activeCount <=
            items.length
        ) {

            summary.textContent =
                activeCount === 1
                    ? "1 ReBUY-Stufe aktiv"
                    : `${activeCount} ReBUY-Stufen aktiv`;

            summary.classList.remove(
                "warning");
        }

        else {

            summary.textContent =
                `${activeCount} ReBUY-Stufen benötigt · ${items.length} vorhanden`;

            summary.classList.add(
                "warning");
        }
    }
}


function updateReBuyLevelStates() {

    document
        .querySelectorAll(
            ".config-rebuy-grid"
        )
        .forEach(
            applyReBuyLevelState);
}


/*
 * Delegierter Listener:
 * funktioniert unabhängig davon, wann der Config-Editor
 * neu gerendert wird.
 */
document.addEventListener(
    "input",
    event => {

        const target =
            event.target;


        if (
            target
            &&
            target.dataset
            &&
            target.dataset.configName ===
                "MaxBuyCount"
        ) {

            updateReBuyLevelStates();
        }
    });


function createReBuyDistanceGrid(
    name,
    value,
    definition) {

    const wrapper =
        document.createElement(
            "div");

    wrapper.className =
        "config-rebuy-grid";

    wrapper.dataset.configEditable =
        "true";

    wrapper.dataset.configName =
        name;

    wrapper.dataset.configKind =
        "array-fields";


    /*
     * Kanonische ReBUY-Reserve passend zu Config.cs.
     *
     * Bereits gespeicherte Werte haben immer Vorrang.
     * Fehlende Stufen werden nur für den Editor mit den
     * Config.cs-Defaults ergänzt, damit MaxBuyCount später
     * wieder erhöht werden kann, ohne in einen ungültigen
     * verkürzten Array-Zustand zu geraten.
     */
    const defaultValues =
        [
            10,
            20,
            40,
            80,
            150,
            300,
            600,
            900,
            1200
        ];


    const storedValues =
        Array.isArray(value)
            ? value
            : [];


    const values =
        defaultValues.map(
            (defaultValue, index) =>
                index < storedValues.length
                    ? storedValues[index]
                    : defaultValue
        );


    const summary =
        document.createElement(
            "div");

    summary.className =
        "config-rebuy-summary";

    wrapper.appendChild(
        summary);


    values.forEach(
        (distance, index) => {

            const item =
                document.createElement(
                    "label");

            item.className =
                "config-rebuy-item";

            item.dataset.rebuyIndex =
                String(index);


            const labelRow =
                document.createElement(
                    "span");

            labelRow.className =
                "config-rebuy-item-label";


            const title =
                document.createElement(
                    "strong");

            title.textContent =
                `ReBUY ${index + 1}`;


            const unit =
                document.createElement(
                    "small");

            unit.textContent =
                definition.unit
                ||
                "USDC";


            labelRow.appendChild(
                title);

            labelRow.appendChild(
                unit);


            const input =
                document.createElement(
                    "input");

            input.type =
                "number";

            input.inputMode =
                "decimal";

            input.step =
                "any";

            input.min =
                "0";

            input.value =
                String(distance);

            input.className =
                "config-rebuy-input";

            input.dataset.rebuyDistance =
                "true";

            input.setAttribute(
                "aria-label",
                `ReBUY ${index + 1} Abstand`);


            input.addEventListener(
                "input",
                updateConfigDirtyState);


            item.appendChild(
                labelRow);

            item.appendChild(
                input);

            wrapper.appendChild(
                item);
        });


    if (values.length === 0) {

        const empty =
            document.createElement(
                "div");

        empty.className =
            "config-rebuy-empty";

        empty.textContent =
            "Keine ReBUY-Abstände vorhanden.";

        wrapper.appendChild(
            empty);
    }


    applyReBuyLevelState(
        wrapper);


    return wrapper;
}


// ==========================================================
// M15A · BETRIEBSMODUS · TEST | AUS | LIVE
// ==========================================================

function createTradingModeControl(
    name,
    value) {

    const validModes = [
        "TEST",
        "OFF",
        "LIVE"
    ];


    const requested =
        String(
            value ?? "")
            .trim()
            .toUpperCase();


    const currentMode =
        validModes.includes(
            requested)
            ? requested
            : "OFF";


    const wrapper =
        document.createElement(
            "div");

    wrapper.className =
        "config-trading-mode";

    wrapper.dataset.mode =
        currentMode;


    /*
     * Dieses versteckte Input bleibt das authoritative
     * Config-Feld für Dirty-State und Save-Payload.
     */
    const input =
        document.createElement(
            "input");

    input.type =
        "hidden";

    input.value =
        currentMode;

    input.dataset.configEditable =
        "true";

    input.dataset.configName =
        name;

    input.dataset.configKind =
        "string";


    wrapper.appendChild(
        input);


    const buttons = [
        ["TEST", "TEST"],
        ["OFF", "AUS"],
        ["LIVE", "LIVE"]
    ];


    const updateButtons =
        () => {

            wrapper.dataset.mode =
                input.value;


            wrapper
                .querySelectorAll(
                    "[data-trading-mode]")
                .forEach(
                    button => {

                        const active =
                            button.dataset.tradingMode ===
                            input.value;


                        button.classList.toggle(
                            "is-active",
                            active);


                        button.setAttribute(
                            "aria-pressed",
                            active
                                ? "true"
                                : "false");
                    });
        };


    for (
        const [mode, label]
        of buttons
    ) {

        const button =
            document.createElement(
                "button");

        button.type =
            "button";

        button.className =
            "config-trading-mode-button";

        button.dataset.tradingMode =
            mode;

        button.textContent =
            label;

        button.setAttribute(
            "aria-pressed",
            "false");


        button.addEventListener(
            "click",
            () => {

                if (input.value === mode)
                    return;


                input.value =
                    mode;


                updateButtons();


                updateConfigDirtyState();

                if (mode === "LIVE") {

                    const liveBudgetError =
                        validateLiveBudgetConfiguration();


                    if (liveBudgetError) {

                        showConfigCenterError(
                            "LIVE-Budget anpassen",
                            liveBudgetError.message,
                            9000);
                    }
                }
            });


        wrapper.appendChild(
            button);
    }


    updateButtons();


    return wrapper;
}



function createConfigInput(
    name,
    value,
    definition,
    field) {

    if (name === "TradingMode") {

        return createTradingModeControl(
            name,
            value);
    }


    if (definition.array) {

        return createReBuyDistanceGrid(
            name,
            value,
            definition);
    }


    if (typeof value === "boolean") {
        return createBooleanSwitch(
            name,
            value);
    }


    if (definition.winner) {
        return createWinnerSelect(
            name,
            value);
    }


    if (name === "Rule") {

        let options =
            configProperty(
                field,
                "Options",
                "options");

        if (
            !Array.isArray(options) ||
            options.length === 0
        ) {
            options = [
                "ValleyPeak",
                "TrendPullback"
            ];
        }

        return createConfigSelect(
            name,
            value,
            options);
    }


    if (typeof value === "number") {

        const input =
            document.createElement(
                "input");

        input.type =
            "number";

        input.inputMode =
            definition.integer
                ? "numeric"
                : "decimal";

        input.step =
            definition.integer
                ? "1"
                : "any";

        input.value =
            String(value);

        input.className =
            "config-edit-control";

        input.dataset.configEditable =
            "true";

        input.dataset.configName =
            name;

        input.dataset.configKind =
            "number";

        input.dataset.integer =
            definition.integer
                ? "true"
                : "false";


        const min =
            configProperty(
                field,
                "Min",
                "min");

        const max =
            configProperty(
                field,
                "Max",
                "max");


        if (
            min !== null &&
            min !== undefined
        ) {
            input.min =
                String(min);
        }

        if (
            max !== null &&
            max !== undefined
        ) {
            input.max =
                String(max);
        }


        input.addEventListener(
            "input",
            updateConfigDirtyState);

        return input;
    }


    const input =
        document.createElement(
            "input");

    input.type =
        "text";

    input.value =
        value == null
            ? ""
            : String(value);

    input.className =
        "config-edit-control";

    input.dataset.configEditable =
        "true";

    input.dataset.configName =
        name;

    input.dataset.configKind =
        "string";

    input.addEventListener(
        "input",
        updateConfigDirtyState);

    return input;
}


function renderConfigFields(fields) {

    const root =
        byId("configGroups");

    root.replaceChildren();

    productConfigFields =
        new Map();

    productConfigDirty =
        new Set();


    const allFields =
        Array.isArray(fields)
            ? fields
            : [];


    const visibleFields =
        allFields.filter(
            field => {

                const name =
                    String(
                        configProperty(
                            field,
                            "Name",
                            "name")
                        || ""
                    );

                if (
                    !Object.prototype
                        .hasOwnProperty.call(
                            PRODUCT_CONFIG_FIELDS,
                            name)
                ) {
                    return false;
                }

                productConfigFields.set(
                    name,
                    field);

                return true;
            });


    if (visibleFields.length === 0) {

        const empty =
            document.createElement(
                "div");

        empty.className =
            "config-loading";

        empty.textContent =
            "Keine persönlichen Einstellungen verfügbar.";

        root.appendChild(
            empty);

        updateConfigDirtyState();

        return;
    }


    const grouped =
        new Map();


    for (const field of visibleFields) {

        const name =
            String(
                configProperty(
                    field,
                    "Name",
                    "name")
                || ""
            );

        const definition =
            PRODUCT_CONFIG_FIELDS[
                name];

        if (!definition)
            continue;


        const displayGroup =
            productConfigDisplayGroup(
                name,
                definition);


        if (!grouped.has(
                displayGroup))
        {
            grouped.set(
                displayGroup,
                []);
        }


        grouped
            .get(displayGroup)
            .push({
                field,
                name,
                definition
            });
    }


    buildProductConfigCategoryOverview(
        root,
        grouped);


    queueMicrotask(
        showProductConfigOverview);


    for (
        const groupName
        of PRODUCT_CONFIG_GROUP_ORDER
    ) {

        const rows =
            grouped.get(
                groupName);

        if (
            !rows ||
            rows.length === 0
        ) {
            continue;
        }


        rows.sort(
            (a, b) => {

                const aOrder =
                    productConfigFieldOrderIndex(
                        groupName,
                        a.name);

                const bOrder =
                    productConfigFieldOrderIndex(
                        groupName,
                        b.name);

                return aOrder - bOrder;
            });


        const section =
            document.createElement(
                "section");

        section.className =
            "config-group hidden";

        section.dataset.configGroup =
            groupName;


        const title =
            document.createElement(
                "div");

        title.className =
            "config-group-title";

        title.textContent =
            groupName;

        section.appendChild(
            title);


        for (const row of rows) {

            const {
                field,
                name,
                definition
            } = row;

            /*
             * SHOCK GUARD UP V1
             * Die Sperrzeit wird bewusst innerhalb derselben
             * Kachel wie der AN/AUS-Schalter dargestellt.
             */
            if (name === "ShockGuardUpBlockHours")
                continue;


            const value =
                configProperty(
                    field,
                    "Value",
                    "value");


            const card =
                document.createElement(
                    "article");

            card.className =
                "config-field";


            const head =
                document.createElement(
                    "div");

            head.className =
                "config-field-head";


            const fieldTitle =
                document.createElement(
                    "div");

            fieldTitle.className =
                "config-field-title";


            const strong =
                document.createElement(
                    "strong");

            strong.textContent =
                definition.label;

            
fieldTitle.appendChild(
                strong);


            const infoButton =
                document.createElement(
                    "button");

            infoButton.type =
                "button";

            infoButton.className =
                "config-info-button";

            infoButton.textContent =
                "i";

            infoButton.setAttribute(
                "aria-label",
                `Information zu ${definition.label}`);

            infoButton.setAttribute(
                "title",
                `Information zu ${definition.label}`);


            infoButton.addEventListener(
                "click",
                event => {

                    event.preventDefault();
                    event.stopPropagation();

                    openProductConfigHelp(
                        name,
                        field,
                        definition);
                });


            fieldTitle.appendChild(
                infoButton);


            head.appendChild(
                fieldTitle);


            if (
                definition.access === "edit"
            ) {

                const editor =
                    createConfigInput(
                        name,
                        value,
                        definition,
                        field);

                const editorWrap =
                    document.createElement(
                        "div");

                editorWrap.className =
                    "config-editor-wrap";

                editorWrap.appendChild(
                    editor);


                if (definition.unit) {

                    const unit =
                        document.createElement(
                            "span");

                    unit.className =
                        "config-edit-unit";

                    unit.textContent =
                        definition.unit;

                    editorWrap.appendChild(
                        unit);
                }


                head.appendChild(
                    editorWrap);
            }
            else {

                const valueBox =
                    document.createElement(
                        "div");

                valueBox.className =
                    "config-field-value";

                valueBox.textContent =
                    formatProductConfigValue(
                        name,
                        value,
                        definition);

                head.appendChild(
                    valueBox);
            }


            card.appendChild(
                head);


            if (name === "ShockGuardUpEnabled") {

                const hoursField =
                    productConfigFields.get(
                        "ShockGuardUpBlockHours");

                if (hoursField) {

                    const hoursDefinition =
                        PRODUCT_CONFIG_FIELDS[
                            "ShockGuardUpBlockHours"];

                    const hoursValue =
                        configProperty(
                            hoursField,
                            "Value",
                            "value");

                    const combinedRow =
                        document.createElement(
                            "div");

                    combinedRow.className =
                        "shock-guard-up-hours-row";


                    const combinedLabel =
                        document.createElement(
                            "span");

                    combinedLabel.className =
                        "shock-guard-up-hours-label";

                    combinedLabel.textContent =
                        "Sperrzeit";


                    const combinedEditor =
                        document.createElement(
                            "div");

                    combinedEditor.className =
                        "shock-guard-up-hours-editor";


                    const hoursInput =
                        createConfigInput(
                            "ShockGuardUpBlockHours",
                            hoursValue,
                            hoursDefinition,
                            hoursField);

                    combinedEditor.appendChild(
                        hoursInput);


                    const hoursUnit =
                        document.createElement(
                            "span");

                    hoursUnit.className =
                        "config-edit-unit";

                    hoursUnit.textContent =
                        "Stunden";

                    combinedEditor.appendChild(
                        hoursUnit);


                    combinedRow.appendChild(
                        combinedLabel);

                    combinedRow.appendChild(
                        combinedEditor);

                    card.appendChild(
                        combinedRow);
                }
            }


            const description =
                productConfigDescription(
                    field,
                    definition);


            if (description) {

                const desc =
                    document.createElement(
                        "div");

                desc.className =
                    "config-field-description";

                desc.textContent =
                    description;

                card.appendChild(
                    desc);
            }


            const availability =
                productConfigStatus(name, definition, value);


            if (availability) {
                const availabilityBadge =
                    document.createElement(
                        "div");

                availabilityBadge.className =
                    `config-product-status ${availability.key}`;

                availabilityBadge.textContent =
                    availability.label;

                card.appendChild(
                    availabilityBadge);
            }


            if (
                name === "AutoOptimizerEnabled"
            ) {

                const action =
                    document.createElement(
                        "div");

                action.className =
                    "manual-optimizer-action";


                const runButton =
                    document.createElement(
                        "button");

                runButton.type =
                    "button";

                runButton.className =
                    "manual-optimizer-run-button";

                runButton.textContent =
                    "Jetzt starten";


                const enabledInput =
                    card.querySelector(
                        '[data-config-name="AutoOptimizerEnabled"]');


                if (enabledInput) {

                    enabledInput.addEventListener(
                        "change",
                        updateManualOptimizerButtons);
                }


                runButton.addEventListener(
                    "click",
                    async event => {

                        event.preventDefault();
                        event.stopPropagation();

                        runButton.disabled =
                            true;

                        runButton.textContent =
                            "Läuft …";

                        try {

                            const result =
                                await requestManualOptimizerRun();

                            if (
                                result.code === "optimizer_queued"
                                &&
                                result.data?.ok === true
                            ) {

                                /*
                                 * Backend hat den Auftrag als queued
                                 * bestätigt. Der normale 10-Sekunden-
                                 * Refresh übernimmt den Folgezustand.
                                 */
                                optimizerRuntimeStatus = {
                                    State: "Pending"
                                };

                                optimizerRuntimeLastFetch =
                                    Date.now();

                                updateManualOptimizerButtons();

                                return;
                            }

                            throw new Error(
                                "Optimizer konnte nicht gestartet werden.");
                        }
                        catch (error) {

                            const code =
                                String(
                                    error?.optimizerCode
                                    ??
                                    "")
                                    .trim()
                                    .toLowerCase();

                            if (
                                code === "optimizer_position_not_flat"
                            ) {

                                window.alert(
                                    "Optimizer nicht möglich. Eine Position ist noch geöffnet. Der Optimizer kann erst bei vollständig geschlossener Position gestartet werden.");
                            }
                            else if (
                                code === "optimizer_disabled"
                            ) {

                                window.alert(
                                    "Der Auto-Optimizer ist deaktiviert.");
                            }
                            else if (
                                code === "optimizer_already_running"
                            ) {

                                optimizerRuntimeStatus = {
                                    State: "Running"
                                };
                            }
                            else if (
                                code === "optimizer_already_queued"
                            ) {

                                optimizerRuntimeStatus = {
                                    State: "Pending"
                                };
                            }
                            else if (
                                code === "optimizer_not_configured"
                            ) {

                                window.alert(
                                    "Der manuelle Optimizer ist derzeit nicht verfügbar.");
                            }
                            else {

                                window.alert(
                                    error?.message
                                    ||
                                    "Optimizer konnte nicht gestartet werden.");
                            }

                            await loadOptimizerRuntimeStatus(
                                true);
                        }
                        finally {

                            updateManualOptimizerButtons();
                        }
                    });


                action.appendChild(
                    runButton);

                card.appendChild(
                    action);

                updateManualOptimizerButtons();
            }


            section.appendChild(
                card);
        }


        root.appendChild(
            section);
    }


    setConfigActionMessage("");

    updateConfigDirtyState();
}


function collectConfigChanges() {

    const changes =
        {};

    let dangerous =
        false;


    for (
        const name
        of productConfigDirty
    ) {

        const input =
            document.querySelector(
                `[data-config-name="${name}"]`);

        if (!input)
            continue;


        changes[name] =
            configInputValue(
                input);


        const field =
            productConfigFields.get(
                name);

        dangerous =
            dangerous ||
            Boolean(
                configProperty(
                    field,
                    "Dangerous",
                    "dangerous"));
    }


    return {
        changes,
        dangerous
    };
}


async function savePersonalConfig() {

    if (
        configPositionOpen
        ||
        !configTradingCanEdit
    ) {

        showConfigLockedCenterWarning();


        setConfigActionMessage(
            configPositionOpen
                ? "Speichern nicht möglich: Die aktuelle Position ist noch offen. Nach dem SELL und der anschließenden Pause kann die Config gespeichert werden."
                : "Speichern nicht möglich: Trading zuerst pausieren.",
            "error");

        return;
    }


    const liveBudgetError =
        validateLiveBudgetConfiguration();


    if (liveBudgetError) {

        resetConfigDangerousSaveConfirmation();

        setConfigActionMessage(
            liveBudgetError.message,
            "error");

        showConfigCenterError(
            "LIVE-Budget anpassen",
            liveBudgetError.message,
            9000);

        return;
    }


    if (
        productConfigDirty.size === 0
    ) {

        resetConfigDangerousSaveConfirmation();


        const message =
            "Es wurden keine geänderten Einstellungen erkannt.";


        setConfigActionMessage(
            message,
            "warning");


        showConfigCenterWarning(
            "Keine Änderungen",
            message);


        return;
    }


    let payload;

    try {

        payload =
            collectConfigChanges();
    }
    catch (error) {

        const message =
            error.message
            ||
            "Ungültiger Einstellungswert.";


        resetConfigDangerousSaveConfirmation();


        setConfigActionMessage(
            message,
            "error");


        showConfigCenterError(
            "Speichern nicht möglich",
            message);


        return;
    }


    const optimizerScoreError =
        validateOptimizerScoresBeforeSave();


    if (optimizerScoreError) {

        resetConfigDangerousSaveConfirmation();


        setConfigActionMessage(
            optimizerScoreError,
            "error");


        showConfigCenterError(
            "Optimizer-Werte ungültig",
            optimizerScoreError);


        return;
    }


    const changedCount =
        Object.keys(
            payload.changes)
        .length;


    let confirmDangerous =
        false;


    if (payload.dangerous) {

        /*
         * Product-App:
         * keine browsernative Sicherheitsabfrage.
         *
         * Erster Tipp:
         * gelbe Sicherheitsblase.
         *
         * Zweiter Tipp innerhalb von 8 Sekunden:
         * ConfirmDangerous=true.
         */
        confirmDangerous =
            confirmDangerousConfigSave(
                payload.changes);


        if (!confirmDangerous)
            return;
    }

    else {

        resetConfigDangerousSaveConfirmation();
    }


    const button =
        byId(
            "configSaveButton");


    button.disabled =
        true;

    button.textContent =
        "Speichert …";


    setConfigActionMessage(
        changedCount === 1
            ? "1 Änderung wird gespeichert …"
            : `${changedCount} Änderungen werden gespeichert …`
    );


    try {

        const result =
            await api(
                "/api/v1/btctrader/config",
                {
                    method:
                        "POST",

                    body:
                        JSON.stringify({

                            Fields:
                                payload.changes,

                            ConfirmDangerous:
                                confirmDangerous
                        })
                });


        /*
         * Config zuerst vollständig neu laden.
         *
         * Wichtig:
         * renderConfigFields() leert während des Reloads
         * bewusst die alte Statusmeldung.
         *
         * Deshalb setzen wir die Erfolgsmeldung ERST
         * NACH dem Reload erneut.
         */
        await openPersonalConfig();


        const successMessage =
            result.Message
            ||
            result.message
            ||
            (
                changedCount === 1
                    ? "1 Änderung wurde erfolgreich gespeichert."
                    : `${changedCount} Änderungen wurden erfolgreich gespeichert.`
            );


        setConfigActionMessage(
            successMessage,
            "success");


        resetConfigDangerousSaveConfirmation();


        showConfigCenterSuccess(
            "Gespeichert",
            successMessage);


        if (
            typeof refreshTraderViews ===
                "function"
        ) {

            await refreshTraderViews();
        }
    }
    catch (error) {

        const message =
            error.message
            ||
            "Config konnte nicht gespeichert werden.";


        resetConfigDangerousSaveConfirmation();


        setConfigActionMessage(
            message,
            "error");


        showConfigCenterError(
            "Speichern fehlgeschlagen",
            message);
    }
    finally {

        /*
         * Dirty-State nach jedem Speichervorgang
         * frisch aus den aktuell dargestellten Feldern
         * berechnen.
         *
         * Dadurch funktionieren auch der zweite,
         * dritte usw. Speichervorgang zuverlässig.
         */
        updateConfigDirtyState();


        button.textContent =
            productConfigDirty.size === 0
                ? "Speichern"
                : `Speichern (${productConfigDirty.size})`;


        if (!configTradingCanEdit) {

            /*
             * Gesperrt, aber absichtlich anklickbar:
             * Klick zeigt ausschließlich die Warnblase.
             */
            button.disabled =
                false;

            button.classList.add(
                "config-save-locked");

            button.setAttribute(
                "aria-disabled",
                "true");
        }

        else {

            button.classList.remove(
                "config-save-locked");

            button.removeAttribute(
                "aria-disabled");


            button.disabled =
                productConfigDirty.size === 0;
        }
    }
}



// ==========================================================
// M4.7H · FACTORY RESET FEEDBACK
// ==========================================================

let configFactoryArmed =
    false;

let configFactoryArmTimer =
    null;


function resetConfigFactoryArm() {

    configFactoryArmed =
        false;


    if (configFactoryArmTimer) {

        clearTimeout(
            configFactoryArmTimer);

        configFactoryArmTimer =
            null;
    }


    const button =
        byId(
            "configFactoryButton");


    if (!button)
        return;


    button.classList.remove(
        "armed");


    button.textContent =
        "Werkseinstellungen";


    updateConfigDirtyState();
}


async function resetPersonalConfigToFactory() {

    if (!configTradingCanEdit) {

        showConfigLockedCenterWarning();


        setConfigActionMessage(
            configPositionOpen
                ? "Werkseinstellungen nicht möglich: Die aktuelle Position ist noch offen."
                : "Werkseinstellungen nicht möglich: Trading zuerst pausieren.",
            "error");

        return;
    }


    const factoryButton =
        byId(
            "configFactoryButton");

    const saveButton =
        byId(
            "configSaveButton");


    /*
     * Erster Klick:
     * nur sichtbar scharf schalten.
     */
    if (!configFactoryArmed) {

        configFactoryArmed =
            true;


        factoryButton.classList.add(
            "armed");


        factoryButton.textContent =
            "JA · WERKSEINSTELLUNGEN LADEN";


        setConfigActionMessage(
            "Sicherheitsabfrage: Noch einmal auf den Button tippen, um die persönliche Config wirklich auf Werkseinstellungen zurückzusetzen.",
            "warning");


        configFactoryArmTimer =
            window.setTimeout(
                () => {

                    resetConfigFactoryArm();


                    setConfigActionMessage(
                        "");
                },
                8000);


        return;
    }


    /*
     * Zweiter Klick:
     * tatsächlicher Reset.
     */
    if (configFactoryArmTimer) {

        clearTimeout(
            configFactoryArmTimer);

        configFactoryArmTimer =
            null;
    }


    configFactoryArmed =
        false;


    factoryButton.classList.remove(
        "armed");


    factoryButton.disabled =
        true;

    saveButton.disabled =
        true;


    factoryButton.textContent =
        "Werkseinstellungen werden geladen …";


    setConfigActionMessage(
        "Persönliche Config wird auf Werkseinstellungen zurückgesetzt …"
    );


    try {

        const result =
            await api(
                "/api/v1/btctrader/config/reset",
                {
                    method:
                        "POST",

                    body:
                        "{}"
                });


        /*
         * Neue Config zuerst laden.
         * Erfolgsmeldung danach setzen, damit sie
         * nicht durch renderConfigFields() verschwindet.
         */
        await openPersonalConfig();


        setConfigActionMessage(
            result.Message
            ||
            result.message
            ||
            "Werkseinstellungen wurden erfolgreich geladen.",
            "success");


        if (
            typeof refreshTraderViews ===
                "function"
        ) {

            await refreshTraderViews();
        }
    }
    catch (error) {

        setConfigActionMessage(
            error.message
            ||
            "Werkseinstellungen konnten nicht geladen werden.",
            "error");
    }
    finally {

        factoryButton.classList.remove(
            "armed");


        factoryButton.textContent =
            "Werkseinstellungen";


        updateConfigDirtyState();
    }
}


async function refreshConfigPositionLock() {

    try {

        const control =
            await api(
                "/api/v1/btctrader/trading-control");


        renderTradingControl(
            control,
            true);
    }
    catch {

        configTradingCanEdit =
            false;

        updateConfigDirtyState();
    }
}



async function openPersonalConfig() {
    showConfigView();

    byId("configLoading")
        .classList.remove("hidden");

    byId("configError")
        .classList.add("hidden");

    byId("configGroups")
        .replaceChildren();

    byId("configNameValue").textContent =
        "Config wird geladen …";

    byId("configVersionValue").textContent =
        "–";


    try {
        const data =
            await api(
                "/api/v1/btctrader/config");


        if (
            !data ||
            !data.connected
        ) {
            throw new Error(
                "Persönliche Config ist momentan nicht verfügbar.");
        }


        byId("configNameValue").textContent =
            data.configName ||
            "BTC Trader Pro";


        byId("configVersionValue").textContent =
            data.configVersion === null ||
            data.configVersion === undefined
                ? "Read only"
                : `Config ${data.configVersion}`;


        renderConfigFields(
            data.fields);


        renderOptimizerSummaryFromConfig(
            data);

        optimizerSummaryLastFetch =
            Date.now();


        await refreshConfigPositionLock();


        /*
         * Der Speichern-Button ist bei gesperrter Config
         * absichtlich deaktiviert und kann deshalb nicht
         * zuverlässig selbst als Klick-Auslöser dienen.
         *
         * Deshalb erscheint die Sperrwarnung beim Öffnen
         * der persönlichen Einstellungen automatisch.
         */
        if (!configTradingCanEdit) {

            showConfigLockedCenterWarning();
        }


        byId("configLoading")
            .classList.add("hidden");
    }
    catch (error) {
        byId("configLoading")
            .classList.add("hidden");

        const box =
            byId("configError");

        box.textContent =
            error.message ||
            "Persönliche Einstellungen konnten nicht geladen werden.";

        box.classList.remove(
            "hidden");
    }
}


// ==========================================================
// M4.7B · TESTWALLET RESET UI
// ==========================================================

// ==========================================================
// M4.7B1 · TESTWALLET PANEL
// ==========================================================

let walletResetPanelBusy =
    false;


let traderResetArmed =
    false;


let traderResetArmTimer =
    null;


function resetTraderResetArm() {

    traderResetArmed =
        false;


    if (traderResetArmTimer) {

        clearTimeout(
            traderResetArmTimer);


        traderResetArmTimer =
            null;
    }


    const button =
        byId(
            "walletResetConfirmButton");


    if (
        button
        &&
        !walletResetPanelBusy
    ) {

        button.textContent =
            "TestWallet zurücksetzen";


        button.classList.remove(
            "armed");
    }
}


function closeTestWalletResetPanel() {

    resetTraderResetArm();


    const panel =
        byId(
            "drawerWalletResetPanel");


    const button =
        byId(
            "drawerWalletButton");


    if (panel)
        panel.classList.add(
            "hidden");


    if (button)
        button.classList.remove(
            "wallet-open");
}


async function openTestWalletResetPanel() {

    closeLiveDataResetPanel();

    const panel =
        byId(
            "drawerWalletResetPanel");


    const menuButton =
        byId(
            "drawerWalletButton");


    const state =
        byId(
            "walletResetState");


    const confirmButton =
        byId(
            "walletResetConfirmButton");


    if (
        !panel
        ||
        !state
        ||
        !confirmButton
    ) {
        return;
    }


    if (
        !panel.classList.contains(
            "hidden")
    ) {

        closeTestWalletResetPanel();

        return;
    }


    resetTraderResetArm();


    panel.classList.remove(
        "hidden");


    if (menuButton)
        menuButton.classList.add(
            "wallet-open");


    state.textContent =
        "Bereit · TestWallet-Reset ist möglich.";


    state.className =
        "ready";


    confirmButton.disabled =
        false;
}


async function performTestWalletReset() {

    if (walletResetPanelBusy)
        return;


    const button =
        byId(
            "walletResetConfirmButton");


    const state =
        byId(
            "walletResetState");


    if (
        !button
        ||
        button.disabled
    ) {
        return;
    }


    /*
     * Erster Klick:
     * Löschung nur scharf schalten.
     */
    if (!traderResetArmed) {

        traderResetArmed =
            true;


        button.textContent =
            "JA · ALLE TRADING-DATEN LÖSCHEN";


        button.classList.add(
            "armed");


        if (state) {

            state.textContent =
                "Sicherheitsabfrage · Noch einmal tippen, um wirklich alles zu löschen.";


            state.className =
                "blocked";
        }


        traderResetArmTimer =
            window.setTimeout(
                () => {

                    resetTraderResetArm();


                    if (state) {

                        state.textContent =
                            "Bereit · TestWallet-Reset ist möglich.";


                        state.className =
                            "ready";
                    }
                },
                8000);


        return;
    }


    /*
     * Zweiter Klick:
     * endgültiger Full Reset.
     */
    walletResetPanelBusy =
        true;


    if (traderResetArmTimer) {

        clearTimeout(
            traderResetArmTimer);


        traderResetArmTimer =
            null;
    }


    button.disabled =
        true;


    button.classList.remove(
        "armed");


    button.textContent =
        "Trading-Daten werden gelöscht …";


    if (state) {

        state.textContent =
            "Persönlicher Trader wird neu eingerichtet …";


        state.className =
            "";
    }


    try {

        const result =
            await api(
                "/api/v1/btctrader/trader/reset",
                {
                    method:
                        "POST",

                    body:
                        "{}"
                });


        closeTestWalletResetPanel();

        closeSettingsDrawer();


        showTradingControlToast(
            result.Message
            ||
            result.message
            ||
            "Trader wurde vollständig zurückgesetzt.",
            "success");


        await refreshTraderViews();
    }
    catch (error) {

        traderResetArmed =
            false;


        if (state) {

            state.textContent =
                error?.message
                ||
                "Trader konnte nicht vollständig zurückgesetzt werden.";


            state.className =
                "blocked";
        }
    }
    finally {

        walletResetPanelBusy =
            false;


        if (
            !byId(
                "drawerWalletResetPanel")
                ?.classList
                .contains(
                    "hidden")
        ) {

            button.disabled =
                false;


            resetTraderResetArm();
        }
    }
}


function showInfoFromDrawer() {
    closeSettingsDrawer();

    setMessage(
        `BTC Trader Pro · App ${nativeVersionName()} · BTC Trader Pro`);
}



// ==========================================================
// M4.5A4 · TRADING CONTROL UI
// ==========================================================

let tradingControlMode =
    null;

let tradingControlBusy =
    false;

let tradingControlToastTimer =
    null;

let configTradingCanEdit =
    false;


function controlProperty(
    data,
    pascalName,
    camelName) {

    if (
        data &&
        Object.prototype.hasOwnProperty.call(
            data,
            pascalName)
    ) {
        return data[pascalName];
    }

    if (
        data &&
        Object.prototype.hasOwnProperty.call(
            data,
            camelName)
    ) {
        return data[camelName];
    }

    return undefined;
}


function showTradingControlToast(
    text,
    type = "") {

    const box =
        byId("tradingControlToast");

    if (!box)
        return;


    if (tradingControlToastTimer) {
        clearTimeout(
            tradingControlToastTimer);
    }


    box.textContent =
        text;

    box.className =
        "trading-control-toast" +
        (
            type
                ? " " + type
                : ""
        );


    tradingControlToastTimer =
        window.setTimeout(
            () => {
                box.classList.add(
                    "hidden");
            },
            4200);
}


function renderTradingControl(
    data,
    allowTransitionToast = true) {

    const mode =
        String(
            controlProperty(
                data,
                "Mode",
                "mode")
            || ""
        );


    const hasPosition =
        Boolean(
            controlProperty(
                data,
                "HasPosition",
                "hasPosition"));


    const canEditConfig =
        Boolean(
            controlProperty(
                data,
                "CanEditConfig",
                "canEditConfig"));


    const previousMode =
        tradingControlMode;

    tradingControlMode =
        mode;


    configPositionOpen =
        hasPosition;

    configTradingCanEdit =
        canEditConfig;

    updateManualFirstBuyAvailability();
    updateManualSellAvailability();


    const bar =
        byId("tradingControlBar");

    const toggle =
        byId("tradingControlToggle");

    const label =
        byId("tradingControlLabel");

    const detail =
        byId("tradingControlDetail");


    if (
        bar &&
        toggle &&
        label &&
        detail
    ) {

        bar.dataset.mode =
            mode;


        if (mode === "ACTIVE") {

            toggle.checked =
                true;

            label.textContent =
                "Trading aktiv";

            detail.textContent =
                hasPosition
                    ? "Aktuelle Position wird aktiv betreut."
                    : "Neue Positionen sind erlaubt.";
        }

        else if (
            mode === "PAUSE_AFTER_SELL"
        ) {

            toggle.checked =
                false;

            label.textContent =
                "Pause nach SELL";

            detail.textContent =
                hasPosition
                    ? "Die aktuelle Position wird noch vollständig beendet."
                    : "Trading wird pausiert.";
        }

        else {

            toggle.checked =
                false;

            label.textContent =
                "Trading pausiert";

            detail.textContent =
                "Keine neuen Trading-Einstiege.";
        }


        const configuredTradingMode =
            String(
                document.documentElement.dataset.tradingMode ||
                "")
                .trim()
                .toUpperCase();

        toggle.disabled =
            tradingControlBusy ||
            configuredTradingMode === "OFF";
    }


    updateConfigDirtyState();

    updateManualFirstBuyAvailability();
    updateManualSellAvailability();


    if (
        allowTransitionToast
        &&
        previousMode === "PAUSE_AFTER_SELL"
        &&
        mode === "PAUSED"
    ) {

        showTradingControlToast(
            "Trading pausiert – Config kann jetzt geändert werden.",
            "success");
    }
}


async function loadTradingControl(
    allowTransitionToast = true) {

    const data =
        await api(
            "/api/v1/btctrader/trading-control");


    renderTradingControl(
        data,
        allowTransitionToast);


    const diagControlMode =
        String(
            controlProperty(
                data,
                "Mode",
                "mode")
            || "UNKNOWN")
            .trim()
            .toUpperCase();

    window.BtcTraderDiag?.changed?.(
        "LIVE",
        "trading-control",
        `TradingControl=${diagControlMode}`,
        diagControlMode === "ACTIVE"
            ? "ok"
            : diagControlMode === "PAUSE_AFTER_SELL"
                ? "warn"
                : "info");


    return data;
}


async function changeTradingControl() {

    if (tradingControlBusy)
        return;


    const toggle =
        byId("tradingControlToggle");

    if (!toggle)
        return;


    const startTrading =
        Boolean(
            toggle.checked);


    tradingControlBusy =
        true;

    toggle.disabled =
        true;


    try {

        const endpoint =
            startTrading
                ? "/api/v1/btctrader/trading-control/start"
                : "/api/v1/btctrader/trading-control/stop";


        const data =
            await api(
                endpoint,
                {
                    method: "POST",
                    body: "{}"
                });


        renderTradingControl(
            data,
            false);


        const mode =
            String(
                controlProperty(
                    data,
                    "Mode",
                    "mode")
                || ""
            );


        if (mode === "ACTIVE") {

            showTradingControlToast(
                "Trading aktiviert.",
                "success");
        }

        else if (
            mode === "PAUSE_AFTER_SELL"
        ) {

            showTradingControlToast(
                "Trading wird nach dem nächsten erfolgreichen SELL pausiert.",
                "warning");
        }

        else {

            showTradingControlToast(
                "Trading pausiert – Config kann jetzt geändert werden.",
                "success");
        }


        if (
            typeof refreshTraderViews ===
            "function"
        ) {
            await refreshTraderViews();
        }
    }
    catch (error) {

        showTradingControlToast(
            error.message ||
            "Trading-Status konnte nicht geändert werden.",
            "error");


        try {
            await loadTradingControl(
                false);
        }
        catch {
        }
    }
    finally {

        tradingControlBusy =
            false;


        const currentToggle =
            byId("tradingControlToggle");


        if (currentToggle) {
            const configuredTradingMode =
                String(
                    document.documentElement.dataset.tradingMode ||
                    "")
                    .trim()
                    .toUpperCase();

            currentToggle.disabled =
                configuredTradingMode === "OFF";
        }
    }
}


let loginRedirectPending = false;
function redirectToLogin() {
    token = "";
    localCsrfToken = "";
    localStorage.removeItem(TOKEN_KEY);
    if (!loginRedirectPending) {
        loginRedirectPending = true;
        window.location.replace("/login");
    }
}


// ==========================================================
// PRODUCT LICENSE STATUS UI V1
//
// Backend-Semantik:
// - Normaler zentraler Refresh: 6 Stunden
// - Retry bei Fehler: 15 Minuten
// - Signierter Offline-Cache: maximal 48 Stunden
//   seit VerifiedAtUtc
//
// WICHTIG:
// Diese 48 Stunden verlängern NICHT die eigentliche Lizenz.
// Sie sind ausschließlich eine Offline-/Control-Plane-Reserve.
// ==========================================================

const LICENSE_NORMAL_REFRESH_MS =
    6 * 60 * 60 * 1000;

const LICENSE_OFFLINE_GRACE_MS =
    48 * 60 * 60 * 1000;


let licenseStatusRefreshTimer =
    null;


function setLicenseNotice(
    severity,
    title,
    text) {

    const box =
        byId("licenseNotice");

    const titleElement =
        byId("licenseNoticeTitle");

    const textElement =
        byId("licenseNoticeText");


    if (
        !box
        ||
        !titleElement
        ||
        !textElement
    ) {
        return;
    }


    box.classList.remove(
        "license-notice-info",
        "license-notice-warning",
        "license-notice-danger");


    if (
        !severity
        ||
        !title
        ||
        !text
    ) {

        box.classList.add(
            "hidden");

        titleElement.textContent =
            "Lizenzhinweis";

        textElement.textContent =
            "–";

        return;
    }


    box.classList.remove(
        "hidden");


    box.classList.add(
        `license-notice-${severity}`);


    titleElement.textContent =
        title;


    textElement.textContent =
        text;
}


function formatLicenseDuration(
    milliseconds) {

    const totalMinutes =
        Math.max(
            0,
            Math.ceil(
                milliseconds / 60000));


    const hours =
        Math.floor(
            totalMinutes / 60);


    const minutes =
        totalMinutes % 60;


    if (hours >= 24) {

        const days =
            Math.floor(
                hours / 24);

        const restHours =
            hours % 24;


        return restHours > 0
            ? `${days} T. ${restHours} Std.`
            : `${days} Tage`;
    }


    if (hours > 0) {

        return minutes > 0
            ? `${hours} Std. ${minutes} Min.`
            : `${hours} Std.`;
    }


    return `${minutes} Min.`;
}


function scheduleLicenseStatusRefresh() {

    if (licenseStatusRefreshTimer) {

        clearTimeout(
            licenseStatusRefreshTimer);
    }


    licenseStatusRefreshTimer =
        setTimeout(
            () => {

                const dashboard =
                    byId("dashboardView");


                if (
                    dashboard
                    &&
                    !dashboard.classList.contains(
                        "hidden")
                ) {

                    loadLicenseStatus();
                }
            },
            5 * 60 * 1000);
}


async function loadLicenseStatus() {
    const statusValue = byId("licenseStatusValue");
    const validUntilValue = byId("licenseValidUntilValue");
    const remainingValue = byId("licenseRemainingValue");
    const sourceValue = byId("licenseVerifiedAtValue");
    const paymentsValue = byId("licenseGraceValue");
    if (!statusValue || !validUntilValue || !remainingValue) return;
    try {
        const data = await api("/trader-api/license/blockchain");
        if (!data?.ok || !data.license) throw new Error("LICENSE_STATUS_UNAVAILABLE");
        const license = data.license;
        statusValue.textContent = license.isLifetime ? "Lifetime" : (license.isValid ? "Aktiv" : "Keine aktive Lizenz");
        if (license.isLifetime) {
            validUntilValue.textContent = "Unbegrenzt";
            remainingValue.textContent = "Lifetime";
        } else if (license.validUntilUtc) {
            const until = new Date(license.validUntilUtc);
            validUntilValue.textContent = until.toLocaleString("de-DE", {day:"2-digit",month:"2-digit",year:"numeric",hour:"2-digit",minute:"2-digit"});
            remainingValue.textContent = formatLicenseDuration(Math.max(0, until.getTime() - Date.now()));
        } else {
            validUntilValue.textContent = "–";
            remainingValue.textContent = "–";
        }
        if (sourceValue) sourceValue.textContent = "Lokal geprüft · Direct USDC V2";
        if (paymentsValue) paymentsValue.textContent = String(license.processedPayments ?? 0);
        if (license.isValid && data.smartphoneSynchronizationRequired === true)
            setLicenseNotice("warning", "Smartphone-Synchronisierung erforderlich",
                "Bitte Handy-App zur Synchronisierung öffnen.\n\nLIVE-BUY und REBUY sind vorübergehend gesperrt.");
        else if (license.isValid || license.isLifetime) setLicenseNotice(null, null, null);
        else setLicenseNotice("warning", "Keine aktive Lizenz", "Für neue BUY/REBUY wird eine gültige Lizenz benötigt. SELL und Recovery bleiben möglich.");
    } catch {
        statusValue.textContent = "Nicht verfügbar";
        if (sourceValue) sourceValue.textContent = "Lokaler Lizenzstatus nicht verfügbar";
    } finally {
        scheduleLicenseStatusRefresh();
    }
}

let blockchainLicensePollTimer = null;
let blockchainLicenseReceiver = null;
let blockchainLicensePollBusy = false;
let licenseTariffsLoadedAt = 0;

let LICENSE_V2_USDC = null;
let LICENSE_V2_CHAIN_ID = null;

async function loadV2Tariffs() {
    const select = byId("licenseProductSelect");
    const previous = select?.value;
    licenseTariffsLoadedAt = 0;
    if (select) { select.disabled = true; select.replaceChildren(); }
    updateLicensePurchasePrice();
    const data = await api("/trader-api/license/v2-tariffs");
    if (data.chainId !== 8453 || !/^0x[0-9a-fA-F]{40}$/.test(data.token) ||
        !Array.isArray(data.products)) throw new Error("V2-Tarife nicht verfügbar.");
    LICENSE_V2_CHAIN_ID = data.chainId;
    LICENSE_V2_USDC = data.token;
    for (const tariff of data.products) {
        if (!tariff.active || !/^[1-9][0-9]{0,77}$/.test(tariff.amountAtomic) ||
            typeof tariff.amountDisplay !== "string") continue;
        const option = new Option(tariff.name + " · " + tariff.amountDisplay + " USDC", tariff.code);
        option.dataset.amountAtomic = tariff.amountAtomic;
        option.dataset.amountDisplay = tariff.amountDisplay;
        select?.add(option);
    }
    if (select) {
        if ([...select.options].some(x => x.value === previous)) select.value = previous;
        select.disabled = select.options.length === 0;
    }
    licenseTariffsLoadedAt = Date.now();
    updateLicensePurchasePrice();
}

function selectedLicenseProduct() {
    const select = byId("licenseProductSelect");
    if (!select) return null;

    const option =
        select.options[select.selectedIndex];

    if (!option) return null;

    return {
        code: option.value,
        amountAtomic: option.dataset.amountAtomic,
        amountDisplay: option.dataset.amountDisplay,
        name: option.textContent || option.value
    };
}

function licenseV2PaymentUri() {
    const product = selectedLicenseProduct();

    if (!product ||
        !blockchainLicenseReceiver ||
        !LICENSE_V2_USDC || !LICENSE_V2_CHAIN_ID ||
        Date.now() - licenseTariffsLoadedAt > 60000 ||
        !/^[1-9][0-9]{0,77}$/.test(product.amountAtomic))
        return null;

    const atomic = product.amountAtomic;

    return (
        "ethereum:" +
        LICENSE_V2_USDC +
        "@" +
        LICENSE_V2_CHAIN_ID +
        "/transfer?address=" +
        blockchainLicenseReceiver +
        "&uint256=" +
        atomic.toString()
    );
}

function updateLicenseChainBadge() {
    const tokenSelect =
        byId("licenseTokenSelect");

    const networkSelect =
        byId("licenseNetworkSelect");

    const badge =
        byId("licenseChainBadge");

    if (!tokenSelect ||
        !networkSelect ||
        !badge)
        return;

    const tokenOption =
        tokenSelect.options[
            tokenSelect.selectedIndex
        ];

    const networkOption =
        networkSelect.options[
            networkSelect.selectedIndex
        ];

    const token =
        tokenOption?.textContent?.trim()
        || tokenSelect.value
        || "–";

    const network =
        networkOption?.textContent?.trim()
        || networkSelect.value
        || "–";

    badge.textContent =
        `${token} · ${network}`;
}

function updateLicensePurchasePrice() {
    const product = selectedLicenseProduct();
    const price = byId("licensePurchasePrice");

    if (price) {
        price.textContent =
            product
                ? `${product.amountDisplay} USDC`
                : "–";
    }

    updateLicenseV2PaymentPayload();
}

function updateLicenseV2PaymentPayload() {
    const uri = licenseV2PaymentUri();
    const qr = byId("licensePurchaseQr");
    const wallet = byId("licenseWalletPayButton");

    if (!uri) {
        if (qr) qr.removeAttribute("src");
        if (wallet) wallet.href = "#";
        return;
    }

    if (qr) {
        qr.src =
            `/trader-api/license/qr?text=${
                encodeURIComponent(uri)
            }`;
    }

    if (wallet) {
        wallet.href = uri;
    }
}

function stopBlockchainLicensePolling() {
    if (blockchainLicensePollTimer) {
        clearInterval(blockchainLicensePollTimer);
        blockchainLicensePollTimer = null;
    }
}

async function copyLicenseActivationValue(elementId, button) {
    const element = byId(elementId);
    const value = element?.textContent?.trim();

    if (!value || value === "–")
        return;

    try {
        await navigator.clipboard.writeText(value);

        if (button) {
            const original = button.textContent;
            button.textContent = "Kopiert ✓";

            setTimeout(() => {
                button.textContent = original;
            }, 1800);
        }
    }
    catch {
        window.prompt("Wert kopieren:", value);
    }
}

function licenseActivationTransactionUri(data) {
    const hub =
        data?.receiverActivation?.hub;

    const callData =
        data?.receiverActivation?.createReceiverData;

    const chainId =
        Number(data?.paymentRoute?.chainId || 0);

    if (!hub || !callData || !chainId)
        return null;

    /*
     * EIP-681 Transaction Request:
     * Ziel = Hub
     * Chain = ausgewählter Zahlungsweg
     * Wert = 0
     * data = createReceiver(...)
     *
     * Keine Signatur und keine Transaktion durch BTC Trader.
     */
    return (
        "ethereum:" +
        hub +
        "@" +
        chainId +
        "?value=0&data=" +
        encodeURIComponent(callData)
    );
}


function updateLicenseActivationRoute(data) {
    const network =
        data?.paymentRoute?.network ||
        "–";

    const gasAsset =
        data?.paymentRoute?.gasAsset ||
        "–";

    const token =
        data?.paymentRoute?.token ||
        "–";

    const networkValue =
        byId("licenseActivationNetwork");

    const gasValue =
        byId("licenseActivationGasAsset");

    const intro =
        byId("licenseActivationIntro");

    const warning =
        byId("licenseActivationWarning");

    const qr =
        byId("licenseActivationQr");

    const qrHint =
        byId("licenseActivationQrHint");


    if (networkValue)
        networkValue.textContent = network;

    if (gasValue)
        gasValue.textContent = gasAsset;

    if (intro) {
        intro.textContent =
            `Der Zahlungsweg ${token} über ${network} muss einmalig aktiviert werden.`;
    }

    if (warning) {
        warning.textContent =
            `Für die einmalige Aktivierung wird ${gasAsset} für die ` +
            `Netzwerkgebühr auf ${network} benötigt. ` +
            `Die endgültige Gebühr zeigt deine Wallet vor dem Signieren an.`;
    }


    const uri =
        licenseActivationTransactionUri(data);

    if (qr) {
        if (uri) {
            qr.src =
                `/trader-api/license/qr?text=${
                    encodeURIComponent(uri)
                }`;

            qr.hidden = false;
        }
        else {
            qr.removeAttribute("src");
            qr.hidden = true;
        }
    }

    if (qrHint) {
        qrHint.textContent =
            uri
                ? `Aktivierungs-QR für ${network}. Vor dem Signieren Netzwerk, Contract und Gebühr prüfen.`
                : "Aktivierungs-QR momentan nicht verfügbar.";
    }
}


function showLicenseReceiverActivation(data) {
    stopBlockchainLicensePolling();

    blockchainLicenseReceiver = null;

    updateLicenseActivationRoute(data);

    const activation = byId("licenseReceiverActivation");
    const purchase = byId("licenseActivatedPurchase");
    const paymentRoute = byId("licensePaymentRoute");

    if (paymentRoute) paymentRoute.hidden = false;
    if (activation) activation.hidden = false;
    if (purchase) purchase.hidden = true;

    const receiver = byId("licenseActivationReceiver");
    const hub = byId("licenseActivationHub");
    const callData = byId("licenseActivationData");
    const fee = byId("licenseActivationFee");
    const status = byId("licenseActivationStatus");

    if (receiver)
        receiver.textContent = data?.receiver || "–";

    if (hub)
        hub.textContent =
            data?.receiverActivation?.hub || "–";

    if (callData)
        callData.textContent =
            data?.receiverActivation?.createReceiverData || "–";

    const feeBaseEth =
        data?.receiverActivation?.estimatedFeeBaseEth;

    if (fee) {
        fee.textContent =
            feeBaseEth
                ? `~ ${feeBaseEth} Base ETH`
                : "Base ETH · Schätzung momentan nicht verfügbar";
    }

    if (status) {
        status.textContent =
            "Die persönliche Lizenzadresse ist noch nicht aktiviert. " +
            "USDC-Zahlungen sind bis zur erfolgreichen Aktivierung gesperrt.";
    }
}

function showActivatedLicensePurchase(data) {
    const activation = byId("licenseReceiverActivation");
    const purchase = byId("licenseActivatedPurchase");
    const paymentRoute = byId("licensePaymentRoute");

    if (paymentRoute) paymentRoute.hidden = true;
    if (activation) activation.hidden = true;
    if (purchase) purchase.hidden = false;

    blockchainLicenseReceiver = data.receiver;

    const receiver = byId("licenseReceiverAddress");
    const copy = byId("licenseCopyReceiverButton");
    const status = byId("licensePurchaseStatus");

    if (receiver)
        receiver.textContent = blockchainLicenseReceiver;

    if (copy)
        copy.disabled = false;

    updateLicensePurchasePrice();

    if (status) {
        if (data.license?.isValid) {
            status.textContent =
                data.license.isLifetime
                    ? "Lizenz aktiv · Lifetime"
                    : "Lizenz aktiv";
        }
        else {
            status.textContent = "Bereit für Zahlung.";
        }
    }

    startBlockchainLicensePolling();
}

let blockchainLicenseLoad = null;
function loadBlockchainLicensePurchase() {
    if (!blockchainLicenseLoad) {
        blockchainLicenseLoad = performBlockchainLicensePurchaseLoad()
            .finally(() => { blockchainLicenseLoad = null; });
    }
    return blockchainLicenseLoad;
}
async function performBlockchainLicensePurchaseLoad() {
    const status = byId("licenseActivationStatus");

    const activation = byId("licenseReceiverActivation");
    if (activation) activation.hidden = false;
    if (status) status.textContent = "Persönliche Lizenzadresse wird geprüft …";
    // Do not hide receiver activation behind a slow tariff read. Handle rejection immediately.
    const tariffs = loadV2Tariffs().then(() => null, error => error);
    try {
        const data =
            await api(
                "/trader-api/license/v2-payment-status"
            );

        if (!data?.receiver) {
            throw new Error(
                "Persönliche Lizenzadresse ist momentan nicht verfügbar."
            );
        }

        if (data?.receiverActivation?.receiverReady !== true) {
            showLicenseReceiverActivation(data);
            const tariffError = await tariffs;
            if (tariffError && status) status.textContent += " Tarife derzeit nicht verfügbar. Bitte erneut versuchen.";
            return;
        }

        const tariffError = await tariffs;
        if (tariffError) throw new Error("Tarife derzeit nicht verfügbar. Bitte erneut versuchen.");
        showActivatedLicensePurchase(data);
    }
    catch (error) {
        stopBlockchainLicensePolling();
        blockchainLicenseReceiver = null;

        const activation =
            byId("licenseReceiverActivation");

        const purchase =
            byId("licenseActivatedPurchase");

        const paymentRoute =
            byId("licensePaymentRoute");

        if (paymentRoute)
            paymentRoute.hidden = false;

        if (activation)
            activation.hidden = false;

        if (purchase)
            purchase.hidden = true;

        if (status) {
            status.textContent =
                error?.message ||
                "Aktivierungsstatus momentan nicht verfügbar.";
        }
    }
}

async function copyLicenseReceiver() {
    if (!blockchainLicenseReceiver)
        return;

    const button =
        byId("licenseCopyReceiverButton");

    try {
        await navigator.clipboard.writeText(
            blockchainLicenseReceiver
        );

        if (button) {
            button.textContent = "Adresse kopiert ✓";

            setTimeout(() => {
                button.textContent = "Adresse kopieren";
            }, 1800);
        }
    }
    catch {
        window.prompt(
            "Empfängeradresse kopieren:",
            blockchainLicenseReceiver
        );
    }
}

function startBlockchainLicensePolling() {
    if (!blockchainLicenseReceiver)
        return;

    stopBlockchainLicensePolling();

    const check = async () => {
        if (blockchainLicensePollBusy) return;
        blockchainLicensePollBusy = true;
        const status =
            byId("licensePurchaseStatus");

        try {
            if (Date.now() - licenseTariffsLoadedAt > 45000) await loadV2Tariffs();
            const result =
                await api(
                    "/trader-api/license/v2-payment-status",
                    {
                        method: "POST"
                    }
                );

            if (
                result?.state ===
                "RECEIVER_NOT_ACTIVATED"
            ) {
                await loadBlockchainLicensePurchase();
                return;
            }

            if (!result?.ok) {
                if (status)
                    status.textContent =
                        "Blockchain wird geprüft …";

                return;
            }

            if (result.receiver) {
                blockchainLicenseReceiver =
                    result.receiver;

                const receiver =
                    byId("licenseReceiverAddress");

                if (receiver)
                    receiver.textContent =
                        result.receiver;

                updateLicenseV2PaymentPayload();
            }

            if (result.appliedCount > 0) {
                if (status) {
                    status.textContent =
                        "✓ Zahlung bestätigt · Lizenz erfolgreich aktualisiert.";
                }

                await loadLicenseStatus();
                return;
            }

            if (
                result.duplicateCount > 0 &&
                result.license?.isValid
            ) {
                if (status) {
                    status.textContent =
                        "✓ Zahlung bereits verbucht · Lizenz ist aktiv.";
                }

                return;
            }

            if (status) {
                if (result.license?.isLifetime) {
                    status.textContent =
                        "✓ Lizenz aktiv · Lifetime";
                }
                else if (result.license?.isValid) {
                    status.textContent =
                        "✓ Lizenz aktiv · Bereit für eine neue Lizenzzahlung.";
                }
                else {
                    status.textContent =
                        "Warte auf bestätigte USDC-Zahlung …";
                }
            }
        }
        catch (error) {
            if (status) {
                status.textContent =
                    "Zahlungsprüfung fehlgeschlagen: " +
                    (
                        error?.message ||
                        "Unbekannter Fehler"
                    );
            }
        }
        finally { blockchainLicensePollBusy = false; }
    };

    check();

    blockchainLicensePollTimer =
        setInterval(check, 15000);
}

function initBlockchainLicensePurchase() {
    const select =
        byId("licenseProductSelect");

    const copy =
        byId("licenseCopyReceiverButton");

    const tokenSelect =
        byId("licenseTokenSelect");

    const networkSelect =
        byId("licenseNetworkSelect");

    const copyHub =
        byId("licenseCopyActivationHubButton");

    const copyData =
        byId("licenseCopyActivationDataButton");

    const checkActivation =
        byId("licenseCheckActivationButton");

    if (
        select &&
        select.dataset.bound !== "true"
    ) {
        select.dataset.bound = "true";

        select.addEventListener(
            "change",
            updateLicensePurchasePrice
        );
    }

    if (
        tokenSelect &&
        tokenSelect.dataset.bound !== "true"
    ) {
        tokenSelect.dataset.bound = "true";

        tokenSelect.addEventListener(
            "change",
            () => {
                updateLicenseChainBadge();
                loadBlockchainLicensePurchase();
            }
        );
    }

    if (
        networkSelect &&
        networkSelect.dataset.bound !== "true"
    ) {
        networkSelect.dataset.bound = "true";

        networkSelect.addEventListener(
            "change",
            () => {
                updateLicenseChainBadge();
                loadBlockchainLicensePurchase();
            }
        );
    }

    if (
        copy &&
        copy.dataset.bound !== "true"
    ) {
        copy.dataset.bound = "true";

        copy.addEventListener(
            "click",
            copyLicenseReceiver
        );
    }

    if (
        copyHub &&
        copyHub.dataset.bound !== "true"
    ) {
        copyHub.dataset.bound = "true";

        copyHub.addEventListener(
            "click",
            () => copyLicenseActivationValue(
                "licenseActivationHub",
                copyHub
            )
        );
    }

    if (
        copyData &&
        copyData.dataset.bound !== "true"
    ) {
        copyData.dataset.bound = "true";

        copyData.addEventListener(
            "click",
            () => copyLicenseActivationValue(
                "licenseActivationData",
                copyData
            )
        );
    }

    if (
        checkActivation &&
        checkActivation.dataset.bound !== "true"
    ) {
        checkActivation.dataset.bound = "true";

        checkActivation.addEventListener(
            "click",
            async () => {
                const status =
                    byId("licenseActivationStatus");

                if (status)
                    status.textContent =
                        "Aktivierung wird auf Base geprüft …";

                await loadBlockchainLicensePurchase();
            }
        );
    }

    updateLicensePurchasePrice();
    updateLicenseChainBadge();
    loadBlockchainLicensePurchase();
}

function showDashboard(me) {
    byId("dashboardView")
        .classList.remove("hidden");

    byId("settingsMenuButton")
        .classList.remove("hidden");

    byId("welcomeText").textContent =
        `Hallo ${me.username || ""}`;

    byId("accountText").textContent =
        "Konto verbunden";

    byId("usernameValue").textContent =
        me.username || "–";

    byId("emailValue").textContent =
        me.email || "–";

    byId("appValue").textContent =
        me.appId || APP_ID;

    byId("deviceValue").textContent =
        deviceId.length > 16
            ? deviceId.slice(0, 16) + "…"
            : deviceId;

    byId("versionValue").textContent =
        `${nativeVersionName()} / Code ${nativeVersionCode()}`;

    loadProgramIdentity();
    loadLicenseStatus();
    initBlockchainLicensePurchase();
}


// Standalone: no device heartbeat.


async function loadProgramIdentity() {

    const versionValue =
        byId("programVersionValue");

    const revisionValue =
        byId("programRevisionValue");


    if (!versionValue || !revisionValue)
        return;


    try {

        const data =
            await api("/api/system/identity");


        versionValue.textContent =
            data?.version || "–";


        const revision =
            Number(data?.revision);


        revisionValue.textContent =
            Number.isInteger(revision) && revision >= 0
                ? `R${String(revision).padStart(4, "0")}`
                : "–";
    }
    catch {

        versionValue.textContent =
            "Nicht verfügbar";

        revisionValue.textContent =
            "Nicht verfügbar";
    }
}



function formatNumber(value, digits = 2) {
    const number = Number(value);

    if (!Number.isFinite(number))
        return "–";

    return new Intl.NumberFormat(
        "de-DE",
        {
            minimumFractionDigits: digits,
            maximumFractionDigits: digits
        }
    ).format(number);
}


function showTraderOffline() {
    byId("traderStatusBadge").textContent =
        "OFFLINE";

    byId("traderStatusBadge").className =
        "status-wait";

    byId("traderStatusValue").textContent =
        "Nicht erreichbar";

    byId("traderStatusSub").textContent =
        "BTC Trader Pro antwortet momentan nicht.";
}


// ==========================================================
// M15B · LIVE WALLET READ-ONLY
// ==========================================================
//
// Binance wird ausschließlich verwendet, wenn TradingMode=LIVE.
//
// Dashboard-Refresh: 10 Sekunden.
// Binance-Refresh:    maximal alle 60 Sekunden.
//
// Bei Fehlern wird frühestens nach 30 Sekunden erneut versucht.
//
// KEINE ORDERFUNKTION.
// ==========================================================

const LIVE_WALLET_REFRESH_MS =
    60000;

const LIVE_WALLET_ERROR_RETRY_MS =
    30000;


const liveWalletReadOnlyCache = {

    btc:
        null,

    usdc:
        null,

    loadedAt:
        0,

    lastAttemptAt:
        0,

    errorMessage:
        "",

    inFlight:
        null
};



async function loadLiveWalletReadOnlyCached() {

    const now =
        Date.now();


    const hasValidBalance =
        Number.isFinite(
            liveWalletReadOnlyCache.btc)
        &&
        Number.isFinite(
            liveWalletReadOnlyCache.usdc);


    if (
        hasValidBalance
        &&
        now -
            liveWalletReadOnlyCache.loadedAt
            <
            LIVE_WALLET_REFRESH_MS
    ) {

        return {
            ok: true,
            btc:
                liveWalletReadOnlyCache.btc,
            usdc:
                liveWalletReadOnlyCache.usdc
        };
    }


    if (liveWalletReadOnlyCache.inFlight) {

        return await
            liveWalletReadOnlyCache.inFlight;
    }


    if (
        liveWalletReadOnlyCache.errorMessage
        &&
        now -
            liveWalletReadOnlyCache.lastAttemptAt
            <
            LIVE_WALLET_ERROR_RETRY_MS
    ) {

        return {
            ok: false,
            message:
                liveWalletReadOnlyCache.errorMessage
        };
    }


    liveWalletReadOnlyCache.lastAttemptAt =
        now;


    liveWalletReadOnlyCache.inFlight =
        (async () => {

            try {

                const data =
                    await api(
                        "/trader-api/binance/account");


                const balances =
                    data.balances ??
                    data.Balances ??
                    {};


                const btc =
                    balances.btc ??
                    balances.Btc ??
                    {};


                const usdc =
                    balances.usdc ??
                    balances.Usdc ??
                    {};


                const btcTotal =
                    Number(
                        btc.total ??
                        btc.Total ??
                        0);


                const usdcTotal =
                    Number(
                        usdc.total ??
                        usdc.Total ??
                        0);


                if (
                    !Number.isFinite(
                        btcTotal)
                    ||
                    !Number.isFinite(
                        usdcTotal)
                ) {

                    throw new Error(
                        "Ungültiger Binance-Kontostand.");
                }


                liveWalletReadOnlyCache.btc =
                    btcTotal;

                liveWalletReadOnlyCache.usdc =
                    usdcTotal;

                liveWalletReadOnlyCache.loadedAt =
                    Date.now();

                liveWalletReadOnlyCache.errorMessage =
                    "";


                setBinanceAccountDisplay(
                    "connected",
                    btcTotal,
                    usdcTotal);


                return {
                    ok: true,
                    btc:
                        btcTotal,
                    usdc:
                        usdcTotal
                };
            }
            catch (error) {

                liveWalletReadOnlyCache.errorMessage =
                    error?.message
                    ||
                    "Binance-Kontostand nicht verfügbar.";


                return {
                    ok: false,
                    message:
                        liveWalletReadOnlyCache.errorMessage
                };
            }
            finally {

                liveWalletReadOnlyCache.inFlight =
                    null;
            }
        })();


    return await
        liveWalletReadOnlyCache.inFlight;
}



async function loadTraderDashboard() {
    try {
        const data =
            await api(
                "/api/v1/btctrader/dashboard");

        if (
            !data ||
            !data.connected
        ) {
            showTraderOffline();
            return;
        }


        const trader =
            data.trader || {};

        const market =
            data.market || {};

        const wallet =
            data.wallet || {};


        const livePosition =
            data.livePosition ??
            data.LivePosition ??
            null;


        // -------------------------------------------------
        // M15B · Betriebsmodus im sichtbaren Header
        // -------------------------------------------------

        const tradingMode =
            String(
                trader.tradingMode ??
                trader.TradingMode ??
                "OFF")
                .trim()
                .toUpperCase();


        const betaBadge =
            byId("betaBadge");


        if (betaBadge) {

            betaBadge.dataset.tradingMode =
                tradingMode;


            if (tradingMode === "TEST") {

                betaBadge.textContent =
                    "BTC Trader Pro · TESTWALLET";
            }
            else if (tradingMode === "LIVE") {

                betaBadge.textContent =
                    "BTC Trader Pro · LIVE WALLET";
            }
            else {

                betaBadge.textContent =
                    "BTC Trader Pro · AUS";
            }
        }


        document.documentElement.dataset.tradingMode =
            tradingMode;


        window.BtcTraderDiag?.changed?.(
            "LIVE",
            "trading-mode",
            `TradingMode=${tradingMode}`,
            "info");

        const tradingToggle =
            byId("tradingControlToggle");

        if (tradingToggle) {
            tradingToggle.disabled =
                tradingControlBusy ||
                tradingMode === "OFF";
        }


        // -------------------------------------------------
        // Verbindungsstatus
        // -------------------------------------------------

        byId("traderStatusBadge").textContent =
            "AKTIV";

        byId("traderStatusBadge").className =
            "status-ok";

        byId("traderStatusValue").textContent =
            trader.mode || "Verbunden";

        byId("traderStatusSub").textContent =
            `${trader.version || "BTC Trader"} · ${trader.rule || "–"}`;


        // -------------------------------------------------
        // BTC-Kurs
        // -------------------------------------------------

        byId("btcPriceValue").textContent =
            market.btcPrice == null
                ? "–"
                : `${formatNumber(
                    market.btcPrice,
                    2
                  )} USDC`;

        const diagMarketPrice = Number(market.btcPrice);

        window.BtcTraderDiag?.changed?.(
            "LIVE",
            "market-price",
            Number.isFinite(diagMarketPrice)
                ? `BTC=${formatNumber(diagMarketPrice, 2)} USDC`
                : "BTC=–",
            "info");

        if (market.change24h == null) {
            byId("btcPriceSub").textContent =
                "24h: –";
        }
        else {
            const change =
                Number(market.change24h);

            const prefix =
                change > 0
                    ? "+"
                    : "";

            byId("btcPriceSub").textContent =
                `24h: ${prefix}${formatNumber(
                    change,
                    3
                )} %`;
        }


        // -------------------------------------------------
        // M15B · Wallet nach Betriebsmodus
        // -------------------------------------------------

        if (tradingMode === "TEST") {

            byId("walletValue").textContent =
                `${formatNumber(
                    wallet.walletValue,
                    2
                )} USDC`;

            byId("walletSub").textContent =
                `${formatNumber(
                    wallet.usdc,
                    2
                )} USDC · ${formatNumber(
                    wallet.btc,
                    8
                )} BTC`;

            byId("walletLimitSub").textContent =
                `TestWallet-Budget: ${formatNumber(
                    wallet.startWalletValue,
                    2
                )} USDC`;

            setProfitValue(
                wallet.profit);


            if (wallet.hasPosition) {

                byId("positionValue").textContent =
                    "OFFEN";

                byId("positionCard").classList.add(
                    "position-open");

                byId("positionSub").textContent =
                    `Ø ${formatNumber(
                        wallet.averageBuyPrice,
                        2
                    )} · BUYs ${wallet.buyCount ?? 0}`;
            }
            else {

                byId("positionValue").textContent =
                    "KEINE";

                byId("positionCard").classList.remove(
                    "position-open");

                byId("positionSub").textContent =
                    "Keine offene Position";
            }
        }
        else if (tradingMode === "LIVE") {

            const liveWallet =
                await loadLiveWalletReadOnlyCached();


            if (liveWallet.ok) {

                const btcPrice =
                    Number(
                        market.btcPrice);


                const liveWalletValue =
                    Number.isFinite(
                        btcPrice)
                        ?
                        liveWallet.usdc
                        +
                        (
                            liveWallet.btc
                            *
                            btcPrice
                        )
                        :
                        null;


                byId("walletValue").textContent =
                    liveWalletValue === null
                        ?
                        "–"
                        :
                        `${formatNumber(
                            liveWalletValue,
                            2
                        )} USDC`;


                byId("walletSub").textContent =
                    `${formatNumber(
                        liveWallet.usdc,
                        2
                    )} USDC · ${formatNumber(
                        liveWallet.btc,
                        8
                    )} BTC · Binance`;

                byId("walletLimitSub").textContent =
                    `Max. LIVE-Position: ${formatNumber(
                        wallet.maxLivePositionUSDC ??
                        wallet.MaxLivePositionUSDC ??
                        0,
                        2
                    )} USDC`;

                window.BtcTraderDiag?.changed?.(
                    "LIVE",
                    "live-wallet",
                    `BinanceWallet=${formatNumber(liveWallet.usdc, 2)} USDC · ${formatNumber(liveWallet.btc, 8)} BTC${
                        liveWalletValue === null
                            ? ""
                            : ` · Value=${formatNumber(liveWalletValue, 2)} USDC`
                    }`,
                    "ok");
            }
            else {

                byId("walletValue").textContent =
                    "–";

                byId("walletSub").textContent =
                    "LIVE Wallet · Binance nicht verfügbar";

                byId("walletLimitSub").textContent =
                    `Max. LIVE-Position: ${formatNumber(
                        wallet.maxLivePositionUSDC ??
                        wallet.MaxLivePositionUSDC ??
                        0,
                        2
                    )} USDC`;
            }


            /*
             * LIVE-Position ausschließlich aus der
             * persönlichen live_execution.db.
             *
             * Niemals TestWallet-Positionswerte verwenden.
             */
            const liveHasPosition =
                Boolean(
                    livePosition?.hasPosition ??
                    livePosition?.HasPosition ??
                    false);


            if (liveHasPosition) {

                const liveAverageBuyPrice =
                    Number(
                        livePosition?.averageBuyPrice ??
                        livePosition?.AverageBuyPrice ??
                        0);


                const liveBuyCount =
                    Number(
                        livePosition?.buyCount ??
                        livePosition?.BuyCount ??
                        0);


                byId("positionValue").textContent =
                    "OFFEN";

                byId("positionCard").classList.add(
                    "position-open");


                byId("positionSub").textContent =
                    `Ø ${formatNumber(
                        liveAverageBuyPrice,
                        2
                    )} · BUYs ${liveBuyCount}`;
            }
            else {

                byId("positionValue").textContent =
                    "KEINE";

                byId("positionCard").classList.remove(
                    "position-open");

                byId("positionSub").textContent =
                    "Keine offene LIVE-Position";
            }
        }
        else {

            // AUS:
            // Keine TestWallet-Werte als scheinbare
            // Betriebsdaten anzeigen.

            byId("walletValue").textContent =
                "–";

            byId("walletSub").textContent =
                "Trading ausgeschaltet";

            byId("walletLimitSub").textContent =
                `Max. LIVE-Position: ${formatNumber(
                    wallet.maxLivePositionUSDC ??
                    wallet.MaxLivePositionUSDC ??
                    0,
                    2
                )} USDC`;

            byId("profitValue").textContent =
                "–";

            byId("profitValue").className =
                "profit-neutral";

            byId("positionValue").textContent =
                "–";

            byId("positionCard").classList.remove(
                "position-open");

            byId("positionSub").textContent =
                "Trading ausgeschaltet";
        }


        // -------------------------------------------------
        // Signal
        // -------------------------------------------------

        const rawSignal =
            String(trader.signal || "–");

        const signalParts =
            rawSignal.split("|");

        const signalValue =
            byId("signalValue");

        const signalSub =
            byId("signalSub");

        if (signalParts.length >= 2) {

            signalValue.textContent =
                signalParts[0].trim() || "–";

            const signalDetails =
                signalParts
                    .slice(1)
                    .map(part => part.trim())
                    .filter(Boolean);

            const signalFields =
                byId("signalFields");

            const parsedFields =
                signalDetails
                    .map(part => {
                        const match =
                            part.match(/^([^=]+)=(.+)$/);

                        if (!match) {
                            return null;
                        }

                        return {
                            label: match[1].trim(),
                            value: match[2].trim()
                        };
                    })
                    .filter(Boolean);

            /*
             * ValleyPeak-Anzeige:
             * Auch das bestehende menschenlesbare Format wird
             * ausschließlich zerlegt – es wird NICHTS berechnet.
             */
            if (
                parsedFields.length === 0 &&
                signalDetails.length > 0
            ) {
                const detailText =
                    signalDetails.join(" · ");

                const valleyMatch =
                    detailText.match(
                        /Schwelle\s+(≤|<=)\s*([^·]+?)\s*·\s*Aktuell\s+([^·]+?)\s*·\s*Abstand\s+([^·]+?)\s*·\s*([+-]?[0-9.,]+%)\s*·\s*AVG\s+([^·]+?)\s*·\s*Schwelle\s+([+-]?[0-9.,]+%)(?:\s*·|$)/i
                    );

                if (valleyMatch) {
                    parsedFields.push(
                        {
                            label: "Schwelle",
                            value:
                                valleyMatch[1] + " " +
                                valleyMatch[2].trim()
                        },
                        {
                            label: "Aktuell",
                            value: valleyMatch[3].trim()
                        },
                        {
                            label: "Abstand",
                            value: valleyMatch[4].trim()
                        },
                        {
                            label: "Abstand %",
                            value: valleyMatch[5].trim()
                        },
                        {
                            label: "AVG",
                            value: valleyMatch[6].trim()
                        },
                        {
                            label: "Schwelle %",
                            value: valleyMatch[7].trim()
                        }
                    );
                }
            }

            /*
             * Weitere nachgewiesene ValleyPeak-Formate.
             * Ausschließlich Zerlegung bereits gelieferter
             * Backend-Werte – keinerlei Berechnung.
             */
            if (
                parsedFields.length === 0 &&
                signalDetails.length > 0
            ) {
                const detailText =
                    signalDetails.join(" · ");

                let match = null;

                /*
                 * EINSTIEGSSCHWELLE ERREICHT
                 *
                 * Aktuell ... · Schwelle ≤ ... ·
                 * Warte auf Kurserholung · AVG ... ·
                 * Schwelle ...%
                 */
                match = detailText.match(
                    /^Aktuell\s+([^·]+?)\s*·\s*Schwelle\s+(≤|<=)\s*([^·]+?)\s*·\s*Warte auf Kurserholung\s*·\s*AVG\s+([^·]+?)\s*·\s*Schwelle\s+([+-]?[0-9.,]+%)$/i
                );

                if (match) {
                    parsedFields.push(
                        {
                            label: "Aktuell",
                            value: match[1].trim()
                        },
                        {
                            label: "Schwelle",
                            value:
                                match[2] + " " +
                                match[3].trim()
                        },
                        {
                            label: "AVG",
                            value: match[4].trim()
                        },
                        {
                            label: "Schwelle %",
                            value: match[5].trim()
                        }
                    );

                    signalSub.hidden = false;
                    signalSub.textContent =
                        "Warte auf Kurserholung";
                }

                /*
                 * EINSTIEG FREIGEGEBEN
                 *
                 * Kurserholung bestätigt · Aktuell ... ·
                 * AVG ... · Schwelle ...%
                 */
                if (!match) {
                    match = detailText.match(
                        /^Kurserholung bestätigt\s*·\s*Aktuell\s+([^·]+?)\s*·\s*AVG\s+([^·]+?)\s*·\s*Schwelle\s+([+-]?[0-9.,]+%)$/i
                    );

                    if (match) {
                        parsedFields.push(
                            {
                                label: "Aktuell",
                                value: match[1].trim()
                            },
                            {
                                label: "AVG",
                                value: match[2].trim()
                            },
                            {
                                label: "Schwelle %",
                                value: match[3].trim()
                            }
                        );

                        signalSub.hidden = false;
                        signalSub.textContent =
                            "Kurserholung bestätigt";
                    }
                }

                /*
                 * WARTE AUF VERKAUFSZIEL
                 *
                 * Ziel ≥ ... · Aktuell ... · Abstand ... ·
                 * ...% · Position ...%
                 */
                if (!match) {
                    match = detailText.match(
                        /^Ziel\s+(≥|>=)\s*([^·]+?)\s*·\s*Aktuell\s+([^·]+?)\s*·\s*Abstand\s+([^·]+?)\s*·\s*([+-]?[0-9.,]+%)\s*·\s*Position\s+([+-]?[0-9.,]+%)$/i
                    );

                    if (match) {
                        parsedFields.push(
                            {
                                label: "Ziel",
                                value:
                                    match[1] + " " +
                                    match[2].trim()
                            },
                            {
                                label: "Aktuell",
                                value: match[3].trim()
                            },
                            {
                                label: "Abstand",
                                value: match[4].trim()
                            },
                            {
                                label: "Abstand %",
                                value: match[5].trim()
                            },
                            {
                                label: "Position",
                                value: match[6].trim()
                            }
                        );
                    }
                }
            }

            /*
             * TrendPullback-Anzeige.
             *
             * Ausschließlich Zerlegung der bereits vom Backend
             * gelieferten DebugState-Werte. Keine Berechnung
             * von Trend, Pullback, Recovery oder Trading-Signalen
             * im Browser.
             */
            let trendPullbackStructured = false;
            let trendPullbackNote = "";

            if (
                parsedFields.length === 0 &&
                signalDetails.length > 0
            ) {
                const detailText =
                    signalDetails.join(" · ");

                const headline =
                    signalValue.textContent.trim();

                let match = null;

                if (headline === "WARTE AUF TRENDDATEN") {
                    match = detailText.match(
                        /^Kursdaten\s+([^·]+?)\s*·\s*TrendPullback sammelt das Analysefenster$/i
                    );

                    if (match) {
                        parsedFields.push({
                            label: "Kursdaten",
                            value: match[1].trim()
                        });

                        trendPullbackNote =
                            "TrendPullback sammelt das Analysefenster";
                        trendPullbackStructured = true;
                    }
                }
                else if (headline === "WARTE AUF KURSDATEN") {
                    trendPullbackNote =
                        signalDetails.join(" · ");

                    trendPullbackStructured = true;
                }
                else if (headline === "WARTE AUF AUFWÄRTSTREND") {
                    match = detailText.match(
                        /^Aktueller Trend\s+([^·]+?)\s*·\s*Benötigt\s+(≥|>=)\s*([^·]+?)$/i
                    );

                    if (match) {
                        parsedFields.push(
                            {
                                label: "Aktueller Trend",
                                value: match[1].trim()
                            },
                            {
                                label: "Benötigt",
                                value:
                                    match[2] + " " +
                                    match[3].trim()
                            }
                        );

                        trendPullbackStructured = true;
                    }
                }
                else if (headline === "AUFWÄRTSTREND AKTIV") {
                    match = detailText.match(
                        /^Neues Hoch\s+([^·]+?)\s*·\s*Trend\s+([^·]+?)\s*·\s*Warte auf Rücksetzer$/i
                    );

                    if (match) {
                        parsedFields.push(
                            {
                                label: "Neues Hoch",
                                value: match[1].trim()
                            },
                            {
                                label: "Trend",
                                value: match[2].trim()
                            }
                        );

                        trendPullbackNote =
                            "Warte auf Rücksetzer";
                        trendPullbackStructured = true;
                    }
                }
                else if (headline === "WARTE AUF RÜCKSETZER") {
                    match = detailText.match(
                        /^Aktueller Rücksetzer\s+([^·]+?)\s*·\s*Benötigt\s+(≥|>=)\s*([^·]+?)$/i
                    );

                    if (match) {
                        parsedFields.push(
                            {
                                label: "Aktueller Rücksetzer",
                                value: match[1].trim()
                            },
                            {
                                label: "Benötigt",
                                value:
                                    match[2] + " " +
                                    match[3].trim()
                            }
                        );

                        trendPullbackStructured = true;
                    }
                }
                else if (headline === "RÜCKSETZER ERKANNT") {
                    match = detailText.match(
                        /^Rücksetzer\s+([^·]+?)\s*·\s*Warte auf Tief und anschließende Erholung$/i
                    );

                    if (match) {
                        parsedFields.push({
                            label: "Rücksetzer",
                            value: match[1].trim()
                        });

                        trendPullbackNote =
                            "Warte auf Tief und anschließende Erholung";
                        trendPullbackStructured = true;
                    }
                }
                else if (headline === "RÜCKSETZER AKTIV") {
                    match = detailText.match(
                        /^Aktuelles Tief\s+([^·]+?)\s*·\s*Warte auf Kurserholung$/i
                    );

                    if (match) {
                        parsedFields.push({
                            label: "Aktuelles Tief",
                            value: match[1].trim()
                        });

                        trendPullbackNote =
                            "Warte auf Kurserholung";
                        trendPullbackStructured = true;
                    }
                }
                else if (headline === "WARTE AUF ERHOLUNG") {
                    match = detailText.match(
                        /^Aktuelle Erholung\s+([^·]+?)\s*·\s*Benötigt\s+(≥|>=)\s*([^·]+?)$/i
                    );

                    if (match) {
                        parsedFields.push(
                            {
                                label: "Aktuelle Erholung",
                                value: match[1].trim()
                            },
                            {
                                label: "Benötigt",
                                value:
                                    match[2] + " " +
                                    match[3].trim()
                            }
                        );

                        trendPullbackStructured = true;
                    }
                }
                else if (headline === "EINSTIEG FREIGEGEBEN") {
                    match = detailText.match(
                        /^Erholung\s+([^·]+?)\s*·\s*TrendPullback BUY-Bedingung erfüllt$/i
                    );

                    if (match) {
                        parsedFields.push({
                            label: "Erholung",
                            value: match[1].trim()
                        });

                        trendPullbackNote =
                            "TrendPullback BUY-Bedingung erfüllt";
                        trendPullbackStructured = true;
                    }
                }
            }

            /*
             * Anzeige בלבד:
             * Werte werden ausschließlich aus dem bereits vom
             * Backend gelieferten Signaltext übernommen.
             * Keine Target-/Exit-/Trading-Berechnung im Browser.
             */
            const structuredSignal =
                trendPullbackStructured ||
                (
                    parsedFields.length >= 2 &&
                    (
                        parsedFields.length === signalDetails.length ||
                        (
                            parsedFields.length >= 3 &&
                            parsedFields.some(
                                field =>
                                    field.label === "Abstand %" ||
                                    field.label === "Schwelle %" ||
                                    field.label === "Ziel"
                            )
                        )
                    )
                );

            if (
                signalFields &&
                structuredSignal
            ) {
                signalSub.textContent =
                    trendPullbackNote;

                signalSub.hidden =
                    !trendPullbackNote;

                signalFields.replaceChildren();

                for (const field of parsedFields) {
                    const item =
                        document.createElement("div");

                    item.className =
                        "signal-field";

                    const label =
                        document.createElement("span");

                    label.textContent =
                        field.label;

                    const value =
                        document.createElement("strong");

                    value.textContent =
                        field.value;

                    item.append(label, value);
                    signalFields.append(item);
                }

                signalFields.hidden = false;
            }
            else {
                signalSub.hidden = false;
                signalSub.textContent =
                    signalDetails.join("\n");

                if (signalFields) {
                    signalFields.hidden = true;
                    signalFields.replaceChildren();
                }
            }
        }
        else {

            signalValue.textContent =
                rawSignal;

            /*
             * Alte/SmartExit-Statuswerte bleiben vollständig
             * kompatibel. Die Rule steht bereits in der
             * kompakten Modus-Kachel darunter.
             */
            signalSub.hidden = false;
            signalSub.textContent =
                trader.rule || "–";

            const signalFields =
                byId("signalFields");

            if (signalFields) {
                signalFields.hidden = true;
                signalFields.replaceChildren();
            }
        }


        /*
         * Ein Trader-Fehler wird angezeigt,
         * ohne die App selbst als offline darzustellen.
         */
        if (
            trader.error &&
            trader.error !== "-"
        ) {
            byId("traderStatusSub").textContent =
                `Trader-Fehler: ${trader.error}`;
        }
    }
    catch (error) {
        /*
         * 401 wird bereits zentral durch api()
         * behandelt.
         *
         * Temporärer Trader-Ausfall darf die
         * angemeldete App nicht zerstören.
         */
        if (token)
            showTraderOffline();
    }
}



// ==========================================================
// M4.3C · PERSÖNLICHE TRADING-DATEN
// ==========================================================

function setProfitValue(value) {
    const element =
        byId("profitValue");

    const number =
        Number(value);

    if (!Number.isFinite(number)) {
        element.textContent = "–";
        element.className = "profit-neutral";
        return;
    }

    let arrow = "→";
    let prefix = "";
    let cssClass = "profit-neutral";

    if (number > 0) {
        arrow = "↗";
        prefix = "+";
        cssClass = "profit-positive";
    }
    else if (number < 0) {
        arrow = "↘";
        cssClass = "profit-negative";
    }

    element.textContent =
        `${arrow} ${prefix}${formatNumber(
            number,
            2
        )} USDC`;

    element.className =
        cssClass;
}



// ==========================================================
// M4.6A2 · MARKET CHART
// ==========================================================

const MARKET_CHART_RANGES =
    new Set([
        "current",
        "1h",
        "1d",
        "7d"
    ]);


let marketChartRange =
    localStorage.getItem(
        "btcTraderMarketRange")
    || "current";


if (!MARKET_CHART_RANGES.has(
        marketChartRange))
{
    marketChartRange =
        "current";
}


let marketChartPoints =
    [];

let marketChartFrom =
    null;

let marketChartTo =
    null;

let marketChartPosition =
    {};

let personalTradingTrades =
    [];

let marketChartUiInitialized =
    false;

let marketCustomFrom =
    null;

let marketCustomTo =
    null;

let marketResizeFrame =
    null;


// ==========================================================
// M4.6A3 · BLUE TOUCH ZOOM
// ==========================================================

let marketChartViewStart =
    0;

let marketChartViewEnd =
    1;

let marketChartTouchState =
    null;


function clampMarketValue(
    value,
    minimum,
    maximum) {

    return Math.min(
        maximum,
        Math.max(
            minimum,
            value));
}


function marketChartIsZoomed() {

    return (
        marketChartViewStart > .0001
        ||
        marketChartViewEnd < .9999
    );
}


function marketChartVisiblePoints() {

    const points =
        Array.isArray(
            marketChartPoints)
            ? marketChartPoints
            : [];


    if (points.length <= 2)
        return points;


    const lastIndex =
        points.length - 1;


    let startIndex =
        Math.floor(
            marketChartViewStart
            *
            lastIndex);


    let endIndex =
        Math.ceil(
            marketChartViewEnd
            *
            lastIndex);


    startIndex =
        Math.max(
            0,
            Math.min(
                startIndex,
                lastIndex - 1));


    endIndex =
        Math.max(
            startIndex + 1,
            Math.min(
                endIndex,
                lastIndex));


    return points.slice(
        startIndex,
        endIndex + 1);
}


function marketChartVisibleBounds() {

    const points =
        marketChartVisiblePoints();


    let first =
        null;

    let last =
        null;


    for (const point of points) {

        const time =
            marketDate(
                point.time);

        if (!time)
            continue;


        if (!first)
            first = time;

        last = time;
    }


    return {
        from:
            first ||
            marketDate(
                marketChartFrom),

        to:
            last ||
            marketDate(
                marketChartTo)
    };
}


function updateMarketZoomUi() {

    const reset =
        byId(
            "marketChartResetZoom");


    if (!reset)
        return;


    reset.classList.toggle(
        "hidden",
        !marketChartIsZoomed());
}


function redrawMarketZoom() {

    updateMarketZoomUi();

    renderMarketChart();

    renderTradeHistory(
        visibleTradesForMarketRange());
}


function resetMarketChartZoom(
    redraw = true) {

    marketChartViewStart =
        0;

    marketChartViewEnd =
        1;

    marketChartTouchState =
        null;


    if (redraw) {
        redrawMarketZoom();
    }
    else {
        updateMarketZoomUi();
    }
}


function marketDate(value) {

    if (!value)
        return null;


    const date =
        new Date(value);


    return Number.isNaN(
        date.getTime())
        ? null
        : date;
}


function marketRangeTitle(range) {

    switch (range) {

        case "1h":
            return "1 Std";

        case "1d":
            return "1 Tag";

        case "7d":
            return "7 Tage";

        default:
            return "Aktuell";
    }
}


function updateMarketRangeButtons() {

    document
        .querySelectorAll(
            "[data-market-range]")
        .forEach(
            button => {

                button.classList.toggle(
                    "active",
                    button.dataset.marketRange ===
                        marketChartRange);
            });
}


function visibleTradesForMarketRange() {

    if (
        !Array.isArray(
            personalTradingTrades)
    ) {
        return [];
    }


    const bounds =
        marketChartVisibleBounds();


    const from =
        bounds.from;

    const to =
        bounds.to;


    if (!from || !to)
        return personalTradingTrades;


    const fromTime =
        from.getTime();

    const toTime =
        to.getTime();


    return personalTradingTrades.filter(
        trade => {

            const time =
                marketDate(
                    trade.time);

            if (!time)
                return false;


            const value =
                time.getTime();


            return (
                value >= fromTime
                &&
                value <= toTime
            );
        });
}


function formatMarketAxisTime(
    date) {

    if (!date)
        return "";


    if (
        marketChartRange === "1d"
        ||
        marketChartRange === "7d"
    ) {
        return date.toLocaleString(
            "de-DE",
            {
                day: "2-digit",
                month: "2-digit",
                hour: "2-digit",
                minute: "2-digit"
            });
    }


    return date.toLocaleTimeString(
        "de-DE",
        {
            hour: "2-digit",
            minute: "2-digit"
        });
}


function chartCssColor(
    name,
    fallback) {

    const value =
        getComputedStyle(
            document.documentElement)
        .getPropertyValue(
            name)
        .trim();


    return value || fallback;
}


function renderMarketChart() {

    const canvas =
        byId(
            "marketChartCanvas");

    const empty =
        byId(
            "marketChartEmpty");


    if (!canvas || !empty)
        return;


    const validPoints =
        marketChartVisiblePoints()
            .map(
                point => {

                    const time =
                        marketDate(
                            point.time);

                    const price =
                        Number(
                            point.btcPrice);


                    if (
                        !time
                        ||
                        !Number.isFinite(
                            price)
                        ||
                        price <= 0
                    ) {
                        return null;
                    }


                    return {
                        time,
                        price
                    };
                })
            .filter(Boolean);


    if (validPoints.length < 2) {

        empty.classList.remove(
            "hidden");

        const context =
            canvas.getContext(
                "2d");

        if (context) {
            context.clearRect(
                0,
                0,
                canvas.width,
                canvas.height);
        }

        return;
    }


    empty.classList.add(
        "hidden");


    const rect =
        canvas.getBoundingClientRect();


    const width =
        Math.max(
            280,
            rect.width);


    const height =
        Math.max(
            180,
            rect.height);


    const dpr =
        Math.min(
            window.devicePixelRatio || 1,
            2);


    canvas.width =
        Math.round(
            width * dpr);

    canvas.height =
        Math.round(
            height * dpr);


    const ctx =
        canvas.getContext(
            "2d");


    if (!ctx)
        return;


    ctx.setTransform(
        dpr,
        0,
        0,
        dpr,
        0,
        0);


    ctx.clearRect(
        0,
        0,
        width,
        height);


    const btcColor =
        chartCssColor(
            "--btc",
            "#f7931a");

    const chartBlueColor =
        chartCssColor(
            "--chart-blue",
            "#39aaff");

    const borderColor =
        chartCssColor(
            "--border",
            "#2b3543");

    const mutedColor =
        chartCssColor(
            "--muted",
            "#909baa");

    const greenColor =
        chartCssColor(
            "--green",
            "#46c98b");

    const yellowColor =
        chartCssColor(
            "--yellow",
            "#eab85a");


    const padding = {
        left: 8,
        right: window.innerWidth <= 620 ? 52 : 74,
        top: 14,
        bottom: 28
    };


    const plotWidth =
        width
        -
        padding.left
        -
        padding.right;


    const plotHeight =
        height
        -
        padding.top
        -
        padding.bottom;


    const firstTime =
        validPoints[0]
            .time
            .getTime();


    const lastTime =
        validPoints[
            validPoints.length - 1]
            .time
            .getTime();


    const timeSpan =
        Math.max(
            1,
            lastTime - firstTime);


    const visibleTrades =
        visibleTradesForMarketRange();


    const yValues =
        validPoints.map(
            p => p.price);


    for (const trade of visibleTrades) {

        const price =
            Number(
                trade.price);

        if (
            Number.isFinite(price)
            &&
            price > 0
        ) {
            yValues.push(
                price);
        }
    }


    if (
        marketChartPosition
        &&
        marketChartPosition.hasPosition
    ) {

        const average =
            Number(
                marketChartPosition
                    .averageBuyPrice);

        const target =
            Number(
                marketChartPosition
                    .sellTarget);


        if (
            Number.isFinite(
                average)
            &&
            average > 0
        ) {
            yValues.push(
                average);
        }


        if (
            Number.isFinite(
                target)
            &&
            target > 0
        ) {
            yValues.push(
                target);
        }
    }


    let minPrice =
        Math.min(
            ...yValues);

    let maxPrice =
        Math.max(
            ...yValues);


    if (minPrice === maxPrice) {
        minPrice -= 1;
        maxPrice += 1;
    }


    const pricePadding =
        Math.max(
            1,
            (
                maxPrice
                -
                minPrice
            )
            * .08);


    minPrice -=
        pricePadding;

    maxPrice +=
        pricePadding;


    const priceSpan =
        maxPrice - minPrice;


    const xForTime =
        time =>
            padding.left
            +
            (
                (
                    time.getTime()
                    -
                    firstTime
                )
                /
                timeSpan
            )
            *
            plotWidth;


    const yForPrice =
        price =>
            padding.top
            +
            (
                1
                -
                (
                    (
                        price
                        -
                        minPrice
                    )
                    /
                    priceSpan
                )
            )
            *
            plotHeight;


    // ------------------------------------------------------
    // GRID + PREISACHSE
    // ------------------------------------------------------

    ctx.font =
        '9px -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif';

    ctx.textBaseline =
        "middle";


    for (
        let i = 0;
        i <= 4;
        i++
    ) {

        const ratio =
            i / 4;


        const y =
            padding.top
            +
            ratio
            *
            plotHeight;


        ctx.beginPath();

        ctx.strokeStyle =
            borderColor;

        ctx.globalAlpha =
            .55;

        ctx.lineWidth =
            1;

        ctx.moveTo(
            padding.left,
            y);

        ctx.lineTo(
            padding.left
            +
            plotWidth,
            y);

        ctx.stroke();


        const price =
            maxPrice
            -
            ratio
            *
            priceSpan;


        ctx.globalAlpha =
            1;

        ctx.fillStyle =
            mutedColor;

        ctx.textAlign =
            "left";


        ctx.fillText(
            new Intl.NumberFormat(
                "de-DE",
                {
                    maximumFractionDigits:
                        0
                })
            .format(price),
            padding.left
            +
            plotWidth
            +
            7,
            y);
    }


    // ------------------------------------------------------
    // X-ACHSE
    // ------------------------------------------------------

    const axisPoints = [
        0,
        .5,
        1
    ];


    for (const ratio of axisPoints) {

        const time =
            new Date(
                firstTime
                +
                ratio
                *
                timeSpan);


        const x =
            padding.left
            +
            ratio
            *
            plotWidth;


        ctx.fillStyle =
            mutedColor;

        ctx.textBaseline =
            "alphabetic";


        if (ratio === 0)
            ctx.textAlign = "left";

        else if (ratio === 1)
            ctx.textAlign = "right";

        else
            ctx.textAlign = "center";


        ctx.fillText(
            formatMarketAxisTime(
                time),
            x,
            height - 6);
    }


    // ------------------------------------------------------
    // AVERAGE BUY / SELL TARGET
    // ------------------------------------------------------

    function drawReferenceLine(
        price,
        color,
        dash,
        label) {

        if (
            !Number.isFinite(price)
            ||
            price <= 0
        ) {
            return;
        }


        const y =
            yForPrice(
                price);


        ctx.save();

        ctx.beginPath();

        ctx.strokeStyle =
            color;

        ctx.globalAlpha =
            .58;

        ctx.lineWidth =
            1;

        ctx.setLineDash(
            dash);

        ctx.moveTo(
            padding.left,
            y);

        ctx.lineTo(
            padding.left
            +
            plotWidth,
            y);

        ctx.stroke();


        ctx.setLineDash(
            []);

        ctx.globalAlpha =
            .9;

        ctx.fillStyle =
            color;

        ctx.textAlign =
            "right";

        ctx.textBaseline =
            "bottom";

        ctx.font =
            '8px -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif';


        ctx.fillText(
            label,
            padding.left
            +
            plotWidth
            -
            3,
            y - 2);

        ctx.restore();
    }


    if (
        marketChartPosition
        &&
        marketChartPosition.hasPosition
    ) {

        drawReferenceLine(
            Number(
                marketChartPosition
                    .averageBuyPrice),
            greenColor,
            [5,4],
            "AVG");


        drawReferenceLine(
            Number(
                marketChartPosition
                    .sellTarget),
            btcColor,
            [5,4],
            "TARGET");
    }


    // ------------------------------------------------------
    // KURSLINIE + FLÄCHE
    // ------------------------------------------------------

    const gradient =
        ctx.createLinearGradient(
            0,
            padding.top,
            0,
            padding.top
            +
            plotHeight);


    gradient.addColorStop(
        0,
        "rgba(57,170,255,.22)");

    gradient.addColorStop(
        1,
        "rgba(57,170,255,0)");


    ctx.beginPath();


    validPoints.forEach(
        (point, index) => {

            const x =
                xForTime(
                    point.time);

            const y =
                yForPrice(
                    point.price);


            if (index === 0)
                ctx.moveTo(x,y);
            else
                ctx.lineTo(x,y);
        });


    const lastPoint =
        validPoints[
            validPoints.length - 1];

    const firstPoint =
        validPoints[0];


    ctx.lineTo(
        xForTime(
            lastPoint.time),
        padding.top
        +
        plotHeight);

    ctx.lineTo(
        xForTime(
            firstPoint.time),
        padding.top
        +
        plotHeight);

    ctx.closePath();

    ctx.fillStyle =
        gradient;

    ctx.fill();


    ctx.beginPath();


    validPoints.forEach(
        (point, index) => {

            const x =
                xForTime(
                    point.time);

            const y =
                yForPrice(
                    point.price);


            if (index === 0)
                ctx.moveTo(x,y);
            else
                ctx.lineTo(x,y);
        });


    ctx.strokeStyle =
        chartBlueColor;

    ctx.globalAlpha =
        1;

    ctx.lineWidth =
        1.4;

    ctx.lineJoin =
        "round";

    ctx.lineCap =
        "round";

    /*
     * Dezenter Glow:
     * kräftiges Blau, aber kein überladener Neon-Effekt.
     */
    ctx.shadowColor =
        chartBlueColor;

    ctx.shadowBlur =
        2;

    ctx.stroke();

    ctx.shadowBlur =
        0;

    ctx.shadowColor =
        "transparent";

    ctx.globalAlpha =
        1;


    // ------------------------------------------------------
    // BUY / REBUY / SELL MARKER
    // ------------------------------------------------------

    for (const trade of visibleTrades) {

        const time =
            marketDate(
                trade.time);

        const price =
            Number(
                trade.price);


        if (
            !time
            ||
            !Number.isFinite(
                price)
            ||
            price <= 0
        ) {
            continue;
        }


        const timestamp =
            time.getTime();


        if (
            timestamp < firstTime
            ||
            timestamp > lastTime
        ) {
            continue;
        }


        const action =
            String(
                trade.action || "")
            .toUpperCase();


        let color =
            btcColor;

        let letter =
            "S";


        if (action === "BUY") {
            color =
                greenColor;

            letter =
                "B";
        }

        else if (
            action === "REBUY"
        ) {
            color =
                yellowColor;

            letter =
                "R";
        }


        const x =
            xForTime(
                time);

        const y =
            yForPrice(
                price);


        ctx.beginPath();

        ctx.fillStyle =
            color;

        ctx.arc(
            x,
            y,
            5,
            0,
            Math.PI * 2);

        ctx.fill();


        ctx.fillStyle =
            "#10151d";

        ctx.font =
            'bold 7px -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif';

        ctx.textAlign =
            "center";

        ctx.textBaseline =
            "middle";

        ctx.fillText(
            letter,
            x,
            y + .3);
    }
}


function updateMarketChartSummary(
    data) {

    const current =
        byId(
            "marketChartCurrent");

    const stats =
        byId(
            "marketChartStats");


    const validPrices =
        marketChartPoints
            .map(
                p =>
                    Number(
                        p.btcPrice))
            .filter(
                p =>
                    Number.isFinite(p)
                    &&
                    p > 0);


    if (
        current
        &&
        validPrices.length > 0
    ) {
        current.textContent =
            `${formatNumber(
                validPrices[
                    validPrices.length - 1],
                2
            )} USDC`;
    }


    if (stats) {

        if (
            validPrices.length === 0
        ) {
            stats.textContent =
                `${marketRangeTitle(
                    marketChartRange
                )} · keine Daten`;

            return;
        }


        const low =
            Math.min(
                ...validPrices);

        const high =
            Math.max(
                ...validPrices);


        stats.textContent =
            `${marketRangeTitle(
                marketChartRange
            )} · ${data.pointCount ?? validPrices.length} Punkte`
            +
            ` · Tief ${formatNumber(low,0)}`
            +
            ` · Hoch ${formatNumber(high,0)}`;
    }
}


async function loadMarketHistory() {

    let marketUrl =
        "/api/v1/btctrader/market?range="
        +
        encodeURIComponent(
            marketChartRange);

    if (marketChartRange === "custom" &&
        marketCustomFrom &&
        marketCustomTo)
    {
        marketUrl =
            "/api/v1/btctrader/market?from="
            +
            encodeURIComponent(
                marketCustomFrom)
            +
            "&to="
            +
            encodeURIComponent(
                marketCustomTo);
    }

    const data =
        await api(
            marketUrl);


    marketChartPoints =
        Array.isArray(
            data.points)
            ? data.points
            : [];


    marketChartFrom =
        data.from || null;

    marketChartTo =
        data.to || null;


    updateMarketRangeButtons();

    updateMarketChartSummary(
        data);

    renderMarketChart();


    /*
     * Trade History folgt exakt dem vom
     * Markt-Endpoint gelieferten Von/Bis-Zeitraum.
     */
    renderTradeHistory(
        visibleTradesForMarketRange());
}


async function selectMarketRange(
    range) {

    if (!MARKET_CHART_RANGES.has(
            range))
    {
        return;
    }


    marketChartRange =
        range;

    marketCustomFrom =
        null;

    marketCustomTo =
        null;


    /*
     * Neuer Schnellzeitraum beginnt immer
     * wieder in der vollständigen Ansicht.
     */
    resetMarketChartZoom(
        false);


    localStorage.setItem(
        "btcTraderMarketRange",
        range);


    updateMarketRangeButtons();


    try {
        await loadMarketHistory();
    }
    catch {

        const stats =
            byId(
                "marketChartStats");

        if (stats)
            stats.textContent =
                "Marktdaten momentan nicht verfügbar";
    }
}



async function applyCustomMarketRange() {

    const fromInput =
        byId("marketCustomFrom");

    const toInput =
        byId("marketCustomTo");

    if (!fromInput ||
        !toInput ||
        !fromInput.value ||
        !toInput.value)
    {
        return;
    }

    const fromTime =
        new Date(fromInput.value);

    const toTime =
        new Date(toInput.value);

    if (!Number.isFinite(fromTime.getTime()) ||
        !Number.isFinite(toTime.getTime()) ||
        fromTime >= toTime)
    {
        return;
    }

    marketCustomFrom =
        fromTime.toISOString();

    marketCustomTo =
        toTime.toISOString();

    marketChartRange =
        "custom";

    resetMarketChartZoom(
        true);

    updateMarketRangeButtons();

    try {
        await loadMarketHistory();
    }
    catch {
        const stats =
            byId("marketChartStats");

        if (stats)
            stats.textContent =
                "Marktdaten momentan nicht verfügbar";
    }
}


function updateCustomMarketApplyState() {

    const fromInput =
        byId("marketCustomFrom");

    const toInput =
        byId("marketCustomTo");

    const applyButton =
        byId("marketCustomApply");

    if (!fromInput ||
        !toInput ||
        !applyButton)
    {
        return;
    }

    const fromTime =
        new Date(fromInput.value);

    const toTime =
        new Date(toInput.value);

    applyButton.disabled =
        !fromInput.value ||
        !toInput.value ||
        !Number.isFinite(fromTime.getTime()) ||
        !Number.isFinite(toTime.getTime()) ||
        fromTime >= toTime;
}


function marketTouchDistance(
    first,
    second) {

    const dx =
        second.clientX -
        first.clientX;

    const dy =
        second.clientY -
        first.clientY;


    return Math.sqrt(
        dx * dx +
        dy * dy);
}


function startMarketPinch(
    touches,
    canvas) {

    if (touches.length < 2)
        return;


    const rect =
        canvas.getBoundingClientRect();


    const first =
        touches[0];

    const second =
        touches[1];


    const distance =
        marketTouchDistance(
            first,
            second);


    if (distance <= 0)
        return;


    const midpointX =
        (
            first.clientX
            +
            second.clientX
        )
        / 2
        -
        rect.left;


    /*
     * Renderer verwendet links 8 px und rechts 74 px.
     * Der Zoomanker folgt dadurch exakt dem sichtbaren Plot.
     */
    const plotLeft =
        8;

    const plotWidth =
        Math.max(
            1,
            rect.width
            -
            8
            -
            74);


    const midpointRatio =
        clampMarketValue(
            (
                midpointX
                -
                plotLeft
            )
            /
            plotWidth,
            0,
            1);


    const width =
        marketChartViewEnd
        -
        marketChartViewStart;


    const anchorValue =
        marketChartViewStart
        +
        midpointRatio
        *
        width;


    marketChartTouchState = {
        type:
            "pinch",

        distance,

        start:
            marketChartViewStart,

        end:
            marketChartViewEnd,

        width,

        midpointRatio,

        anchorValue
    };
}


function initMarketChartTouchZoom() {

    const canvas =
        byId(
            "marketChartCanvas");

    const reset =
        byId(
            "marketChartResetZoom");


    if (!canvas)
        return;


    if (
        canvas.dataset.touchZoomReady ===
        "true"
    ) {
        return;
    }


    canvas.dataset.touchZoomReady =
        "true";


    if (reset) {

        reset.addEventListener(
            "click",
            () => {
                resetMarketChartZoom();
            });
    }


    canvas.addEventListener(
        "touchstart",
        event => {

            if (
                event.touches.length >=
                2
            ) {

                event.preventDefault();

                startMarketPinch(
                    event.touches,
                    canvas);

                return;
            }


            if (
                event.touches.length ===
                1
            ) {

                const touch =
                    event.touches[0];


                marketChartTouchState = {
                    type:
                        "pan",

                    x:
                        touch.clientX,

                    y:
                        touch.clientY,

                    start:
                        marketChartViewStart,

                    end:
                        marketChartViewEnd
                };
            }
        },
        {
            passive:
                false
        });


    canvas.addEventListener(
        "touchmove",
        event => {

            // --------------------------------------------------
            // PINCH ZOOM
            // --------------------------------------------------

            if (
                event.touches.length >=
                2
            ) {

                event.preventDefault();


                if (
                    !marketChartTouchState
                    ||
                    marketChartTouchState.type !==
                        "pinch"
                ) {

                    startMarketPinch(
                        event.touches,
                        canvas);

                    return;
                }


                const state =
                    marketChartTouchState;


                const currentDistance =
                    marketTouchDistance(
                        event.touches[0],
                        event.touches[1]);


                if (
                    currentDistance <=
                    0
                ) {
                    return;
                }


                /*
                 * Finger auseinander:
                 * Fenster wird kleiner = hineinzoomen.
                 *
                 * Finger zusammen:
                 * Fenster wird größer = herauszoomen.
                 */
                let newWidth =
                    state.width
                    *
                    (
                        state.distance
                        /
                        currentDistance
                    );


                newWidth =
                    clampMarketValue(
                        newWidth,
                        .03,
                        1);


                let newStart =
                    state.anchorValue
                    -
                    state.midpointRatio
                    *
                    newWidth;


                newStart =
                    clampMarketValue(
                        newStart,
                        0,
                        1 - newWidth);


                marketChartViewStart =
                    newStart;

                marketChartViewEnd =
                    newStart
                    +
                    newWidth;


                redrawMarketZoom();

                return;
            }


            // --------------------------------------------------
            // EIN-FINGER PAN NUR NACH ZOOM
            // --------------------------------------------------

            if (
                event.touches.length !==
                    1
                ||
                !marketChartTouchState
                ||
                marketChartTouchState.type !==
                    "pan"
                ||
                !marketChartIsZoomed()
            ) {
                return;
            }


            const touch =
                event.touches[0];


            const dx =
                touch.clientX
                -
                marketChartTouchState.x;


            const dy =
                touch.clientY
                -
                marketChartTouchState.y;


            /*
             * Vertikales Wischen soll weiterhin
             * normal die Seite scrollen.
             */
            if (
                Math.abs(dy)
                >
                Math.abs(dx)
            ) {
                return;
            }


            if (
                Math.abs(dx) <
                3
            ) {
                return;
            }


            event.preventDefault();


            const rect =
                canvas.getBoundingClientRect();


            const plotWidth =
                Math.max(
                    1,
                    rect.width
                    -
                    8
                    -
                    74);


            const width =
                marketChartTouchState.end
                -
                marketChartTouchState.start;


            const shift =
                -
                (
                    dx
                    /
                    plotWidth
                )
                *
                width;


            const newStart =
                clampMarketValue(
                    marketChartTouchState.start
                    +
                    shift,
                    0,
                    1 - width);


            marketChartViewStart =
                newStart;

            marketChartViewEnd =
                newStart
                +
                width;


            redrawMarketZoom();
        },
        {
            passive:
                false
        });


    canvas.addEventListener(
        "touchend",
        event => {

            if (
                event.touches.length >=
                2
            ) {

                startMarketPinch(
                    event.touches,
                    canvas);

                return;
            }


            if (
                event.touches.length ===
                1
                &&
                marketChartIsZoomed()
            ) {

                const touch =
                    event.touches[0];


                marketChartTouchState = {
                    type:
                        "pan",

                    x:
                        touch.clientX,

                    y:
                        touch.clientY,

                    start:
                        marketChartViewStart,

                    end:
                        marketChartViewEnd
                };

                return;
            }


            marketChartTouchState =
                null;
        },
        {
            passive:
                false
        });


    canvas.addEventListener(
        "touchcancel",
        () => {

            marketChartTouchState =
                null;
        },
        {
            passive:
                true
        });


    updateMarketZoomUi();
}


function initMarketChartUi() {

    if (marketChartUiInitialized)
        return;


    marketChartUiInitialized =
        true;


    initMarketChartTouchZoom();


    const buttons =
        byId(
            "marketRangeButtons");


    if (buttons) {

        buttons.addEventListener(
            "click",
            event => {

                const button =
                    event.target.closest(
                        "[data-market-range]");


                if (!button)
                    return;


                selectMarketRange(
                    button.dataset.marketRange);
            });
    }


    const customFromInput =
        byId("marketCustomFrom");

    const customToInput =
        byId("marketCustomTo");

    const customApplyButton =
        byId("marketCustomApply");

    if (customFromInput)
        customFromInput.addEventListener(
            "input",
            updateCustomMarketApplyState);

    if (customToInput)
        customToInput.addEventListener(
            "input",
            updateCustomMarketApplyState);

    if (customApplyButton)
        customApplyButton.addEventListener(
            "click",
            applyCustomMarketRange);

    updateCustomMarketApplyState();


    window.addEventListener(
        "resize",
        () => {

            if (marketResizeFrame) {
                cancelAnimationFrame(
                    marketResizeFrame);
            }


            marketResizeFrame =
                requestAnimationFrame(
                    () => {
                        renderMarketChart();

                        marketResizeFrame =
                            null;
                    });
        });


    updateMarketRangeButtons();
}


function formatTradeTime(value) {

    if (!value)
        return "–";


    const date =
        new Date(value);


    if (Number.isNaN(
            date.getTime()))
    {
        return "–";
    }


    const day =
        String(
            date.getDate())
        .padStart(
            2,
            "0");


    const month =
        String(
            date.getMonth() + 1)
        .padStart(
            2,
            "0");


    const hours =
        String(
            date.getHours())
        .padStart(
            2,
            "0");


    const minutes =
        String(
            date.getMinutes())
        .padStart(
            2,
            "0");


    return (
        `${day}.${month}. `
        +
        `${hours}:${minutes}`
    );
}


function renderTradeHistory(trades) {
    const rows =
        Array.isArray(trades)
            ? trades
            : [];

    const empty =
        byId("tradeEmpty");

    const wrap =
        byId("tradeTableWrap");

    const body =
        byId("tradeTableBody");

    body.replaceChildren();

    if (rows.length === 0) {
        empty.classList.remove("hidden");
        wrap.classList.add("hidden");
        return;
    }

    empty.classList.add("hidden");
    wrap.classList.remove("hidden");


    for (const trade of rows) {

        const row =
            document.createElement("tr");


        // ZEIT
        const timeCell =
            document.createElement("td");

        timeCell.textContent =
            formatTradeTime(
                trade.time);

        row.appendChild(
            timeCell);


        // AKTION + RULE
        const actionCell =
            document.createElement("td");

        const action =
            document.createElement("span");

        const actionText =
            String(
                trade.action || "–"
            ).toUpperCase();

        action.textContent =
            actionText;

        action.className =
            "trade-action " +
            (
                actionText === "BUY"
                    ? "buy"
                    : actionText === "REBUY"
                        ? "rebuy"
                        : actionText === "SELL"
                            ? "sell"
                            : ""
            );

        actionCell.appendChild(
            action);

        if (trade.rule) {
            const rule =
                document.createElement("small");

            rule.className =
                "trade-rule";

            rule.textContent =
                String(trade.rule);

            actionCell.appendChild(
                rule);
        }

        row.appendChild(
            actionCell);


        // PREIS
        const priceCell =
            document.createElement("td");

        priceCell.textContent =
            `${formatNumber(
                trade.price,
                2
            )}`;

        row.appendChild(
            priceCell);


        // BETRAG
        const amountCell =
            document.createElement("td");

        const isLiveTrade =
            String(
                trade.rule || ""
            ).toUpperCase() === "LIVE";

        const amountValue =
            isLiveTrade &&
            (
                actionText === "BUY" ||
                actionText === "REBUY"
            ) &&
            Number.isFinite(
                Number(trade.quoteQuantity)
            )
                ? trade.quoteQuantity
                : trade.amount;

        amountCell.textContent =
            formatNumber(
                amountValue,
                actionText === "SELL"
                    ? 8
                    : (
                        actionText === "BUY" ||
                        actionText === "REBUY"
                            ? 2
                            : 8
                    ));

        row.appendChild(
            amountCell);


        // PROFIT
        const profitCell =
            document.createElement("td");

        const profit =
            Number(
                trade.profit);

        if (
            actionText !== "SELL" &&
            (!Number.isFinite(profit) || profit === 0)
        ) {
            profitCell.textContent =
                "–";
        }
        else {
            const prefix =
                profit > 0
                    ? "+"
                    : "";

            profitCell.textContent =
                `${prefix}${formatNumber(
                    profit,
                    2
                )}`;

            if (profit > 0)
                profitCell.className =
                    "trade-profit-positive";
            else if (profit < 0)
                profitCell.className =
                    "trade-profit-negative";
        }

        row.appendChild(
            profitCell);


        body.appendChild(
            row);
    }
}


async function loadPersonalTrading() {
    try {
        const data =
            await api(
                "/api/v1/btctrader/trading");

        if (
            !data ||
            !data.connected
        ) {
            return;
        }


        const position =
            data.position || {};


        // -------------------------------------------------
        // Profit
        // -------------------------------------------------

        setProfitValue(
            data.profit);


        // -------------------------------------------------
        // Position / persönliche Kennzahlen
        // -------------------------------------------------

        const hasPosition =
            Boolean(
                position.hasPosition);


        const diagPositionParts = [
            `Position=${hasPosition ? "OPEN" : "FLAT"}`,
            `Id=${Number(position.positionId) || 0}`,
            `BuyCount=${Number(position.buyCount) || 0}`
        ];

        if (hasPosition) {
            const averageBuy = Number(position.averageBuyPrice);
            const lastBuy = Number(position.lastBuyPrice);
            const sellTarget = Number(position.sellTarget);

            if (Number.isFinite(averageBuy) && averageBuy > 0)
                diagPositionParts.push(`Avg=${formatNumber(averageBuy, 2)}`);
            if (Number.isFinite(lastBuy) && lastBuy > 0)
                diagPositionParts.push(`Last=${formatNumber(lastBuy, 2)}`);
            if (Number.isFinite(sellTarget) && sellTarget > 0)
                diagPositionParts.push(`Target=${formatNumber(sellTarget, 2)}`);
        }

        diagPositionParts.push(`Trades=${Number(data.tradeCount) || 0}`);

        window.BtcTraderDiag?.changed?.(
            "LIVE",
            "position",
            diagPositionParts.join(" · "),
            hasPosition ? "warn" : "ok");

        const diagProfit =
            Number(data.profit);

        window.BtcTraderDiag?.changed?.(
            "LIVE",
            "profit",
            Number.isFinite(diagProfit)
                ? `Profit=${diagProfit >= 0 ? "+" : ""}${diagProfit} USDC`
                : "Profit=–",
            Number.isFinite(diagProfit) && diagProfit >= 0
                ? "ok"
                : "info");


        byId("sellTargetValue").textContent =
            hasPosition &&
            Number(position.sellTarget) > 0
                ? `${formatNumber(
                    position.sellTarget,
                    2
                )}`
                : "–";


        const sellTargetDistanceValue =
            byId("sellTargetDistanceValue");

        const sellTargetForDistance =
            Number(position.sellTarget);

        const averageBuyForDistance =
            Number(position.averageBuyPrice);

        if (
            sellTargetDistanceValue &&
            hasPosition &&
            Number.isFinite(sellTargetForDistance) &&
            sellTargetForDistance > 0 &&
            Number.isFinite(averageBuyForDistance) &&
            averageBuyForDistance > 0
        ) {
            const distance =
                sellTargetForDistance - averageBuyForDistance;

            const distancePercent =
                (distance / averageBuyForDistance) * 100;

            const sign =
                distance >= 0 ? "+" : "";

            sellTargetDistanceValue.textContent =
                `Δ Ø ${sign}${formatNumber(distance, 2)} · ${sign}${formatNumber(distancePercent, 2)} %`;
        }
        else if (sellTargetDistanceValue) {
            sellTargetDistanceValue.textContent = "–";
        }


        byId("averageBuyValue").textContent =
            hasPosition &&
            Number(position.averageBuyPrice) > 0
                ? `${formatNumber(
                    position.averageBuyPrice,
                    2
                )}`
                : "–";


        byId("lastBuyValue").textContent =
            hasPosition &&
            Number(position.lastBuyPrice) > 0
                ? `${formatNumber(
                    position.lastBuyPrice,
                    2
                )}`
                : "–";


        byId("buyCountValue").textContent =
            String(
                position.buyCount ?? 0);


        byId("tradeCountValue").textContent =
            String(
                data.tradeCount ?? 0);


        byId("positionIdValue").textContent =
            Number(position.positionId) > 0
                ? `#${position.positionId}`
                : "–";


        // -------------------------------------------------
        // Trade History
        // -------------------------------------------------

        personalTradingTrades =
            Array.isArray(
                data.trades)
                ? data.trades
                : [];

        marketChartPosition =
            position;


        renderTradeHistory(
            visibleTradesForMarketRange());

        renderMarketChart();


        // -------------------------------------------------
        // Aktualisierung
        // -------------------------------------------------

        if (data.fetchedAt) {
            const date =
                new Date(
                    data.fetchedAt);

            byId("tradingUpdatedValue").textContent =
                Number.isNaN(date.getTime())
                    ? "Aktualisiert"
                    : `Aktualisiert ${date.toLocaleTimeString(
                        "de-DE",
                        {
                            hour: "2-digit",
                            minute: "2-digit",
                            second: "2-digit"
                        })}`;
        }
    }
    catch {
        /*
         * Trading-History ist eine Zusatzansicht.
         * Ein Fehler hier darf das normale Dashboard
         * nicht zerstören.
         */
    }
}



// ==========================================================
// M5.1E-B · PERSONAL OPTIMIZER SUMMARY
// ==========================================================

let optimizerSummaryLastFetch =
    0;

let optimizerSummaryLoading =
    false;


// ==========================================================
// PRODUCT UI · MANUAL AUTO-OPTIMIZER RUNTIME STATUS
// ==========================================================

let optimizerRuntimeStatus =
    null;

let optimizerRuntimeLastFetch =
    0;

let optimizerRuntimeLoading =
    false;

function updateManualOptimizerButtons() {

    const runtimeState =
        String(
            optimizerRuntimeStatus?.State
            ??
            optimizerRuntimeStatus?.state
            ??
            "")
            .trim()
            .toUpperCase();

    const busy =
        runtimeState === "PENDING"
        ||
        runtimeState === "RUNNING";

    document
        .querySelectorAll(
            ".manual-optimizer-run-button")
        .forEach(
            button => {

                const enabledInput =
                    document.querySelector(
                        '[data-config-name="AutoOptimizerEnabled"]');

                const enabled =
                    enabledInput
                    &&
                    enabledInput.checked === true;

                button.disabled =
                    !enabled || busy;

                button.textContent =
                    busy
                        ? "Läuft …"
                        : "Jetzt starten";
            });
}


async function loadOptimizerRuntimeStatus(
    force = false) {

    const now =
        Date.now();

    if (
        !force
        &&
        now - optimizerRuntimeLastFetch < 10000
    ) {
        return;
    }

    if (optimizerRuntimeLoading)
        return;

    optimizerRuntimeLoading =
        true;

    try {

        const data =
            await api(
                "/api/optimizer");

        optimizerRuntimeStatus =
            data?.RuntimeStatus
            ??
            data?.runtimeStatus
            ??
            null;

        optimizerRuntimeLastFetch =
            Date.now();

        updateManualOptimizerButtons();
    }
    catch (error) {
        /*
         * Reine Zusatzanzeige.
         * Niemals Dashboard oder Trading stören.
         *
         * Ein fehlgeschlagener Statusabruf darf keinen
         * veralteten Busy-Zustand dauerhaft anzeigen.
         */
        const staleState =
            String(
                optimizerRuntimeStatus?.State
                ??
                optimizerRuntimeStatus?.state
                ??
                "")
                .trim()
                .toUpperCase();

        if (
            staleState === "PENDING"
            ||
            staleState === "RUNNING"
        ) {
            optimizerRuntimeStatus =
                null;

                updateManualOptimizerButtons();
        }

        console.error(
            "Optimizer-Runtime-Status konnte nicht aktualisiert werden.",
            error);
    }
    finally {

        optimizerRuntimeLoading =
            false;
    }
}


async function requestManualOptimizerRun() {

    const headers = {
        "X-App-Id": APP_ID,
        "Content-Type": "application/json"
    };

    if (token) {
        headers.Authorization =
            "Bearer " + token;
    }

    const response =
        await localFetch(
            "/api/v1/btctrader/optimizer/run-now",
            {
                method: "POST",
                headers,
                body: "{}"
            });

    const data =
        await response
            .json()
            .catch(() => ({}));



    const code =
        String(
            data?.code
            ??
            data?.Code
            ??
            "")
            .trim()
            .toLowerCase();

    if (!response.ok) {

        const error =
            new Error(
                data?.message
                ??
                data?.Message
                ??
                `HTTP ${response.status}`);

        error.optimizerCode =
            code;

        throw error;
    }

    return {
        data,
        code
    };
}


function optimizerSummaryField(
    data,
    name) {

    const fields =
        Array.isArray(
            data?.fields)
            ? data.fields
            : [];


    const field =
        fields.find(
            item =>
                String(
                    configProperty(
                        item,
                        "Name",
                        "name")
                    || ""
                ) === name);


    if (!field)
        return undefined;


    return configProperty(
        field,
        "Value",
        "value");
}


function optimizerSummaryBool(
    value) {

    if (typeof value === "boolean")
        return value;


    if (typeof value === "string") {

        const v =
            value
                .trim()
                .toLowerCase();

        return (
            v === "true"
            ||
            v === "1"
            ||
            v === "an"
        );
    }


    return Boolean(
        value);
}


function optimizerSummaryDate(
    value) {

    if (!value)
        return "Noch nie";


    const date =
        new Date(
            value);


    if (Number.isNaN(date.getTime()))
        return String(value);


    return date.toLocaleString(
        "de-DE",
        {
            day: "2-digit",
            month: "2-digit",
            year: "2-digit",
            hour: "2-digit",
            minute: "2-digit"
        });
}


function optimizerSummaryCurve(
    data) {

    const values =
        optimizerSummaryField(
            data,
            "ReBuyDistances");


    if (!Array.isArray(values))
        return "–";


    const maxBuy =
        Number(
            optimizerSummaryField(
                data,
                "MaxBuyCount"));


    const activeCount =
        Number.isFinite(maxBuy)
            ? Math.max(
                0,
                Math.floor(maxBuy) - 1)
            : values.length;


    const active =
        values.slice(
            0,
            activeCount);


    if (active.length === 0)
        return "Keine ReBUYs";


    const format =
        new Intl.NumberFormat(
            "de-DE",
            {
                maximumFractionDigits: 2
            });


    return (
        active
            .map(
                value => {

                    const number =
                        Number(value);

                    return Number.isFinite(number)
                        ? format.format(number)
                        : String(value);
                })
            .join(" · ")
        +
        " USDC"
    );
}


// ==========================================================
// OPTIMIZER CARD V2 · COMPACT SUMMARY
// ==========================================================
//
// Ausschließlich Dashboard-Anzeige.
// Keine Optimizer-/Config-/Trading-Änderung.
// ==========================================================

function optimizerSummaryWinnerLabel(
    value) {

    const numeric =
        Number(value);


    const winner =
        OPTIMIZER_WINNERS.find(
            item =>
                Number(item[0]) ===
                numeric);


    return winner
        ? winner[1]
        : "–";
}


function optimizerSummaryDays(
    value,
    zeroText = "0 Tage") {

    const numeric =
        Number(value);


    if (!Number.isFinite(numeric))
        return "–";


    if (numeric === 0)
        return zeroText;


    const rounded =
        Math.round(numeric);


    return (
        `${rounded} `
        +
        (
            rounded === 1
                ? "Tag"
                : "Tage"
        )
    );
}


function optimizerSummaryNextPossible(
    lastRunRaw,
    intervalRaw,
    enabled) {

    if (!enabled)
        return "–";


    if (!lastRunRaw)
        return "Nach nächstem SELL";


    const lastRun =
        new Date(
            lastRunRaw);


    if (
        Number.isNaN(
            lastRun.getTime())
    ) {
        return "–";
    }


    const interval =
        Number(
            intervalRaw);


    if (
        !Number.isFinite(interval)
        ||
        interval < 0
    ) {
        return "–";
    }


    const next =
        new Date(
            lastRun.getTime());


    next.setDate(
        next.getDate()
        +
        interval);


    if (
        next.getTime()
        <=
        Date.now()
    ) {
        return "Bereit · nach SELL";
    }


    return next.toLocaleString(
        "de-DE",
        {
            day: "2-digit",
            month: "2-digit",
            year: "2-digit",
            hour: "2-digit",
            minute: "2-digit"
        });
}


function renderOptimizerSummaryFromConfig(
    data) {

    const card =
        byId(
            "optimizerSummaryCard");

    if (!card)
        return;


    const badge =
        byId(
            "optimizerSummaryBadge");

    const winner =
        byId(
            "optimizerSummaryWinner");

    const interval =
        byId(
            "optimizerSummaryInterval");

    const lookback =
        byId(
            "optimizerSummaryLookback");

    const windowValue =
        byId(
            "optimizerSummaryWindow");

    const strategySize =
        byId(
            "optimizerSummaryStrategySize");

    const optimizerBudget =
        byId(
            "optimizerSummaryBudget");

    const lastRun =
        byId(
            "optimizerSummaryLastRun");

    const nextRun =
        byId(
            "optimizerSummaryNextRun");

    const curve =
        byId(
            "optimizerSummaryCurve");

    const hint =
        byId(
            "optimizerSummaryHint");


    if (
        !badge
        ||
        !winner
        ||
        !interval
        ||
        !lookback
        ||
        !windowValue
        ||
        !strategySize
        ||
        !optimizerBudget
        ||
        !lastRun
        ||
        !nextRun
        ||
        !curve
        ||
        !hint
    ) {
        return;
    }


    const enabled =
        optimizerSummaryBool(
            optimizerSummaryField(
                data,
                "AutoOptimizerEnabled"));


    const winnerRaw =
        optimizerSummaryField(
            data,
            "OptimizerWinnerSelection");


    const intervalRaw =
        optimizerSummaryField(
            data,
            "AutoOptimizerIntervalDays");


    const lookbackRaw =
        optimizerSummaryField(
            data,
            "OptimizerLookbackDays");


    const windowRaw =
        optimizerSummaryField(
            data,
            "Window");


    const lastRunRaw =
        optimizerSummaryField(
            data,
            "AutoOptimizerLastRun");


    const tradingModeRaw =
        optimizerSummaryField(
            data,
            "TradingMode");

    const tradeAmountRaw =
        optimizerSummaryField(
            data,
            "TradeAmount");

    const maxBuyCountRaw =
        optimizerSummaryField(
            data,
            "MaxBuyCount");

    const testWalletBudgetRaw =
        optimizerSummaryField(
            data,
            "TestWalletUSDC");

    const maxLivePositionRaw =
        optimizerSummaryField(
            data,
            "MaxLivePositionUSDC");


    // ------------------------------------------------------
    // STATUS
    // ------------------------------------------------------

    badge.textContent =
        enabled
            ? "AUTO AN"
            : "AUTO AUS";


    badge.classList.toggle(
        "is-on",
        enabled);


    badge.classList.toggle(
        "is-off",
        !enabled);


    card.classList.toggle(
        "optimizer-active",
        enabled);


    // ------------------------------------------------------
    // GEWINNERAUSWAHL
    // ------------------------------------------------------

    winner.textContent =
        optimizerSummaryWinnerLabel(
            winnerRaw);


    winner.classList.toggle(
        "optimizer-v2-muted",
        Number(winnerRaw) === 0);


    // ------------------------------------------------------
    // INTERVALL / LOOKBACK / WINDOW
    // ------------------------------------------------------

    interval.textContent =
        optimizerSummaryDays(
            intervalRaw);


    lookback.textContent =
        optimizerSummaryDays(
            lookbackRaw,
            "Alle Daten");


    windowValue.textContent =
        (
            windowRaw === null
            ||
            windowRaw === undefined
            ||
            windowRaw === ""
        )
            ? "–"
            : String(windowRaw);


    // ------------------------------------------------------
    // STRATEGIEGRÖSSE / OPTIMIZER-BUDGET
    // ------------------------------------------------------
    //
    // Exakt dieselbe Grundregel wie im Backend:
    //
    // Strategiegröße = TradeAmount × MaxBuyCount
    //
    // TEST:
    // MIN(Strategiegröße, TestWalletUSDC)
    //
    // LIVE:
    // MIN(Strategiegröße, MaxLivePositionUSDC)
    //
    // AUS:
    // kein Optimizer
    // ------------------------------------------------------

    const tradeAmount =
        Number(
            tradeAmountRaw);

    const maxBuyCount =
        Number(
            maxBuyCountRaw);

    const tradingMode =
        String(
            tradingModeRaw ?? "")
            .trim()
            .toUpperCase();


    const strategySizeUSDC =
        (
            Number.isFinite(tradeAmount)
            &&
            tradeAmount > 0
            &&
            Number.isFinite(maxBuyCount)
            &&
            maxBuyCount >= 1
        )
            ? tradeAmount * Math.floor(maxBuyCount)
            : null;


    let optimizerBudgetUSDC =
        null;


    if (
        strategySizeUSDC !== null
        &&
        tradingMode === "TEST"
    ) {

        const testWalletBudget =
            Number(
                testWalletBudgetRaw);

        if (
            Number.isFinite(testWalletBudget)
            &&
            testWalletBudget >= 0
        ) {
            optimizerBudgetUSDC =
                Math.min(
                    strategySizeUSDC,
                    testWalletBudget);
        }
    }
    else if (
        strategySizeUSDC !== null
        &&
        tradingMode === "LIVE"
    ) {

        const maxLivePosition =
            Number(
                maxLivePositionRaw);

        if (
            Number.isFinite(maxLivePosition)
            &&
            maxLivePosition >= 0
        ) {
            optimizerBudgetUSDC =
                Math.min(
                    strategySizeUSDC,
                    maxLivePosition);
        }
    }


    strategySize.textContent =
        strategySizeUSDC === null
            ? "–"
            : `${formatNumber(
                strategySizeUSDC,
                2)} USDC`;


    optimizerBudget.textContent =
        optimizerBudgetUSDC === null
            ? "–"
            : `${formatNumber(
                optimizerBudgetUSDC,
                2)} USDC`;


    // ------------------------------------------------------
    // LETZTER / FRÜHESTER LAUF
    // ------------------------------------------------------

    lastRun.textContent =
        optimizerSummaryDate(
            lastRunRaw);


    nextRun.textContent =
        optimizerSummaryNextPossible(
            lastRunRaw,
            intervalRaw,
            enabled);


    // ------------------------------------------------------
    // REBUY-KURVE
    // ------------------------------------------------------

    // ======================================================
    // REBUY CURVE POLISH · SPACED VALUES
    // ======================================================

    const curveText =
        optimizerSummaryCurve(
            data);


    curve.replaceChildren();


    if (
        curveText === "–"
        ||
        curveText === "Keine ReBUYs"
    ) {
        curve.textContent =
            curveText;
    }
    else {

        const suffix =
            " USDC";


        const values =
            curveText.endsWith(
                suffix)
                ?
                    curveText
                        .slice(
                            0,
                            -suffix.length)
                        .split(
                            " · ")
                :
                    [curveText];


        for (
            const value
            of values
        ) {

            const item =
                document.createElement(
                    "span");


            item.className =
                "optimizer-v2-curve-value";


            item.textContent =
                `${value} USDC`;


            curve.appendChild(
                item);
        }
    }


    // ------------------------------------------------------
    // DEZENTER HINWEIS
    // ------------------------------------------------------

    if (!enabled) {

        hint.textContent =
            "Automatische Optimierung deaktiviert";
    }
    else if (
        Number(winnerRaw) === 0
    ) {

        hint.textContent =
            "Automatische Auswertung aktiv · keine Gewinnerübernahme";
    }
    else {

        hint.textContent =
            "Start nach SELL, sobald das persönliche Intervall erreicht ist";
    }
}


async function loadOptimizerSummary(
    force = false) {

    const now =
        Date.now();


    if (
        !force
        &&
        now - optimizerSummaryLastFetch < 30000
    ) {
        return;
    }


    if (optimizerSummaryLoading)
        return;


    optimizerSummaryLoading =
        true;


    try {

        const data =
            await api(
                "/api/v1/btctrader/config");


        if (
            !data
            ||
            !data.connected
        ) {
            return;
        }


        optimizerSummaryLastFetch =
            Date.now();


        renderOptimizerSummaryFromConfig(
            data);

    }
    catch {
        /*
         * Zusatzanzeige.
         * Niemals Dashboard/Trading stören.
         */
    }
    finally {

        optimizerSummaryLoading =
            false;
    }
}


// ==========================================================
// M5.2E · COMPACT MARKETPHASE CARD
// ==========================================================
//
// Reine Dashboard-Anzeige.
//
// Die eigentliche Analyse bleibt vollständig im BTC Trader.
// Dieser Code:
// - berechnet keine Marktphase
// - verändert keine Config
// - verändert kein Trading
// - startet keinen Optimizer
//
// Backend-Analyse wird maximal ungefähr einmal pro Minute
// über AppManagement abgefragt.
// ==========================================================

let marketPhaseLastFetch =
    0;

let marketPhaseLoading =
    false;

const MARKET_PHASE_FETCH_INTERVAL_MS =
    55000;


function marketPhaseTrendInfo(
    trend) {

    const value =
        String(
            trend || ""
        )
        .trim()
        .toUpperCase();


    if (value === "UP") {
        return {
            arrow: "↗",
            tone: "is-up"
        };
    }


    if (value === "DOWN") {
        return {
            arrow: "↘",
            tone: "is-down"
        };
    }


    return {
        arrow: "→",
        tone: "is-neutral"
    };
}


function setMarketPhaseTrend(
    arrowId,
    valueId,
    trend) {

    const info =
        marketPhaseTrendInfo(
            trend);


    const arrow =
        byId(
            arrowId);

    const value =
        byId(
            valueId);


    if (arrow) {
        arrow.textContent =
            info.arrow;

        arrow.className =
            "market-phase-trend-arrow "
            +
            info.tone;
    }


    if (value) {
        value.textContent =
            String(
                trend || "–"
            );
    }
}


function setMarketPhaseUnavailable(
    text) {

    const card =
        byId(
            "marketPhaseCard");

    const badge =
        byId(
            "marketPhaseBadge");


    if (card) {
        card.classList.remove(
            "phase-up",
            "phase-down",
            "phase-shock");

        card.classList.add(
            "phase-neutral");
    }


    if (badge) {
        badge.textContent =
            "WARTET";

        badge.className =
            "market-phase-badge is-wait";
    }


    const name =
        byId(
            "marketPhaseName");

    if (name) {
        name.textContent =
            "Noch keine Analyse";
    }


    const phaseArrow =
        byId(
            "marketPhaseArrow");

    if (phaseArrow) {
        phaseArrow.textContent =
            "→";

        phaseArrow.className =
            "market-phase-main-arrow is-neutral";
    }


    const confidence =
        byId(
            "marketPhaseConfidence");

    if (confidence) {
        confidence.textContent =
            "–";
    }


    setMarketPhaseTrend(
        "marketPhaseMainTrendArrow",
        "marketPhaseMainTrend",
        "");

    setMarketPhaseTrend(
        "marketPhaseShortTrendArrow",
        "marketPhaseShortTrend",
        "");


    const resetIds = [
        "marketPhaseVolatility",
        "marketPhaseSpeed",
        "marketPhaseLookback",
        "marketPhaseWindow",
        "marketPhaseShock",
        "marketPhaseAutoApply"
    ];


    for (const id of resetIds) {
        const element =
            byId(id);

        if (element) {
            element.textContent =
                "–";

            element.className =
                "";
        }
    }


    const decision =
        byId(
            "marketPhaseDecision");

    if (decision) {
        decision.textContent =
            text ||
            "Marktanalyse momentan nicht verfügbar.";
    }
}


function renderMarketPhaseSummary(
    data) {

    if (
        !data
        ||
        !data.connected
        ||
        !data.available
        ||
        !data.result
    ) {
        setMarketPhaseUnavailable(
            data?.status ||
            "Marktanalyse momentan nicht verfügbar.");

        return;
    }


    const result =
        data.result;

    const diagPhase =
        String(
            result.phaseName ||
            result.mainTrend ||
            "UNKNOWN");

    const diagShock =
        result.shockDetected === true;

    const diagDecision =
        String(
            result.decisionReason ||
            data.status ||
            "–")
            .replace(/\s+/g, " ")
            .trim();

    window.BtcTraderDiag?.changed?.(
        "RULE",
        "market-phase",
        `Phase=${diagPhase} · Shock=${diagShock ? "JA" : "NEIN"} · ${diagDecision}`,
        diagShock ? "warn" : "info");

    const card =
        byId(
            "marketPhaseCard");

    const badge =
        byId(
            "marketPhaseBadge");


    // ------------------------------------------------------
    // Persönliche Aktivierung
    // ------------------------------------------------------

    if (badge) {
        badge.textContent =
            data.enabled
                ? "AN"
                : "AUS";

        badge.className =
            "market-phase-badge "
            +
            (
                data.enabled
                    ? "is-on"
                    : "is-off"
            );
    }


    // ------------------------------------------------------
    // Phase / Farbstimmung
    // ------------------------------------------------------

    const mainTrend =
        String(
            result.mainTrend || ""
        )
        .toUpperCase();

    const shock =
        result.shockDetected === true;


    let phaseTone =
        "phase-neutral";

    if (shock) {
        phaseTone =
            "phase-shock";
    }
    else if (mainTrend === "UP") {
        phaseTone =
            "phase-up";
    }
    else if (mainTrend === "DOWN") {
        phaseTone =
            "phase-down";
    }


    if (card) {
        card.classList.remove(
            "phase-up",
            "phase-down",
            "phase-neutral",
            "phase-shock");

        card.classList.add(
            phaseTone);
    }


    const phaseName =
        byId(
            "marketPhaseName");

    if (phaseName) {
        phaseName.textContent =
            String(
                result.phaseName ||
                "–"
            );
    }


    const mainInfo =
        marketPhaseTrendInfo(
            mainTrend);


    const phaseArrow =
        byId(
            "marketPhaseArrow");

    if (phaseArrow) {
        phaseArrow.textContent =
            shock
                ? "!"
                : mainInfo.arrow;

        phaseArrow.className =
            "market-phase-main-arrow "
            +
            (
                shock
                    ? "is-shock"
                    : mainInfo.tone
            );
    }


    // ------------------------------------------------------
    // Confidence
    // ------------------------------------------------------

    const confidenceNumber =
        Number(
            result.confidence);

    const confidence =
        byId(
            "marketPhaseConfidence");

    if (confidence) {
        confidence.textContent =
            Number.isFinite(
                confidenceNumber)
                ?
                    `${Math.round(
                        confidenceNumber
                    )} %`
                :
                    "–";
    }


    // ------------------------------------------------------
    // Trends
    // ------------------------------------------------------

    setMarketPhaseTrend(
        "marketPhaseMainTrendArrow",
        "marketPhaseMainTrend",
        result.mainTrend);

    setMarketPhaseTrend(
        "marketPhaseShortTrendArrow",
        "marketPhaseShortTrend",
        result.shortTermTrend);


    // ------------------------------------------------------
    // Einzelwerte
    // ------------------------------------------------------

    const volatility =
        byId(
            "marketPhaseVolatility");

    if (volatility) {
        volatility.textContent =
            String(
                result.volatility ||
                "–"
            );
    }


    const speed =
        byId(
            "marketPhaseSpeed");

    if (speed) {
        speed.textContent =
            String(
                result.speed ||
                "–"
            );
    }


    const lookback =
        byId(
            "marketPhaseLookback");

    const recommendedLookback =
        Number(
            result.recommendedLookbackDays);

    if (lookback) {
        lookback.textContent =
            Number.isFinite(
                recommendedLookback)
                ?
                    `${recommendedLookback} ${
                        recommendedLookback === 1
                            ? "Tag"
                            : "Tage"
                    }`
                :
                    "–";
    }


    const windowElement =
        byId(
            "marketPhaseWindow");

    const currentWindow =
        Number(
            result.currentWindow);

    const recommendedWindow =
        Number(
            result.recommendedWindow);


    if (windowElement) {

        if (
            Number.isFinite(
                currentWindow)
            &&
            Number.isFinite(
                recommendedWindow)
        ) {
            windowElement.textContent =
                currentWindow ===
                    recommendedWindow
                    ?
                        String(
                            currentWindow)
                    :
                        `${currentWindow} → ${recommendedWindow}`;
        }
        else {
            windowElement.textContent =
                "–";
        }
    }


    const shockElement =
        byId(
            "marketPhaseShock");

    if (shockElement) {
        shockElement.textContent =
            shock
                ? "JA"
                : "NEIN";

        shockElement.className =
            shock
                ? "market-phase-value-danger"
                : "market-phase-value-ok";
    }


    const autoApply =
        byId(
            "marketPhaseAutoApply");

    const automaticApplyAllowed =
        result.automaticApplyAllowed ===
            true;


    if (autoApply) {
        autoApply.textContent =
            automaticApplyAllowed
                ? "ERLAUBT"
                : "AUS";

        autoApply.className =
            automaticApplyAllowed
                ? "market-phase-value-ok"
                : "market-phase-value-muted";
    }


    // ------------------------------------------------------
    // Entscheidung
    // ------------------------------------------------------

    const decision =
        byId(
            "marketPhaseDecision");

    if (decision) {
        decision.textContent =
            String(
                result.decisionReason ||
                data.status ||
                "–"
            );
    }
}


async function loadMarketPhaseSummary(
    force = false) {

    const now =
        Date.now();


    if (
        !force
        &&
        marketPhaseLastFetch > 0
        &&
        now -
            marketPhaseLastFetch
            <
            MARKET_PHASE_FETCH_INTERVAL_MS
    ) {
        return;
    }


    if (marketPhaseLoading)
        return;


    marketPhaseLoading =
        true;


    try {

        const data =
            await api(
                "/api/v1/btctrader/marketphase");


        marketPhaseLastFetch =
            Date.now();


        renderMarketPhaseSummary(
            data);
    }
    catch {
        /*
         * Zusatzanzeige.
         *
         * Fehler der Marktphasen-Karte dürfen niemals
         * Dashboard oder Trading beeinflussen.
         */

        setMarketPhaseUnavailable(
            "Marktanalyse momentan nicht erreichbar.");
    }
    finally {

        marketPhaseLoading =
            false;
    }
}


async function refreshTraderViews() {
    initMarketChartUi();

    await Promise.allSettled([
        loadTraderDashboard(),
        loadPersonalTrading(),
        loadTradingControl(),
        loadMarketHistory(),
        loadOptimizerSummary(),
        loadOptimizerRuntimeStatus(),
        loadMarketPhaseSummary()
    ]);
}


async function requestTraderRefresh() {
    if (document.hidden || !token)
        return;

    if (traderRefreshBusy) {
        traderRefreshPending = true;
        return;
    }

    traderRefreshBusy = true;
    traderRefreshPending = false;

    try {
        await refreshTraderViews();
    }
    finally {
        traderRefreshBusy = false;

        if (traderRefreshPending && !document.hidden && token) {
            traderRefreshPending = false;
            queueMicrotask(requestTraderRefresh);
        }
    }
}


function startTraderUpdates() {
    if (traderTimer !== null)
        clearInterval(traderTimer);

    requestTraderRefresh();

    traderTimer =
        setInterval(
            requestTraderRefresh,
            10000);
}


async function loadAccount() {
    const session = await api("/api/local/session");

    localCsrfToken =
        session.csrfToken;

    token =
        "local-session";

    showDashboard({
        username:
            session.user || "–",
        email:
            "Nicht erforderlich",
        appId:
            "BTC Trader Pro Standalone"
    });

    startTraderUpdates();
}


async function logout() {
    if (traderTimer !== null) clearInterval(traderTimer);
    await localFetch("/logout", { method: "POST" });
    token = "";
    redirectToLogin();
}


byId("tradingControlToggle")
    .addEventListener(
        "change",
        changeTradingControl);

byId("settingsMenuButton")
    .addEventListener(
        "click",
        openSettingsDrawer);

byId("drawerCloseButton")
    .addEventListener(
        "click",
        closeSettingsDrawer);

byId("drawerOverlay")
    .addEventListener(
        "click",
        closeSettingsDrawer);

byId("drawerSettingsButton")
    .addEventListener(
        "click",
        openPersonalConfig);

byId("configBackButton")
    .addEventListener(
        "click",
        handleProductConfigBack);

byId("drawerBinanceButton")
    .addEventListener(
        "click",
        () => {
            binanceOpenedFromConfig =
                false;

            showBinanceView();
        });

byId("binanceBackButton")
    .addEventListener(
        "click",
        handleBinanceBack);

byId("binanceSecretToggleButton")
    .addEventListener(
        "click",
        toggleBinanceSecretVisibility);

// ==========================================================
// M5.1G4 · ROBUSTER SAVE-TAP
// ==========================================================

let configSavePointerHandledAt =
    0;


function configSaveButtonContainsPoint(
    x,
    y) {

    const button =
        byId(
            "configSaveButton");


    if (!button)
        return false;


    const configView =
        byId(
            "drawerConfigView");


    if (
        !configView
        ||
        configView.classList.contains(
            "hidden")
    ) {
        return false;
    }


    const rect =
        button.getBoundingClientRect();


    if (
        rect.width <= 0
        ||
        rect.height <= 0
    ) {
        return false;
    }


    return (
        x >= rect.left
        &&
        x <= rect.right
        &&
        y >= rect.top
        &&
        y <= rect.bottom
    );
}


function triggerConfigSaveFromUi() {

    /*
     * Doppelte Sicherheit:
     * Schon eine offene Position verhindert jeden Save.
     */
    if (
        configPositionOpen
        ||
        !configTradingCanEdit
    ) {

        showConfigLockedCenterWarning();


        setConfigActionMessage(
            configPositionOpen
                ? "Speichern nicht möglich: Die aktuelle Position ist noch offen. Nach dem SELL und der anschließenden Pause kann die Config gespeichert werden."
                : "Speichern nicht möglich: Trading zuerst pausieren.",
            "error");


        return;
    }


    savePersonalConfig();
}


function captureConfigSaveTap(
    x,
    y,
    event) {

    if (
        !configSaveButtonContainsPoint(
            x,
            y)
    ) {
        return;
    }


    /*
     * Wir haben den tatsächlichen Tipp auf die sichtbare
     * Speichern-Fläche erkannt.
     *
     * Damit sind wir unabhängig davon, welches Element
     * Android/WebView intern als Event-Target verwendet.
     */
    event.preventDefault();

    event.stopPropagation();


    configSavePointerHandledAt =
        Date.now();


    triggerConfigSaveFromUi();
}


/*
 * Moderne Android-WebViews:
 * pointerup ist zuverlässiger als ausschließlich click.
 */
if ("PointerEvent" in window) {

    document.addEventListener(
        "pointerup",
        event => {

            if (
                event.pointerType === "mouse"
                &&
                event.button !== 0
            ) {
                return;
            }


            captureConfigSaveTap(
                event.clientX,
                event.clientY,
                event);
        },
        true);
}


/*
 * Fallback für Browser/WebViews ohne PointerEvent.
 */
else {

    document.addEventListener(
        "touchend",
        event => {

            const touch =
                event.changedTouches
                &&
                event.changedTouches[0];


            if (!touch)
                return;


            captureConfigSaveTap(
                touch.clientX,
                touch.clientY,
                event);
        },
        true);
}


/*
 * Click bleibt als Desktop-/Tastatur-Fallback erhalten.
 * Nach einem Pointer-Tap wird der synthetische Click
 * bewusst ignoriert, damit niemals doppelt gespeichert wird.
 */
byId("configSaveButton")
    .addEventListener(
        "click",
        event => {

            event.preventDefault();


            if (
                Date.now()
                -
                configSavePointerHandledAt
                <
                800
            ) {
                return;
            }


            triggerConfigSaveFromUi();
        });


byId("configFactoryButton")
    .addEventListener(
        "click",
        resetPersonalConfigToFactory);

byId("drawerWalletButton")
    .addEventListener(
        "click",
        openTestWalletResetPanel);


byId("walletResetConfirmButton")
    .addEventListener(
        "click",
        performTestWalletReset);


byId("walletResetCancelButton")
    .addEventListener(
        "click",
        closeTestWalletResetPanel);

byId("drawerAccountButton")
    .addEventListener(
        "click",
        openAccountFromDrawer);

byId("drawerInfoButton")
    .addEventListener(
        "click",
        showInfoFromDrawer);

document.addEventListener(
    "keydown",
    event => {
        if (event.key === "Escape")
            closeSettingsDrawer();
    });


byId("logoutButton")
    .addEventListener(
        "click",
        logout);

(async function start() {
    try { await loadAccount(); }
    catch (error) { redirectToLogin(); }
})();


// ============================================================================
// LIVE DATA RESET
// ============================================================================

let liveDataResetBusy =
    false;

let liveDataResetArmed =
    false;

let liveDataResetArmTimer =
    null;


function resetLiveDataResetArm() {

    liveDataResetArmed =
        false;


    if (liveDataResetArmTimer) {

        clearTimeout(
            liveDataResetArmTimer);

        liveDataResetArmTimer =
            null;
    }


    const button =
        byId(
            "liveResetConfirmButton");


    if (
        button
        &&
        !liveDataResetBusy
    ) {

        button.disabled =
            false;

        button.textContent =
            "LIVE-Daten zurücksetzen";

        button.classList.remove(
            "armed");
    }
}


function closeLiveDataResetPanel() {

    resetLiveDataResetArm();


    const panel =
        byId(
            "drawerLiveResetPanel");


    const menuButton =
        byId(
            "drawerLiveResetButton");


    if (panel)
        panel.classList.add(
            "hidden");


    if (menuButton)
        menuButton.classList.remove(
            "wallet-open");
}


function openLiveDataResetPanel() {

    closeTestWalletResetPanel();


    const panel =
        byId(
            "drawerLiveResetPanel");


    const menuButton =
        byId(
            "drawerLiveResetButton");


    const state =
        byId(
            "liveResetState");


    const confirmButton =
        byId(
            "liveResetConfirmButton");


    if (
        !panel
        ||
        !state
        ||
        !confirmButton
    ) {
        return;
    }


    if (!panel.classList.contains(
            "hidden"))
    {
        closeLiveDataResetPanel();
        return;
    }


    resetLiveDataResetArm();


    panel.classList.remove(
        "hidden");


    if (menuButton)
        menuButton.classList.add(
            "wallet-open");


    state.textContent =
        "Bereit · Sicherheitsbedingungen werden serverseitig geprüft.";


    state.className =
        "ready";
}


async function performLiveDataReset() {

    if (liveDataResetBusy)
        return;


    const button =
        byId(
            "liveResetConfirmButton");


    const state =
        byId(
            "liveResetState");


    if (
        !button
        ||
        button.disabled
    ) {
        return;
    }


    /*
     * Erster Klick:
     * nur scharf schalten.
     */
    if (!liveDataResetArmed) {

        liveDataResetArmed =
            true;


        button.textContent =
            "JA · LIVE-DATEN ZURÜCKSETZEN";


        button.classList.add(
            "armed");


        if (state) {

            state.textContent =
                "Sicherheitsabfrage · Noch einmal tippen. Offene oder ungeklärte LIVE-Zustände werden vom Server blockiert.";


            state.className =
                "blocked";
        }


        liveDataResetArmTimer =
            window.setTimeout(
                () => {

                    resetLiveDataResetArm();


                    if (state) {

                        state.textContent =
                            "Bereit · Sicherheitsbedingungen werden serverseitig geprüft.";


                        state.className =
                            "ready";
                    }
                },
                8000);


        return;
    }


    liveDataResetBusy =
        true;


    if (liveDataResetArmTimer) {

        clearTimeout(
            liveDataResetArmTimer);

        liveDataResetArmTimer =
            null;
    }


    button.disabled =
        true;


    button.classList.remove(
        "armed");


    button.textContent =
        "LIVE-Daten werden zurückgesetzt …";


    if (state) {

        state.textContent =
            "Prüfe LIVE-Position, Recovery und Order-State …";


        state.className =
            "";
    }


    try {

        const result =
            await api(
                "/api/v1/btctrader/live/reset",
                {
                    method:
                        "POST",

                    body:
                        "{}"
                });


        closeLiveDataResetPanel();


        showTradingControlToast(
            result.Message
            ||
            result.message
            ||
            "LIVE-Daten wurden zurückgesetzt.",
            "success");


        await refreshTraderViews();
    }
    catch (error) {

        if (state) {

            state.textContent =
                error?.message
                ||
                "LIVE-Daten konnten nicht zurückgesetzt werden.";


            state.className =
                "blocked";
        }


        button.disabled =
            false;


        button.textContent =
            "LIVE-Daten zurücksetzen";
    }
    finally {

        liveDataResetBusy =
            false;


        liveDataResetArmed =
            false;
    }
}


// Listener bewusst mit Null-Checks.
const liveResetDrawerButton =
    byId(
        "drawerLiveResetButton");


const liveResetCancelButton =
    byId(
        "liveResetCancelButton");


const liveResetConfirmButton =
    byId(
        "liveResetConfirmButton");


if (liveResetDrawerButton) {

    liveResetDrawerButton.addEventListener(
        "click",
        openLiveDataResetPanel);
}


if (liveResetCancelButton) {

    liveResetCancelButton.addEventListener(
        "click",
        closeLiveDataResetPanel);
}


if (liveResetConfirmButton) {

    liveResetConfirmButton.addEventListener(
        "click",
        performLiveDataReset);
}

// ==========================================================
// BTC TRADER PRO · LIVE JAHRESREPORT UI V1
// ==========================================================

let annualReportBusy =
    false;

let annualReportResult =
    null;


function annualReportElements() {

    return {

        details:
            byId("settingsReportDetails"),

        owner:
            byId("reportOwnerName"),

        year:
            byId("reportYear"),

        generate:
            byId("reportGenerateButton"),

        status:
            byId("reportStatus"),

        result:
            byId("reportResult"),

        fillCount:
            byId("reportFillCount"),

        positionCount:
            byId("reportPositionCount"),

        excel:
            byId("reportExcelButton"),

        pdf:
            byId("reportPdfButton")
    };
}


function setAnnualReportStatus(
    text,
    type = "") {

    const {
        status
    } =
        annualReportElements();


    if (!status)
        return;


    if (!text) {

        status.textContent =
            "";

        status.className =
            "report-status hidden";

        return;
    }


    status.textContent =
        text;


    status.className =
        "report-status"
        +
        (
            type
                ? " " + type
                : ""
        );
}


function populateAnnualReportYears() {

    const {
        year
    } =
        annualReportElements();


    if (!year)
        return;


    if (year.options.length > 0)
        return;


    const currentYear =
        new Date().getFullYear();


    for (
        let value = currentYear;
        value >= 2009;
        value--
    ) {

        const option =
            document.createElement(
                "option");


        option.value =
            String(value);

        option.textContent =
            String(value);


        year.appendChild(
            option);
    }
}


function resetAnnualReportResult() {

    const {
        result,
        fillCount,
        positionCount
    } =
        annualReportElements();


    annualReportResult =
        null;


    if (fillCount)
        fillCount.textContent =
            "0";


    if (positionCount)
        positionCount.textContent =
            "0";


    if (result)
        result.classList.add(
            "hidden");
}


function annualReportRequestValues() {

    const {
        owner,
        year
    } =
        annualReportElements();


    const reportYear =
        Number(
            year?.value
            ||
            new Date().getFullYear());


    return {

        year:
            reportYear,

        ownerName:
            String(
                owner?.value
                ||
                ""
            )
            .trim()
            .slice(
                0,
                120)
    };
}


async function generateAnnualReport() {

    if (annualReportBusy)
        return;


    const {
        generate,
        result,
        fillCount,
        positionCount
    } =
        annualReportElements();


    if (!generate)
        return;


    const request =
        annualReportRequestValues();


    annualReportBusy =
        true;


    generate.disabled =
        true;


    generate.textContent =
        "Report wird erstellt …";


    resetAnnualReportResult();


    setAnnualReportStatus(
        "LIVE-Daten werden gelesen und der Jahresreport wird erstellt …",
        "working");


    try {

        const data =
            await api(
                "/api/v1/btctrader/reports/year",
                {
                    method:
                        "POST",

                    body:
                        JSON.stringify(
                            request)
                });


        annualReportResult =
            data;


        if (fillCount) {

            fillCount.textContent =
                String(
                    data.fillCount
                    ??
                    data.FillCount
                    ??
                    0);
        }


        if (positionCount) {

            positionCount.textContent =
                String(
                    data.positionCount
                    ??
                    data.PositionCount
                    ??
                    0);
        }


        if (result) {

            result.classList.remove(
                "hidden");
        }


        setAnnualReportStatus(
            "Jahresreport "
            +
            request.year
            +
            " wurde erfolgreich erstellt.",
            "success");
    }
    catch (error) {

        setAnnualReportStatus(
            error?.message
            ||
            "Der Jahresreport konnte nicht erstellt werden.",
            "error");
    }
    finally {

        annualReportBusy =
            false;


        generate.disabled =
            false;


        generate.textContent =
            "Report erstellen";
    }
}


function annualReportDownloadFileName(
    disposition,
    fallback) {

    const value =
        String(
            disposition
            ||
            "");


    const utfMatch =
        value.match(
            /filename\*=UTF-8''([^;]+)/i);


    if (utfMatch) {

        try {

            return decodeURIComponent(
                utfMatch[1]
            );
        }
        catch {
        }
    }


    const plainMatch =
        value.match(
            /filename="?([^";]+)"?/i);


    return plainMatch
        ?
        plainMatch[1]
        :
        fallback;
}


function annualReportBlobBase64(
    blob) {

    return new Promise(
        (
            resolve,
            reject
        ) => {

            const reader =
                new FileReader();


            reader.onload =
                () => {

                    try {

                        const value =
                            String(
                                reader.result
                                ||
                                "");


                        const comma =
                            value.indexOf(
                                ",");


                        if (comma < 0) {

                            reject(
                                new Error(
                                    "Datei konnte nicht für Android vorbereitet werden."));

                            return;
                        }


                        resolve(
                            value.substring(
                                comma + 1));
                    }
                    catch (error) {

                        reject(error);
                    }
                };


            reader.onerror =
                () =>
                    reject(
                        new Error(
                            "Datei konnte nicht für Android gelesen werden."));


            reader.readAsDataURL(
                blob);
        });
}


async function downloadAnnualReport(
    format) {

    if (annualReportBusy)
        return;


    const request =
        annualReportRequestValues();


    const extension =
        format === "pdf"
            ? "pdf"
            : "xlsx";


    const params =
        new URLSearchParams();


    params.set(
        "year",
        String(
            request.year));


    params.set(
        "ownerName",
        request.ownerName);


    const path =
        "/api/v1/btctrader/reports/year/"
        +
        extension
        +
        "?"
        +
        params.toString();


    const fallbackName =
        "BTC-LIVE-Jahresreport-"
        +
        request.year
        +
        "."
        +
        extension;


    annualReportBusy =
        true;


    setAnnualReportStatus(
        extension === "pdf"
            ? "PDF wird vorbereitet …"
            : "Excel-Datei wird vorbereitet …",
        "working");


    try {

        const headers =
            {
                "X-App-Id":
                    APP_ID
            };


        if (token) {

            headers.Authorization =
                "Bearer "
                +
                token;
        }


        const response =
            await localFetch(
                path,
                {
                    method:
                        "GET",

                    headers
                });


    


        if (!response.ok) {

            let message =
                `HTTP ${response.status}`;


            try {

                const contentType =
                    response.headers.get(
                        "Content-Type")
                    ||
                    "";


                if (
                    contentType.includes(
                        "application/json")
                ) {

                    const errorData =
                        await response.json();


                    message =
                        errorData.message
                        ||
                        errorData.Message
                        ||
                        errorData.error
                        ||
                        errorData.Error
                        ||
                        message;
                }
            }
            catch {
            }


            throw new Error(
                message);
        }


        const blob =
            await response.blob();


        const fileName =
            annualReportDownloadFileName(
                response.headers.get(
                    "Content-Disposition"),

                fallbackName);


        const isAndroidDownloadAvailable =
            !!(
                window.AndroidDownload
                &&
                typeof window.AndroidDownload.saveBase64
                    ===
                    "function"
            );


        if (isAndroidDownloadAvailable) {

            setAnnualReportStatus(
                extension === "pdf"
                    ? "PDF wird in Android Downloads gespeichert …"
                    : "Excel-Datei wird in Android Downloads gespeichert …",
                "working");


            const base64 =
                await annualReportBlobBase64(
                    blob);


            const mimeType =
                blob.type
                ||
                (
                    extension === "pdf"
                        ? "application/pdf"
                        : "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                );


            const nativeResult =
                String(
                    window.AndroidDownload.saveBase64(
                        fileName,
                        mimeType,
                        base64)
                    ||
                    "");


            if (
                !nativeResult.startsWith(
                    "OK:")
                &&
                !nativeResult.startsWith(
                    "OK_APP:")
            ) {

                throw new Error(
                    nativeResult.startsWith(
                        "ERROR:")
                        ? nativeResult.substring(
                            6)
                        : "Android konnte die Datei nicht speichern.");
            }


            if (
                nativeResult.startsWith(
                    "OK_APP:")
            ) {

                setAnnualReportStatus(
                    extension === "pdf"
                        ? "PDF wurde im App-Downloadbereich gespeichert."
                        : "Excel-Datei wurde im App-Downloadbereich gespeichert.",
                    "success");
            }
            else {

                setAnnualReportStatus(
                    extension === "pdf"
                        ? "PDF wurde unter Downloads/BTC Trader Pro gespeichert."
                        : "Excel-Datei wurde unter Downloads/BTC Trader Pro gespeichert.",
                    "success");
            }


            return;
        }


        const objectUrl =
            URL.createObjectURL(
                blob);


        const link =
            document.createElement(
                "a");


        link.href =
            objectUrl;

        link.download =
            fileName;

        link.style.display =
            "none";


        document.body.appendChild(
            link);


        link.click();
        link.remove();


        setTimeout(
            () =>
                URL.revokeObjectURL(
                    objectUrl),
            1000);


        setAnnualReportStatus(
            extension === "pdf"
                ? "PDF-Download wurde gestartet."
                : "Excel-Download wurde gestartet.",
            "success");
    }
    catch (error) {

        setAnnualReportStatus(
            error?.message
            ||
            "Die Report-Datei konnte nicht heruntergeladen werden.",
            "error");
    }
    finally {

        annualReportBusy =
            false;
    }
}


function initializeAnnualReportUi() {

    const {
        details,
        owner,
        year,
        generate,
        excel,
        pdf
    } =
        annualReportElements();


    if (
        !details
        ||
        !owner
        ||
        !year
        ||
        !generate
        ||
        !excel
        ||
        !pdf
    ) {

        return;
    }


    if (
        details.dataset.reportUiReady
        ===
        "true"
    ) {

        return;
    }


    details.dataset.reportUiReady =
        "true";


    populateAnnualReportYears();


    generate.addEventListener(
        "click",
        generateAnnualReport);


    excel.addEventListener(
        "click",
        () =>
            downloadAnnualReport(
                "xlsx"));


    pdf.addEventListener(
        "click",
        () =>
            downloadAnnualReport(
                "pdf"));


    owner.addEventListener(
        "input",
        resetAnnualReportResult);


    year.addEventListener(
        "change",
        resetAnnualReportResult);
}


initializeAnnualReportUi();



// ==========================================================
// MANUELLER POSITIONS-SELL · PRODUCT UI V1
// ==========================================================
// Explizite Benutzeraktion. Darf eine offene LIVE-Position
// auch unter dem normalen Gewinnziel schließen. Dadurch wird
// keine automatische Verlust-SELL-Regel freigeschaltet.
// ==========================================================

let manualSellBusy = false;
let manualSellConfirmUntil = 0;
let manualSellConfirmTimer = null;
let manualSellConfirmedPosition = null;

function manualSellAvailabilityState() {
    const tradingMode = String(
        currentManualFirstBuyPersistedConfigValue("TradingMode") ?? ""
    ).trim().toUpperCase();

    if (tradingMode !== "LIVE") {
        return {
            allowed: false,
            reason: "Der manuelle SELL ist nur in LIVE verfügbar."
        };
    }

    if (!configPositionOpen) {
        return {
            allowed: false,
            reason: "Es ist keine offene Position vorhanden."
        };
    }

    if (tradingMode === "LIVE" && !currentManualFirstBuyConfigBool("LiveTradingEnabled")) {
        return {
            allowed: false,
            reason: "LIVE Trading · Master ist AUS."
        };
    }

    if (tradingMode === "LIVE" && !currentManualFirstBuyConfigBool("AllowLiveSell")) {
        return {
            allowed: false,
            reason: "LIVE SELL ist nicht freigegeben."
        };
    }

    return {
        allowed: true,
        reason: "Die eigene Botposition kann über den bestehenden SELL-Pfad geschlossen werden."
    };
}

function clearManualSellConfirmation() {
    manualSellConfirmUntil = 0;
    manualSellConfirmedPosition = null;

    if (manualSellConfirmTimer) {
        clearTimeout(manualSellConfirmTimer);
        manualSellConfirmTimer = null;
    }

    const button = byId("binanceManualSellButton");
    if (button) {
        button.classList.remove("is-confirming");
    }
}

function armManualSellConfirmation() {
    clearManualSellConfirmation();

    const button = byId("binanceManualSellButton");
    if (!button)
        return;

    manualSellConfirmedPosition = {
        id: String(marketChartPosition?.positionIdText ?? "0"),
        mode: String(currentManualFirstBuyPersistedConfigValue("TradingMode") ?? "")
    };
    manualSellConfirmUntil = Date.now() + 8000;
    button.textContent = "Wirklich Position verkaufen?";
    button.classList.add("is-confirming");

    setMessage(
        "WARNUNG: Dieser manuelle SELL schließt die angezeigte Botposition bewusst auch dann, wenn das normale Gewinnziel noch nicht erreicht ist. "
        + "Dadurch kann ein realer Verlust entstehen. Zum Bestätigen innerhalb von 8 Sekunden erneut tippen.",
        "warning");

    manualSellConfirmTimer = setTimeout(
        () => {
            clearManualSellConfirmation();
            updateManualSellAvailability();
        },
        8000);
}

async function executeManualSell() {
    if (manualSellBusy)
        return;

    const button = byId("binanceManualSellButton");
    if (!button)
        return;

    const availability = manualSellAvailabilityState();
    if (!availability.allowed) {
        clearManualSellConfirmation();
        updateManualSellAvailability();
        setMessage(
            "Manueller SELL nicht verfügbar: " + availability.reason,
            "warning");
        return;
    }

    const now = Date.now();
    if (!manualSellConfirmUntil || now > manualSellConfirmUntil) {
        armManualSellConfirmation();
        return;
    }

    const finalAvailability = manualSellAvailabilityState();
    if (!finalAvailability.allowed) {
        clearManualSellConfirmation();
        updateManualSellAvailability();
        setMessage(
            "Manueller SELL nicht verfügbar: " + finalAvailability.reason,
            "warning");
        return;
    }

    const confirmed = manualSellConfirmedPosition;
    if (!confirmed || confirmed.id !== String(marketChartPosition?.positionIdText ?? "0") ||
        confirmed.mode !== String(currentManualFirstBuyPersistedConfigValue("TradingMode") ?? "")) {
        armManualSellConfirmation();
        return;
    }
    clearManualSellConfirmation();
    manualSellBusy = true;
    button.disabled = true;
    button.textContent = "SELL wird geprüft …";

    try {
        const data = await api(
            "/api/v1/btctrader/manual/sell",
            {
                method: "POST",
                headers: {
                    "X-Confirm-Manual-Sell": "LOSS_ACCEPTED",
                    "X-Manual-Position-Id": confirmed.id,
                    "X-Manual-Trading-Mode": confirmed.mode
                },
                body: "{}"
            });

        const code = String(data.code ?? data.Code ?? "");

        if (code === "MANUAL_SELL_ALREADY_QUEUED") {
            setMessage(
                "Ein manueller SELL wartet bereits auf Verarbeitung.",
                "warning");
        }
        else {
            setMessage(
                "Manueller SELL wurde angefordert. Der Trader prüft jetzt die bestehende SELL-Sicherheitskette des gewählten Modus.",
                "success");
        }
    }
    catch (error) {
        setMessage(
            error.message || "Manueller SELL konnte nicht angefordert werden.",
            "error");
    }
    finally {
        manualSellBusy = false;
        updateManualSellAvailability();
    }
}

function updateManualSellAvailability() {
    const button = byId("binanceManualSellButton");
    if (!button)
        return;

    const availability = manualSellAvailabilityState();
    if (!availability.allowed) {
        clearManualSellConfirmation();
    }

    button.disabled = manualSellBusy || !availability.allowed;

    if (!manualSellBusy) {
        const confirmationActive =
            manualSellConfirmUntil > Date.now();

        button.textContent = confirmationActive
            ? "Wirklich Position verkaufen?"
            : "Position jetzt verkaufen";
    }

    button.title = availability.reason;
}

function wireManualSellButton() {
    const button = byId("binanceManualSellButton");

    if (!button || button.dataset.manualSellWired === "true")
        return;

    button.dataset.manualSellWired = "true";
    button.addEventListener("click", executeManualSell);
    updateManualSellAvailability();
}

if (document.readyState === "loading") {
    document.addEventListener(
        "DOMContentLoaded",
        wireManualSellButton,
        { once: true });
}
else {
    wireManualSellButton();
}


// ==========================================================
// PRODUCT LIVE DIAGNOSTIC CONSOLE V1A
// UI shell only · read-only · no backend/trading actions
// ==========================================================

(() => {
    "use strict";

    const MAX_ENTRIES = 300;
    const FILTERS = [
        "ALLE",
        "WEB",
        "RULE",
        "LIVE",
        "BUY",
        "SELL",
        "ERROR"
    ];

    const entries = [];
    let activeFilter = "ALLE";
    let consoleUi = null;
    let displayFrozen = false;
    let backgroundStartedAt = document.hidden ? Date.now() : null;

    function diagTime() {
        return new Date().toLocaleTimeString(
            "de-DE",
            {
                hour: "2-digit",
                minute: "2-digit",
                second: "2-digit"
            });
    }

    function safeText(value) {
        return String(value ?? "")
            .replace(/\s+/g, " ")
            .trim();
    }

    function addEntry(category, text, level = "info") {
        const normalizedCategory =
            FILTERS.includes(category)
                ? category
                : "LIVE";

        entries.push({
            time: diagTime(),
            category: normalizedCategory,
            text: safeText(text),
            level
        });

        while (entries.length > MAX_ENTRIES)
            entries.shift();

        if (!displayFrozen)
            renderEntries();
    }

    function visibleEntries() {
        if (activeFilter === "ALLE")
            return entries;

        return entries.filter(
            x => x.category === activeFilter);
    }

    function renderEntries() {
        if (!consoleUi)
            return;

        const output =
            consoleUi.querySelector(
                "#liveDiagConsoleOutput");

        if (!output)
            return;

        const visible = visibleEntries();

        if (visible.length === 0) {
            output.innerHTML =
                '<div class="live-diag-empty">' +
                'Noch keine Diagnoseereignisse.' +
                '</div>';
            return;
        }

        output.innerHTML = "";

        for (const entry of visible) {
            const row =
                document.createElement("div");

            row.className =
                "live-diag-row level-" +
                entry.level;

            const time =
                document.createElement("span");
            time.className = "live-diag-time";
            time.textContent = entry.time;

            const category =
                document.createElement("span");
            category.className =
                "live-diag-category";
            category.textContent =
                entry.category;

            const message =
                document.createElement("span");
            message.className =
                "live-diag-message";
            message.textContent =
                entry.text;

            row.append(
                time,
                category,
                message);

            output.appendChild(row);
        }

        output.scrollTop =
            output.scrollHeight;
    }

    function setFilter(filter) {
        activeFilter = filter;

        if (!consoleUi)
            return;

        consoleUi
            .querySelectorAll(
                ".live-diag-filter")
            .forEach(button => {
                button.classList.toggle(
                    "active",
                    button.dataset.filter ===
                        activeFilter);
            });

        renderEntries();
    }

    function copyDiagnostic() {
        const visible = visibleEntries();

        const lines = [
            "BTC_TRADER_PRO_DIAGNOSTIC",
            "CapturedUtc=" +
                new Date().toISOString(),
            "Filter=" + activeFilter,
            "Entries=" + visible.length,
            "--------------------------"
        ];

        for (const entry of visible) {
            const tag =
                entry.level === "error"
                    ? "[ERROR]"
                    : entry.level === "warn"
                        ? "[WARN]"
                        : entry.level === "ok"
                            ? "[OK]"
                            : entry.level === "mark"
                                ? "[MARK]"
                                : "[INFO]";

            lines.push(
                `${tag} ${entry.time} ` +
                `${entry.category} ${entry.text}`);
        }

        lines.push("END_DIAGNOSTIC");

        const text =
            lines.join("\n");

        if (
            navigator.clipboard &&
            navigator.clipboard.writeText
        ) {
            navigator.clipboard
                .writeText(text)
                .then(() => {
                    addEntry(
                        "LIVE",
                        "Diagnoseblock kopiert.",
                        "ok");
                })
                .catch(() => {
                    window.prompt(
                        "Diagnoseblock kopieren:",
                        text);
                });

            return;
        }

        window.prompt(
            "Diagnoseblock kopieren:",
            text);
    }

    function clearDiagnostic() {
        entries.length = 0;
        renderEntries();
    }

    function addMarker() {
        addEntry(
            "LIVE",
            "★ USER MARKER",
            "mark");
    }

    function toggleFreeze() {
        displayFrozen = !displayFrozen;

        const button =
            consoleUi?.querySelector(
                "#liveDiagFreeze");

        if (button) {
            button.textContent =
                displayFrozen
                    ? "Live"
                    : "Einfrieren";

            button.classList.toggle(
                "active",
                displayFrozen);
        }

        if (!displayFrozen)
            renderEntries();
    }

    function createConsole() {
        if (consoleUi)
            return consoleUi;

        const panel =
            document.createElement("section");

        panel.id =
            "liveDiagnosticConsole";

        panel.className =
            "live-diagnostic-console hidden";

        panel.setAttribute(
            "aria-label",
            "BTC Trader Pro Live-Diagnosekonsole");

        panel.innerHTML = `
            <div class="live-diag-titlebar"
                 id="liveDiagTitlebar">

                <strong>
                    BTC TRADER PRO · LIVE-KONSOLE
                </strong>

                <button class="live-diag-close"
                        id="liveDiagClose"
                        type="button"
                        aria-label="Konsole schließen">
                    ×
                </button>
            </div>

            <div class="live-diag-filters">
                ${FILTERS.map(
                    filter => `
                        <button
                            type="button"
                            class="live-diag-filter${
                                filter === "ALLE"
                                    ? " active"
                                    : ""
                            }"
                            data-filter="${filter}">
                            ${filter}
                        </button>
                    `).join("")}
            </div>

            <div class="live-diag-output"
                 id="liveDiagConsoleOutput">
            </div>

            <div class="live-diag-actions">
                <button type="button"
                        id="liveDiagMark">
                    Markieren
                </button>

                <button type="button"
                        id="liveDiagFreeze">
                    Einfrieren
                </button>

                <button type="button"
                        id="liveDiagCopy">
                    Kopieren
                </button>

                <button type="button"
                        id="liveDiagClear">
                    Leeren
                </button>
            </div>
        `;

        document.body.appendChild(panel);
        consoleUi = panel;

        panel
            .querySelector("#liveDiagClose")
            .addEventListener(
                "click",
                () =>
                    panel.classList.add("hidden"));

        panel
            .querySelector("#liveDiagMark")
            .addEventListener(
                "click",
                addMarker);

        panel
            .querySelector("#liveDiagFreeze")
            .addEventListener(
                "click",
                toggleFreeze);

        panel
            .querySelector("#liveDiagCopy")
            .addEventListener(
                "click",
                copyDiagnostic);

        panel
            .querySelector("#liveDiagClear")
            .addEventListener(
                "click",
                clearDiagnostic);

        panel
            .querySelectorAll(
                ".live-diag-filter")
            .forEach(button => {
                button.addEventListener(
                    "click",
                    () =>
                        setFilter(
                            button.dataset.filter));
            });

        wireDragging(
            panel,
            panel.querySelector(
                "#liveDiagTitlebar"));

        renderEntries();

        return panel;
    }

    function wireDragging(panel, handle) {
        let dragging = false;
        let startX = 0;
        let startY = 0;
        let startLeft = 0;
        let startTop = 0;

        handle.addEventListener(
            "pointerdown",
            event => {
                if (
                    event.target.closest(
                        "button")
                )
                    return;

                const rect =
                    panel.getBoundingClientRect();

                dragging = true;
                startX = event.clientX;
                startY = event.clientY;
                startLeft = rect.left;
                startTop = rect.top;

                panel.style.right = "auto";
                panel.style.bottom = "auto";

                handle.setPointerCapture(
                    event.pointerId);
            });

        handle.addEventListener(
            "pointermove",
            event => {
                if (!dragging)
                    return;

                const width =
                    panel.offsetWidth;
                const height =
                    panel.offsetHeight;

                const nextLeft =
                    Math.max(
                        0,
                        Math.min(
                            window.innerWidth -
                                Math.min(width, 80),
                            startLeft +
                                event.clientX -
                                startX));

                const nextTop =
                    Math.max(
                        0,
                        Math.min(
                            window.innerHeight - 50,
                            startTop +
                                event.clientY -
                                startY));

                panel.style.left =
                    nextLeft + "px";
                panel.style.top =
                    nextTop + "px";
            });

        const stop = () => {
            dragging = false;
        };

        handle.addEventListener(
            "pointerup",
            stop);

        handle.addEventListener(
            "pointercancel",
            stop);
    }

    function openConsole() {
        const panel =
            createConsole();

        panel.classList.remove("hidden");

        if (entries.length === 0) {
            addEntry(
                "LIVE",
                "Diagnosekonsole bereit · V1A UI",
                "ok");
        }
    }

    document.addEventListener(
        "click",
        event => {
            const button =
                event.target.closest(
                    "#liveDiagnosticConsoleOpenButton");

            if (!button)
                return;

            openConsole();
        });

    // ======================================================
    // PRODUCT LIVE DIAGNOSTIC CONSOLE V1B.1
    // Existing UI/API observations only.
    // No additional trading/API polling.
    // ======================================================

    const changedState =
        new Map();

    function addChanged(
        category,
        key,
        text,
        level = "info") {

        const normalized =
            safeText(text);

        if (
            changedState.get(key) ===
            normalized
        ) {
            return;
        }

        changedState.set(
            key,
            normalized);

        addEntry(
            category,
            normalized,
            level);
    }

    function shortEndpoint(path) {
        const value =
            String(path || "");

        return value
            .replace(
                /^\/api\/v1\/btctrader\//,
                "/")
            .replace(
                /^\/api\//,
                "/");
    }

    function addWeb(
        path,
        status,
        durationMs,
        ok,
        clientSuspended = false) {

        const ms =
            Math.max(
                0,
                Math.round(
                    Number(durationMs) || 0));

        const endpoint =
            shortEndpoint(path);

        const optionalWarning =
            !ok &&
            Number(status) === 404 &&
            endpoint === "/optimizer";

        const suspended =
            clientSuspended === true;

        addEntry(
            ok || optionalWarning || suspended ? "WEB" : "ERROR",
            `${endpoint} ${status} · ${ms} ms${
                optionalWarning ? " · optional" : ""
            }${
                suspended ? " · CLIENT SUSPEND" : ""
            }`,
            suspended
                ? "warn"
                : ok
                    ? "ok"
                    : optionalWarning
                        ? "warn"
                        : "error");
    }

    window.addEventListener(
        "error",
        event => {

            const message =
                safeText(
                    event?.message ||
                    "JavaScript-Fehler");

            addEntry(
                "ERROR",
                `JS · ${message}`,
                "error");
        });

    window.addEventListener(
        "unhandledrejection",
        event => {

            const reason =
                event?.reason;

            const message =
                safeText(
                    reason?.message ||
                    reason ||
                    "Unbehandelte Promise-Ablehnung");

            addEntry(
                "ERROR",
                `PROMISE · ${message}`,
                "error");
        });

    // ======================================================
    // PRODUCT LIVE DIAGNOSTIC CONSOLE V1C
    // Read-only backend breadcrumbs via protected NGINX route.
    // ======================================================

    const backendSeen = new Set();
    let backendDiagTimer = null;
    let backendDiagBusy = false;

    function backendCategory(value) {
        const category =
            safeText(value).toUpperCase();

        return FILTERS.includes(category) &&
               category !== "ALLE"
            ? category
            : "LIVE";
    }

    function backendLevel(value) {
        const level =
            safeText(value).toLowerCase();

        return ["info", "ok", "warn", "error", "mark"]
            .includes(level)
                ? level
                : "info";
    }

    async function refreshBackendDiagnostics() {
        if (backendDiagBusy || !token || document.hidden)
            return;

        backendDiagBusy = true;
        const started = performance.now();
        const visibilityGeneration = pageVisibilityGeneration;

        try {
            const response = await localFetch(
                "/trader-api/diagnostics",
                {
                    method: "GET",
                    cache: "no-store",
                    credentials: "same-origin",
                    headers: {
                        "X-App-Id": APP_ID,
                        "Authorization": "Bearer " + token
                    }
                });

            addWeb(
                "/trader-api/diagnostics",
                response.status,
                performance.now() - started,
                response.ok,
                visibilityGeneration !== pageVisibilityGeneration);

            if (!response.ok)
                return;

            const data = await response.json();
            const backendEntries =
                data?.Entries ||
                data?.entries ||
                [];

            for (const item of backendEntries) {
                const time =
                    item?.TimeUtc ??
                    item?.timeUtc ??
                    "";

                const category =
                    backendCategory(
                        item?.Category ??
                        item?.category);

                const level =
                    backendLevel(
                        item?.Level ??
                        item?.level);

                const message =
                    safeText(
                        item?.Message ??
                        item?.message);

                const fingerprint =
                    `${time}|${category}|${level}|${message}`;

                if (backendSeen.has(fingerprint))
                    continue;

                backendSeen.add(fingerprint);

                addEntry(
                    category,
                    message,
                    level);
            }

            while (backendSeen.size > 600) {
                const first =
                    backendSeen.values().next().value;

                backendSeen.delete(first);
            }
        }
        catch (error) {
            const suspended =
                visibilityGeneration !== pageVisibilityGeneration;

            addEntry(
                suspended ? "WEB" : "ERROR",
                "Diagnostics API · " +
                    safeText(
                        error?.message ||
                        "Abruf fehlgeschlagen") +
                    (suspended ? " · CLIENT SUSPEND" : ""),
                suspended ? "warn" : "error");
        }
        finally {
            backendDiagBusy = false;
        }
    }

    document.addEventListener(
        "visibilitychange",
        () => {
            pageVisibilityGeneration++;

            if (document.hidden) {
                backgroundStartedAt = Date.now();
                traderRefreshPending = false;

                addEntry(
                    "WEB",
                    "App=BACKGROUND · Refresh pausiert",
                    "info");

                return;
            }

            const backgroundMs =
                backgroundStartedAt === null
                    ? 0
                    : Math.max(0, Date.now() - backgroundStartedAt);

            backgroundStartedAt = null;

            addEntry(
                "WEB",
                `App=FOREGROUND · Background=${Math.round(backgroundMs / 1000)}s`,
                "info");

            addEntry(
                "WEB",
                "RESUME_REFRESH=START",
                "info");

            requestTraderRefresh();

            if (consoleUi && !consoleUi.classList.contains("hidden"))
                refreshBackendDiagnostics();
        });

    function startBackendDiagnostics() {
        refreshBackendDiagnostics();

        if (backendDiagTimer)
            return;

        backendDiagTimer =
            window.setInterval(
                refreshBackendDiagnostics,
                5000);
    }

    const originalOpenConsole = openConsole;

    openConsole = function() {
        originalOpenConsole();
        startBackendDiagnostics();
    };

    window.BtcTraderDiag = Object.freeze({
        push: addEntry,
        changed: addChanged,
        web: addWeb,
        open: openConsole
    });
})();
